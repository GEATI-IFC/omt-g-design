/**
 */
package omtg.tests;

import junit.textui.TestRunner;

import omtg.DisjointPartial;
import omtg.OmtgFactory;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>Disjoint Partial</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public class DisjointPartialTest extends generalizationTest {

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static void main(String[] args) {
		TestRunner.run(DisjointPartialTest.class);
	}

	/**
	 * Constructs a new Disjoint Partial test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DisjointPartialTest(String name) {
		super(name);
	}

	/**
	 * Returns the fixture for this Disjoint Partial test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected DisjointPartial getFixture() {
		return (DisjointPartial)fixture;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#setUp()
	 * @generated
	 */
	@Override
	protected void setUp() throws Exception {
		setFixture(OmtgFactory.eINSTANCE.createDisjointPartial());
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#tearDown()
	 * @generated
	 */
	@Override
	protected void tearDown() throws Exception {
		setFixture(null);
	}

} //DisjointPartialTest
