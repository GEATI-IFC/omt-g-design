/**
 */
package omtg.tests;

import junit.textui.TestRunner;

import omtg.DisjointTotal;
import omtg.OmtgFactory;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>Disjoint Total</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public class DisjointTotalTest extends generalizationTest {

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static void main(String[] args) {
		TestRunner.run(DisjointTotalTest.class);
	}

	/**
	 * Constructs a new Disjoint Total test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DisjointTotalTest(String name) {
		super(name);
	}

	/**
	 * Returns the fixture for this Disjoint Total test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected DisjointTotal getFixture() {
		return (DisjointTotal)fixture;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#setUp()
	 * @generated
	 */
	@Override
	protected void setUp() throws Exception {
		setFixture(OmtgFactory.eINSTANCE.createDisjointTotal());
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#tearDown()
	 * @generated
	 */
	@Override
	protected void tearDown() throws Exception {
		setFixture(null);
	}

} //DisjointTotalTest
