/**
 */
package omtg.tests;

import junit.textui.TestRunner;

import omtg.Isoline;
import omtg.OmtgFactory;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>Isoline</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public class IsolineTest extends geoFieldTest {

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static void main(String[] args) {
		TestRunner.run(IsolineTest.class);
	}

	/**
	 * Constructs a new Isoline test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public IsolineTest(String name) {
		super(name);
	}

	/**
	 * Returns the fixture for this Isoline test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected Isoline getFixture() {
		return (Isoline)fixture;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#setUp()
	 * @generated
	 */
	@Override
	protected void setUp() throws Exception {
		setFixture(OmtgFactory.eINSTANCE.createIsoline());
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#tearDown()
	 * @generated
	 */
	@Override
	protected void tearDown() throws Exception {
		setFixture(null);
	}

} //IsolineTest
