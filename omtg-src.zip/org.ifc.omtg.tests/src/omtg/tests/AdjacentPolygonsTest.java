/**
 */
package omtg.tests;

import junit.textui.TestRunner;

import omtg.AdjacentPolygons;
import omtg.OmtgFactory;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>Adjacent Polygons</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public class AdjacentPolygonsTest extends geoFieldTest {

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static void main(String[] args) {
		TestRunner.run(AdjacentPolygonsTest.class);
	}

	/**
	 * Constructs a new Adjacent Polygons test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public AdjacentPolygonsTest(String name) {
		super(name);
	}

	/**
	 * Returns the fixture for this Adjacent Polygons test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected AdjacentPolygons getFixture() {
		return (AdjacentPolygons)fixture;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#setUp()
	 * @generated
	 */
	@Override
	protected void setUp() throws Exception {
		setFixture(OmtgFactory.eINSTANCE.createAdjacentPolygons());
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#tearDown()
	 * @generated
	 */
	@Override
	protected void tearDown() throws Exception {
		setFixture(null);
	}

} //AdjacentPolygonsTest
