/**
 */
package omtg.tests;

import junit.textui.TestRunner;

import omtg.Agregation;
import omtg.OmtgFactory;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>Agregation</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public class AgregationTest extends baseRelationshipTest {

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static void main(String[] args) {
		TestRunner.run(AgregationTest.class);
	}

	/**
	 * Constructs a new Agregation test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public AgregationTest(String name) {
		super(name);
	}

	/**
	 * Returns the fixture for this Agregation test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected Agregation getFixture() {
		return (Agregation)fixture;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#setUp()
	 * @generated
	 */
	@Override
	protected void setUp() throws Exception {
		setFixture(OmtgFactory.eINSTANCE.createAgregation());
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#tearDown()
	 * @generated
	 */
	@Override
	protected void tearDown() throws Exception {
		setFixture(null);
	}

} //AgregationTest
