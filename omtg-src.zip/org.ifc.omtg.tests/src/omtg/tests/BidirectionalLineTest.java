/**
 */
package omtg.tests;

import junit.textui.TestRunner;

import omtg.BidirectionalLine;
import omtg.OmtgFactory;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>Bidirectional Line</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public class BidirectionalLineTest extends geoObjectWithGeometryAndTopologyTest {

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static void main(String[] args) {
		TestRunner.run(BidirectionalLineTest.class);
	}

	/**
	 * Constructs a new Bidirectional Line test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public BidirectionalLineTest(String name) {
		super(name);
	}

	/**
	 * Returns the fixture for this Bidirectional Line test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected BidirectionalLine getFixture() {
		return (BidirectionalLine)fixture;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#setUp()
	 * @generated
	 */
	@Override
	protected void setUp() throws Exception {
		setFixture(OmtgFactory.eINSTANCE.createBidirectionalLine());
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#tearDown()
	 * @generated
	 */
	@Override
	protected void tearDown() throws Exception {
		setFixture(null);
	}

} //BidirectionalLineTest
