/**
 */
package omtg;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Disjoint Total</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see omtg.OmtgPackage#getDisjointTotal()
 * @model
 * @generated
 */
public interface DisjointTotal extends generalization {
} // DisjointTotal
