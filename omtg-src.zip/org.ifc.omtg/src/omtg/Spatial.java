/**
 */
package omtg;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Spatial</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see omtg.OmtgPackage#getSpatial()
 * @model
 * @generated
 */
public interface Spatial extends association {
} // Spatial
