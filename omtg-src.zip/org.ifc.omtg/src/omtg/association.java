/**
 */
package omtg;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>association</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see omtg.OmtgPackage#getassociation()
 * @model abstract="true"
 * @generated
 */
public interface association extends baseRelationship {
} // association
