/**
 */
package omtg;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Disjoint Partial</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see omtg.OmtgPackage#getDisjointPartial()
 * @model
 * @generated
 */
public interface DisjointPartial extends generalization {
} // DisjointPartial
