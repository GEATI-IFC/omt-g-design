/**
 */
package omtg.impl;

import omtg.Method;
import omtg.OmtgPackage;
import omtg.generalDataTypes;
import omtg.visibilityTypes;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Method</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link omtg.impl.MethodImpl#getName <em>Name</em>}</li>
 *   <li>{@link omtg.impl.MethodImpl#getVisibility <em>Visibility</em>}</li>
 *   <li>{@link omtg.impl.MethodImpl#getReturn <em>Return</em>}</li>
 *   <li>{@link omtg.impl.MethodImpl#getAttibutes <em>Attibutes</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class MethodImpl extends EObjectImpl implements Method {
	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getVisibility() <em>Visibility</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getVisibility()
	 * @generated
	 * @ordered
	 */
	protected static final visibilityTypes VISIBILITY_EDEFAULT = visibilityTypes.PUBLIC;

	/**
	 * The cached value of the '{@link #getVisibility() <em>Visibility</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getVisibility()
	 * @generated
	 * @ordered
	 */
	protected visibilityTypes visibility = VISIBILITY_EDEFAULT;

	/**
	 * The default value of the '{@link #getReturn() <em>Return</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getReturn()
	 * @generated
	 * @ordered
	 */
	protected static final generalDataTypes RETURN_EDEFAULT = generalDataTypes.BIGINT;

	/**
	 * The cached value of the '{@link #getReturn() <em>Return</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getReturn()
	 * @generated
	 * @ordered
	 */
	protected generalDataTypes return_ = RETURN_EDEFAULT;

	/**
	 * The default value of the '{@link #getAttibutes() <em>Attibutes</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAttibutes()
	 * @generated
	 * @ordered
	 */
	protected static final String ATTIBUTES_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getAttibutes() <em>Attibutes</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAttibutes()
	 * @generated
	 * @ordered
	 */
	protected String attibutes = ATTIBUTES_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected MethodImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return OmtgPackage.Literals.METHOD;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, OmtgPackage.METHOD__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public visibilityTypes getVisibility() {
		return visibility;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setVisibility(visibilityTypes newVisibility) {
		visibilityTypes oldVisibility = visibility;
		visibility = newVisibility == null ? VISIBILITY_EDEFAULT : newVisibility;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, OmtgPackage.METHOD__VISIBILITY, oldVisibility, visibility));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public generalDataTypes getReturn() {
		return return_;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setReturn(generalDataTypes newReturn) {
		generalDataTypes oldReturn = return_;
		return_ = newReturn == null ? RETURN_EDEFAULT : newReturn;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, OmtgPackage.METHOD__RETURN, oldReturn, return_));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getAttibutes() {
		return attibutes;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setAttibutes(String newAttibutes) {
		String oldAttibutes = attibutes;
		attibutes = newAttibutes;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, OmtgPackage.METHOD__ATTIBUTES, oldAttibutes, attibutes));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case OmtgPackage.METHOD__NAME:
				return getName();
			case OmtgPackage.METHOD__VISIBILITY:
				return getVisibility();
			case OmtgPackage.METHOD__RETURN:
				return getReturn();
			case OmtgPackage.METHOD__ATTIBUTES:
				return getAttibutes();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case OmtgPackage.METHOD__NAME:
				setName((String)newValue);
				return;
			case OmtgPackage.METHOD__VISIBILITY:
				setVisibility((visibilityTypes)newValue);
				return;
			case OmtgPackage.METHOD__RETURN:
				setReturn((generalDataTypes)newValue);
				return;
			case OmtgPackage.METHOD__ATTIBUTES:
				setAttibutes((String)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case OmtgPackage.METHOD__NAME:
				setName(NAME_EDEFAULT);
				return;
			case OmtgPackage.METHOD__VISIBILITY:
				setVisibility(VISIBILITY_EDEFAULT);
				return;
			case OmtgPackage.METHOD__RETURN:
				setReturn(RETURN_EDEFAULT);
				return;
			case OmtgPackage.METHOD__ATTIBUTES:
				setAttibutes(ATTIBUTES_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case OmtgPackage.METHOD__NAME:
				return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
			case OmtgPackage.METHOD__VISIBILITY:
				return visibility != VISIBILITY_EDEFAULT;
			case OmtgPackage.METHOD__RETURN:
				return return_ != RETURN_EDEFAULT;
			case OmtgPackage.METHOD__ATTIBUTES:
				return ATTIBUTES_EDEFAULT == null ? attibutes != null : !ATTIBUTES_EDEFAULT.equals(attibutes);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (name: ");
		result.append(name);
		result.append(", visibility: ");
		result.append(visibility);
		result.append(", return: ");
		result.append(return_);
		result.append(", attibutes: ");
		result.append(attibutes);
		result.append(')');
		return result.toString();
	}

} //MethodImpl
