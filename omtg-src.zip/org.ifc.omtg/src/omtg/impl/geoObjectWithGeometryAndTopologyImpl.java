/**
 */
package omtg.impl;

import omtg.OmtgPackage;
import omtg.geoObjectWithGeometryAndTopology;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>geo Object With Geometry And Topology</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * </p>
 *
 * @generated
 */
public abstract class geoObjectWithGeometryAndTopologyImpl extends geoObjectImpl implements geoObjectWithGeometryAndTopology {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected geoObjectWithGeometryAndTopologyImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return OmtgPackage.Literals.GEO_OBJECT_WITH_GEOMETRY_AND_TOPOLOGY;
	}

} //geoObjectWithGeometryAndTopologyImpl
