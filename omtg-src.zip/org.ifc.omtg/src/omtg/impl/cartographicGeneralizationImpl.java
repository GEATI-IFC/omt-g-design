/**
 */
package omtg.impl;

import omtg.OmtgPackage;
import omtg.cartographicGeneralization;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>cartographic Generalization</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * </p>
 *
 * @generated
 */
public abstract class cartographicGeneralizationImpl extends baseRelationshipImpl implements cartographicGeneralization {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected cartographicGeneralizationImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return OmtgPackage.Literals.CARTOGRAPHIC_GENERALIZATION;
	}

} //cartographicGeneralizationImpl
