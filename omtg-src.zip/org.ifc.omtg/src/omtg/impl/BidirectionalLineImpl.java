/**
 */
package omtg.impl;

import omtg.BidirectionalLine;
import omtg.OmtgPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Bidirectional Line</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * </p>
 *
 * @generated
 */
public class BidirectionalLineImpl extends geoObjectWithGeometryAndTopologyImpl implements BidirectionalLine {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected BidirectionalLineImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return OmtgPackage.Literals.BIDIRECTIONAL_LINE;
	}

} //BidirectionalLineImpl
