/**
 */
package omtg.impl;

import omtg.OmtgPackage;
import omtg.geoObjectWithGeometry;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>geo Object With Geometry</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * </p>
 *
 * @generated
 */
public abstract class geoObjectWithGeometryImpl extends geoObjectImpl implements geoObjectWithGeometry {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected geoObjectWithGeometryImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return OmtgPackage.Literals.GEO_OBJECT_WITH_GEOMETRY;
	}

} //geoObjectWithGeometryImpl
