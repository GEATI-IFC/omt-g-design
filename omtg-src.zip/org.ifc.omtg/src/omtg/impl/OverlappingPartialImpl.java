/**
 */
package omtg.impl;

import omtg.OmtgPackage;
import omtg.OverlappingPartial;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Overlapping Partial</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * </p>
 *
 * @generated
 */
public class OverlappingPartialImpl extends generalizationImpl implements OverlappingPartial {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected OverlappingPartialImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return OmtgPackage.Literals.OVERLAPPING_PARTIAL;
	}

} //OverlappingPartialImpl
