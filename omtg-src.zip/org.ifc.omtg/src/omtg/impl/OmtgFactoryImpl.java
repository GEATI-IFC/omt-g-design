/**
 */
package omtg.impl;

import omtg.*;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.impl.EFactoryImpl;

import org.eclipse.emf.ecore.plugin.EcorePlugin;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Factory</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class OmtgFactoryImpl extends EFactoryImpl implements OmtgFactory {
	/**
	 * Creates the default factory implementation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static OmtgFactory init() {
		try {
			OmtgFactory theOmtgFactory = (OmtgFactory)EPackage.Registry.INSTANCE.getEFactory("http://www.ifc-camboriu.edu.br/~frozza/omtg"); 
			if (theOmtgFactory != null) {
				return theOmtgFactory;
			}
		}
		catch (Exception exception) {
			EcorePlugin.INSTANCE.log(exception);
		}
		return new OmtgFactoryImpl();
	}

	/**
	 * Creates an instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public OmtgFactoryImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EObject create(EClass eClass) {
		switch (eClass.getClassifierID()) {
			case OmtgPackage.SCHEMA: return createSchema();
			case OmtgPackage.CONVENTIONAL: return createConventional();
			case OmtgPackage.ATTRIBUTE: return createAttribute();
			case OmtgPackage.METHOD: return createMethod();
			case OmtgPackage.NETWORK_CLASS: return createNetworkClass();
			case OmtgPackage.SAMPLING: return createSampling();
			case OmtgPackage.ADJACENT_POLYGONS: return createAdjacentPolygons();
			case OmtgPackage.TESSELATION: return createTesselation();
			case OmtgPackage.ISOLINE: return createIsoline();
			case OmtgPackage.POLYGON: return createPolygon();
			case OmtgPackage.POINT: return createPoint();
			case OmtgPackage.LINE: return createLine();
			case OmtgPackage.NODE: return createNode();
			case OmtgPackage.UNIDIRECTIONAL_LINE: return createUnidirectionalLine();
			case OmtgPackage.BIDIRECTIONAL_LINE: return createBidirectionalLine();
			case OmtgPackage.AGREGATION: return createAgregation();
			case OmtgPackage.SPATIAL_AGREGATION: return createSpatialAgregation();
			case OmtgPackage.SIMPLE: return createSimple();
			case OmtgPackage.SPATIAL: return createSpatial();
			case OmtgPackage.NETWORK_ASSOCIATION: return createNetworkAssociation();
			case OmtgPackage.DISJOINT_PARTIAL: return createDisjointPartial();
			case OmtgPackage.DISJOINT_TOTAL: return createDisjointTotal();
			case OmtgPackage.OVERLAPPING_PARTIAL: return createOverlappingPartial();
			case OmtgPackage.OVERLAPPING_TOTAL: return createOverlappingTotal();
			case OmtgPackage.SHAPE: return createShape();
			case OmtgPackage.SCALE: return createScale();
			default:
				throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object createFromString(EDataType eDataType, String initialValue) {
		switch (eDataType.getClassifierID()) {
			case OmtgPackage.GENERAL_DATA_TYPES:
				return creategeneralDataTypesFromString(eDataType, initialValue);
			case OmtgPackage.CARDINALITY:
				return createCardinalityFromString(eDataType, initialValue);
			case OmtgPackage.VISIBILITY_TYPES:
				return createvisibilityTypesFromString(eDataType, initialValue);
			default:
				throw new IllegalArgumentException("The datatype '" + eDataType.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String convertToString(EDataType eDataType, Object instanceValue) {
		switch (eDataType.getClassifierID()) {
			case OmtgPackage.GENERAL_DATA_TYPES:
				return convertgeneralDataTypesToString(eDataType, instanceValue);
			case OmtgPackage.CARDINALITY:
				return convertCardinalityToString(eDataType, instanceValue);
			case OmtgPackage.VISIBILITY_TYPES:
				return convertvisibilityTypesToString(eDataType, instanceValue);
			default:
				throw new IllegalArgumentException("The datatype '" + eDataType.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Schema createSchema() {
		SchemaImpl schema = new SchemaImpl();
		return schema;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Conventional createConventional() {
		ConventionalImpl conventional = new ConventionalImpl();
		return conventional;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Attribute createAttribute() {
		AttributeImpl attribute = new AttributeImpl();
		return attribute;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Method createMethod() {
		MethodImpl method = new MethodImpl();
		return method;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NetworkClass createNetworkClass() {
		NetworkClassImpl networkClass = new NetworkClassImpl();
		return networkClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Sampling createSampling() {
		SamplingImpl sampling = new SamplingImpl();
		return sampling;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public AdjacentPolygons createAdjacentPolygons() {
		AdjacentPolygonsImpl adjacentPolygons = new AdjacentPolygonsImpl();
		return adjacentPolygons;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Tesselation createTesselation() {
		TesselationImpl tesselation = new TesselationImpl();
		return tesselation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Isoline createIsoline() {
		IsolineImpl isoline = new IsolineImpl();
		return isoline;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Polygon createPolygon() {
		PolygonImpl polygon = new PolygonImpl();
		return polygon;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Point createPoint() {
		PointImpl point = new PointImpl();
		return point;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Line createLine() {
		LineImpl line = new LineImpl();
		return line;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Node createNode() {
		NodeImpl node = new NodeImpl();
		return node;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public UnidirectionalLine createUnidirectionalLine() {
		UnidirectionalLineImpl unidirectionalLine = new UnidirectionalLineImpl();
		return unidirectionalLine;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public BidirectionalLine createBidirectionalLine() {
		BidirectionalLineImpl bidirectionalLine = new BidirectionalLineImpl();
		return bidirectionalLine;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Agregation createAgregation() {
		AgregationImpl agregation = new AgregationImpl();
		return agregation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SpatialAgregation createSpatialAgregation() {
		SpatialAgregationImpl spatialAgregation = new SpatialAgregationImpl();
		return spatialAgregation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Simple createSimple() {
		SimpleImpl simple = new SimpleImpl();
		return simple;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Spatial createSpatial() {
		SpatialImpl spatial = new SpatialImpl();
		return spatial;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NetworkAssociation createNetworkAssociation() {
		NetworkAssociationImpl networkAssociation = new NetworkAssociationImpl();
		return networkAssociation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DisjointPartial createDisjointPartial() {
		DisjointPartialImpl disjointPartial = new DisjointPartialImpl();
		return disjointPartial;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DisjointTotal createDisjointTotal() {
		DisjointTotalImpl disjointTotal = new DisjointTotalImpl();
		return disjointTotal;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public OverlappingPartial createOverlappingPartial() {
		OverlappingPartialImpl overlappingPartial = new OverlappingPartialImpl();
		return overlappingPartial;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public OverlappingTotal createOverlappingTotal() {
		OverlappingTotalImpl overlappingTotal = new OverlappingTotalImpl();
		return overlappingTotal;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Shape createShape() {
		ShapeImpl shape = new ShapeImpl();
		return shape;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Scale createScale() {
		ScaleImpl scale = new ScaleImpl();
		return scale;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public generalDataTypes creategeneralDataTypesFromString(EDataType eDataType, String initialValue) {
		generalDataTypes result = generalDataTypes.get(initialValue);
		if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertgeneralDataTypesToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Cardinality createCardinalityFromString(EDataType eDataType, String initialValue) {
		Cardinality result = Cardinality.get(initialValue);
		if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertCardinalityToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public visibilityTypes createvisibilityTypesFromString(EDataType eDataType, String initialValue) {
		visibilityTypes result = visibilityTypes.get(initialValue);
		if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertvisibilityTypesToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public OmtgPackage getOmtgPackage() {
		return (OmtgPackage)getEPackage();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @deprecated
	 * @generated
	 */
	@Deprecated
	public static OmtgPackage getPackage() {
		return OmtgPackage.eINSTANCE;
	}

} //OmtgFactoryImpl
