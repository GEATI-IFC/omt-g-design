/**
 */
package omtg.impl;

import omtg.AdjacentPolygons;
import omtg.Agregation;
import omtg.Attribute;
import omtg.BidirectionalLine;
import omtg.Cardinality;
import omtg.Conventional;
import omtg.DisjointPartial;
import omtg.DisjointTotal;
import omtg.Isoline;
import omtg.Line;
import omtg.Method;
import omtg.NetworkAssociation;
import omtg.NetworkClass;
import omtg.Node;
import omtg.OmtgFactory;
import omtg.OmtgPackage;
import omtg.OverlappingPartial;
import omtg.OverlappingTotal;
import omtg.Point;
import omtg.Polygon;
import omtg.Sampling;
import omtg.Scale;
import omtg.Schema;
import omtg.Shape;
import omtg.Simple;
import omtg.Spatial;
import omtg.SpatialAgregation;
import omtg.Tesselation;
import omtg.UnidirectionalLine;
import omtg.association;
import omtg.attributeSupport;
import omtg.baseRelationship;
import omtg.cartographicGeneralization;
import omtg.element;
import omtg.generalDataTypes;
import omtg.generalization;
import omtg.geoField;
import omtg.geoObject;
import omtg.geoObjectWithGeometry;
import omtg.geoObjectWithGeometryAndTopology;
import omtg.visibilityTypes;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

import org.eclipse.emf.ecore.impl.EPackageImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Package</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class OmtgPackageImpl extends EPackageImpl implements OmtgPackage {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass schemaEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass elementEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass conventionalEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass attributeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass methodEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass geoFieldEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass geoObjectEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass networkClassEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass samplingEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass geoObjectWithGeometryEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass adjacentPolygonsEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass tesselationEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass isolineEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass polygonEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass pointEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass lineEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass geoObjectWithGeometryAndTopologyEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass nodeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass unidirectionalLineEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass bidirectionalLineEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass baseRelationshipEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass associationEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass attributeSupportEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass generalizationEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass agregationEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass spatialAgregationEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass cartographicGeneralizationEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass simpleEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass spatialEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass networkAssociationEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass disjointPartialEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass disjointTotalEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass overlappingPartialEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass overlappingTotalEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass shapeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass scaleEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum generalDataTypesEEnum = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum cardinalityEEnum = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum visibilityTypesEEnum = null;

	/**
	 * Creates an instance of the model <b>Package</b>, registered with
	 * {@link org.eclipse.emf.ecore.EPackage.Registry EPackage.Registry} by the package
	 * package URI value.
	 * <p>Note: the correct way to create the package is via the static
	 * factory method {@link #init init()}, which also performs
	 * initialization of the package, or returns the registered package,
	 * if one already exists.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.emf.ecore.EPackage.Registry
	 * @see omtg.OmtgPackage#eNS_URI
	 * @see #init()
	 * @generated
	 */
	private OmtgPackageImpl() {
		super(eNS_URI, OmtgFactory.eINSTANCE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static boolean isInited = false;

	/**
	 * Creates, registers, and initializes the <b>Package</b> for this model, and for any others upon which it depends.
	 * 
	 * <p>This method is used to initialize {@link OmtgPackage#eINSTANCE} when that field is accessed.
	 * Clients should not invoke it directly. Instead, they should simply access that field to obtain the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #eNS_URI
	 * @see #createPackageContents()
	 * @see #initializePackageContents()
	 * @generated
	 */
	public static OmtgPackage init() {
		if (isInited) return (OmtgPackage)EPackage.Registry.INSTANCE.getEPackage(OmtgPackage.eNS_URI);

		// Obtain or create and register package
		OmtgPackageImpl theOmtgPackage = (OmtgPackageImpl)(EPackage.Registry.INSTANCE.get(eNS_URI) instanceof OmtgPackageImpl ? EPackage.Registry.INSTANCE.get(eNS_URI) : new OmtgPackageImpl());

		isInited = true;

		// Create package meta-data objects
		theOmtgPackage.createPackageContents();

		// Initialize created meta-data
		theOmtgPackage.initializePackageContents();

		// Mark meta-data to indicate it can't be changed
		theOmtgPackage.freeze();

  
		// Update the registry and return the package
		EPackage.Registry.INSTANCE.put(OmtgPackage.eNS_URI, theOmtgPackage);
		return theOmtgPackage;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getSchema() {
		return schemaEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getSchema_Class() {
		return (EReference)schemaEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getSchema_InvokeClass() {
		return (EReference)schemaEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getSchema_Relationship() {
		return (EReference)schemaEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSchema_Name() {
		return (EAttribute)schemaEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getelement() {
		return elementEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getelement_Name() {
		return (EAttribute)elementEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getConventional() {
		return conventionalEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getConventional_Method() {
		return (EReference)conventionalEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getAttribute() {
		return attributeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAttribute_Name() {
		return (EAttribute)attributeEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAttribute_Type() {
		return (EAttribute)attributeEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAttribute_Visibility() {
		return (EAttribute)attributeEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAttribute_IsIdentificable() {
		return (EAttribute)attributeEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getMethod() {
		return methodEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getMethod_Name() {
		return (EAttribute)methodEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getMethod_Visibility() {
		return (EAttribute)methodEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getMethod_Return() {
		return (EAttribute)methodEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getMethod_Attibutes() {
		return (EAttribute)methodEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getgeoField() {
		return geoFieldEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getgeoObject() {
		return geoObjectEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getNetworkClass() {
		return networkClassEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getSampling() {
		return samplingEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getgeoObjectWithGeometry() {
		return geoObjectWithGeometryEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getAdjacentPolygons() {
		return adjacentPolygonsEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getTesselation() {
		return tesselationEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getIsoline() {
		return isolineEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getPolygon() {
		return polygonEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getPoint() {
		return pointEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getLine() {
		return lineEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getgeoObjectWithGeometryAndTopology() {
		return geoObjectWithGeometryAndTopologyEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getNode() {
		return nodeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getUnidirectionalLine() {
		return unidirectionalLineEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getBidirectionalLine() {
		return bidirectionalLineEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getbaseRelationship() {
		return baseRelationshipEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getbaseRelationship_Source() {
		return (EReference)baseRelationshipEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getbaseRelationship_Target() {
		return (EReference)baseRelationshipEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getbaseRelationship_Cardinality() {
		return (EAttribute)baseRelationshipEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getbaseRelationship_Name() {
		return (EAttribute)baseRelationshipEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getassociation() {
		return associationEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getattributeSupport() {
		return attributeSupportEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getattributeSupport_Attribute() {
		return (EReference)attributeSupportEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getgeneralization() {
		return generalizationEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getAgregation() {
		return agregationEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getSpatialAgregation() {
		return spatialAgregationEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getcartographicGeneralization() {
		return cartographicGeneralizationEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getSimple() {
		return simpleEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getSpatial() {
		return spatialEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getNetworkAssociation() {
		return networkAssociationEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getDisjointPartial() {
		return disjointPartialEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getDisjointTotal() {
		return disjointTotalEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getOverlappingPartial() {
		return overlappingPartialEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getOverlappingTotal() {
		return overlappingTotalEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getShape() {
		return shapeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getScale() {
		return scaleEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getgeneralDataTypes() {
		return generalDataTypesEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getCardinality() {
		return cardinalityEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getvisibilityTypes() {
		return visibilityTypesEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public OmtgFactory getOmtgFactory() {
		return (OmtgFactory)getEFactoryInstance();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isCreated = false;

	/**
	 * Creates the meta-model objects for the package.  This method is
	 * guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void createPackageContents() {
		if (isCreated) return;
		isCreated = true;

		// Create classes and their features
		schemaEClass = createEClass(SCHEMA);
		createEReference(schemaEClass, SCHEMA__CLASS);
		createEReference(schemaEClass, SCHEMA__INVOKE_CLASS);
		createEReference(schemaEClass, SCHEMA__RELATIONSHIP);
		createEAttribute(schemaEClass, SCHEMA__NAME);

		elementEClass = createEClass(ELEMENT);
		createEAttribute(elementEClass, ELEMENT__NAME);

		conventionalEClass = createEClass(CONVENTIONAL);
		createEReference(conventionalEClass, CONVENTIONAL__METHOD);

		attributeEClass = createEClass(ATTRIBUTE);
		createEAttribute(attributeEClass, ATTRIBUTE__NAME);
		createEAttribute(attributeEClass, ATTRIBUTE__TYPE);
		createEAttribute(attributeEClass, ATTRIBUTE__VISIBILITY);
		createEAttribute(attributeEClass, ATTRIBUTE__IS_IDENTIFICABLE);

		methodEClass = createEClass(METHOD);
		createEAttribute(methodEClass, METHOD__NAME);
		createEAttribute(methodEClass, METHOD__VISIBILITY);
		createEAttribute(methodEClass, METHOD__RETURN);
		createEAttribute(methodEClass, METHOD__ATTIBUTES);

		geoFieldEClass = createEClass(GEO_FIELD);

		geoObjectEClass = createEClass(GEO_OBJECT);

		networkClassEClass = createEClass(NETWORK_CLASS);

		samplingEClass = createEClass(SAMPLING);

		geoObjectWithGeometryEClass = createEClass(GEO_OBJECT_WITH_GEOMETRY);

		adjacentPolygonsEClass = createEClass(ADJACENT_POLYGONS);

		tesselationEClass = createEClass(TESSELATION);

		isolineEClass = createEClass(ISOLINE);

		polygonEClass = createEClass(POLYGON);

		pointEClass = createEClass(POINT);

		lineEClass = createEClass(LINE);

		geoObjectWithGeometryAndTopologyEClass = createEClass(GEO_OBJECT_WITH_GEOMETRY_AND_TOPOLOGY);

		nodeEClass = createEClass(NODE);

		unidirectionalLineEClass = createEClass(UNIDIRECTIONAL_LINE);

		bidirectionalLineEClass = createEClass(BIDIRECTIONAL_LINE);

		baseRelationshipEClass = createEClass(BASE_RELATIONSHIP);
		createEReference(baseRelationshipEClass, BASE_RELATIONSHIP__SOURCE);
		createEReference(baseRelationshipEClass, BASE_RELATIONSHIP__TARGET);
		createEAttribute(baseRelationshipEClass, BASE_RELATIONSHIP__CARDINALITY);
		createEAttribute(baseRelationshipEClass, BASE_RELATIONSHIP__NAME);

		associationEClass = createEClass(ASSOCIATION);

		attributeSupportEClass = createEClass(ATTRIBUTE_SUPPORT);
		createEReference(attributeSupportEClass, ATTRIBUTE_SUPPORT__ATTRIBUTE);

		generalizationEClass = createEClass(GENERALIZATION);

		agregationEClass = createEClass(AGREGATION);

		spatialAgregationEClass = createEClass(SPATIAL_AGREGATION);

		cartographicGeneralizationEClass = createEClass(CARTOGRAPHIC_GENERALIZATION);

		simpleEClass = createEClass(SIMPLE);

		spatialEClass = createEClass(SPATIAL);

		networkAssociationEClass = createEClass(NETWORK_ASSOCIATION);

		disjointPartialEClass = createEClass(DISJOINT_PARTIAL);

		disjointTotalEClass = createEClass(DISJOINT_TOTAL);

		overlappingPartialEClass = createEClass(OVERLAPPING_PARTIAL);

		overlappingTotalEClass = createEClass(OVERLAPPING_TOTAL);

		shapeEClass = createEClass(SHAPE);

		scaleEClass = createEClass(SCALE);

		// Create enums
		generalDataTypesEEnum = createEEnum(GENERAL_DATA_TYPES);
		cardinalityEEnum = createEEnum(CARDINALITY);
		visibilityTypesEEnum = createEEnum(VISIBILITY_TYPES);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isInitialized = false;

	/**
	 * Complete the initialization of the package and its meta-model.  This
	 * method is guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void initializePackageContents() {
		if (isInitialized) return;
		isInitialized = true;

		// Initialize package
		setName(eNAME);
		setNsPrefix(eNS_PREFIX);
		setNsURI(eNS_URI);

		// Create type parameters

		// Set bounds for type parameters

		// Add supertypes to classes
		conventionalEClass.getESuperTypes().add(this.getelement());
		conventionalEClass.getESuperTypes().add(this.getattributeSupport());
		geoFieldEClass.getESuperTypes().add(this.getConventional());
		geoObjectEClass.getESuperTypes().add(this.getConventional());
		networkClassEClass.getESuperTypes().add(this.getgeoField());
		samplingEClass.getESuperTypes().add(this.getgeoField());
		geoObjectWithGeometryEClass.getESuperTypes().add(this.getgeoObject());
		adjacentPolygonsEClass.getESuperTypes().add(this.getgeoField());
		tesselationEClass.getESuperTypes().add(this.getgeoField());
		isolineEClass.getESuperTypes().add(this.getgeoField());
		polygonEClass.getESuperTypes().add(this.getgeoObjectWithGeometry());
		pointEClass.getESuperTypes().add(this.getgeoObjectWithGeometry());
		lineEClass.getESuperTypes().add(this.getgeoObjectWithGeometry());
		geoObjectWithGeometryAndTopologyEClass.getESuperTypes().add(this.getgeoObject());
		nodeEClass.getESuperTypes().add(this.getgeoObjectWithGeometryAndTopology());
		unidirectionalLineEClass.getESuperTypes().add(this.getgeoObjectWithGeometryAndTopology());
		bidirectionalLineEClass.getESuperTypes().add(this.getgeoObjectWithGeometryAndTopology());
		associationEClass.getESuperTypes().add(this.getbaseRelationship());
		generalizationEClass.getESuperTypes().add(this.getbaseRelationship());
		agregationEClass.getESuperTypes().add(this.getbaseRelationship());
		spatialAgregationEClass.getESuperTypes().add(this.getbaseRelationship());
		cartographicGeneralizationEClass.getESuperTypes().add(this.getbaseRelationship());
		simpleEClass.getESuperTypes().add(this.getassociation());
		spatialEClass.getESuperTypes().add(this.getassociation());
		networkAssociationEClass.getESuperTypes().add(this.getassociation());
		disjointPartialEClass.getESuperTypes().add(this.getgeneralization());
		disjointTotalEClass.getESuperTypes().add(this.getgeneralization());
		overlappingPartialEClass.getESuperTypes().add(this.getgeneralization());
		overlappingTotalEClass.getESuperTypes().add(this.getgeneralization());
		shapeEClass.getESuperTypes().add(this.getcartographicGeneralization());
		scaleEClass.getESuperTypes().add(this.getcartographicGeneralization());

		// Initialize classes and features; add operations and parameters
		initEClass(schemaEClass, Schema.class, "Schema", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getSchema_Class(), this.getelement(), null, "class", null, 0, -1, Schema.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getSchema_InvokeClass(), this.getConventional(), null, "invokeClass", null, 0, -1, Schema.class, IS_TRANSIENT, IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, IS_DERIVED, IS_ORDERED);
		initEReference(getSchema_Relationship(), this.getbaseRelationship(), null, "relationship", null, 0, -1, Schema.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getSchema_Name(), ecorePackage.getEString(), "name", null, 0, 1, Schema.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(elementEClass, element.class, "element", IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getelement_Name(), ecorePackage.getEString(), "name", null, 0, 1, element.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(conventionalEClass, Conventional.class, "Conventional", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getConventional_Method(), this.getMethod(), null, "method", null, 0, -1, Conventional.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(attributeEClass, Attribute.class, "Attribute", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getAttribute_Name(), ecorePackage.getEString(), "name", null, 1, 1, Attribute.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getAttribute_Type(), this.getgeneralDataTypes(), "type", "VARCHAR", 1, 1, Attribute.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getAttribute_Visibility(), this.getvisibilityTypes(), "visibility", null, 0, 1, Attribute.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getAttribute_IsIdentificable(), ecorePackage.getEBoolean(), "isIdentificable", null, 1, 1, Attribute.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(methodEClass, Method.class, "Method", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getMethod_Name(), ecorePackage.getEString(), "name", null, 1, 1, Method.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getMethod_Visibility(), this.getvisibilityTypes(), "visibility", "public", 1, 1, Method.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getMethod_Return(), this.getgeneralDataTypes(), "return", null, 0, 1, Method.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getMethod_Attibutes(), ecorePackage.getEString(), "attibutes", null, 0, 1, Method.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(geoFieldEClass, geoField.class, "geoField", IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(geoObjectEClass, geoObject.class, "geoObject", IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(networkClassEClass, NetworkClass.class, "NetworkClass", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(samplingEClass, Sampling.class, "Sampling", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(geoObjectWithGeometryEClass, geoObjectWithGeometry.class, "geoObjectWithGeometry", IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(adjacentPolygonsEClass, AdjacentPolygons.class, "AdjacentPolygons", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(tesselationEClass, Tesselation.class, "Tesselation", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(isolineEClass, Isoline.class, "Isoline", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(polygonEClass, Polygon.class, "Polygon", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(pointEClass, Point.class, "Point", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(lineEClass, Line.class, "Line", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(geoObjectWithGeometryAndTopologyEClass, geoObjectWithGeometryAndTopology.class, "geoObjectWithGeometryAndTopology", IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(nodeEClass, Node.class, "Node", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(unidirectionalLineEClass, UnidirectionalLine.class, "UnidirectionalLine", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(bidirectionalLineEClass, BidirectionalLine.class, "BidirectionalLine", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(baseRelationshipEClass, baseRelationship.class, "baseRelationship", IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getbaseRelationship_Source(), this.getelement(), null, "source", null, 1, 1, baseRelationship.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getbaseRelationship_Target(), this.getelement(), null, "target", null, 1, 1, baseRelationship.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getbaseRelationship_Cardinality(), this.getCardinality(), "cardinality", null, 1, 1, baseRelationship.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getbaseRelationship_Name(), ecorePackage.getEString(), "name", null, 0, 1, baseRelationship.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(associationEClass, association.class, "association", IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(attributeSupportEClass, attributeSupport.class, "attributeSupport", IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getattributeSupport_Attribute(), this.getAttribute(), null, "attribute", null, 0, -1, attributeSupport.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(generalizationEClass, generalization.class, "generalization", IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(agregationEClass, Agregation.class, "Agregation", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(spatialAgregationEClass, SpatialAgregation.class, "SpatialAgregation", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(cartographicGeneralizationEClass, cartographicGeneralization.class, "cartographicGeneralization", IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(simpleEClass, Simple.class, "Simple", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(spatialEClass, Spatial.class, "Spatial", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(networkAssociationEClass, NetworkAssociation.class, "NetworkAssociation", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(disjointPartialEClass, DisjointPartial.class, "DisjointPartial", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(disjointTotalEClass, DisjointTotal.class, "DisjointTotal", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(overlappingPartialEClass, OverlappingPartial.class, "OverlappingPartial", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(overlappingTotalEClass, OverlappingTotal.class, "OverlappingTotal", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(shapeEClass, Shape.class, "Shape", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(scaleEClass, Scale.class, "Scale", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		// Initialize enums and add enum literals
		initEEnum(generalDataTypesEEnum, generalDataTypes.class, "generalDataTypes");
		addEEnumLiteral(generalDataTypesEEnum, generalDataTypes.BIGINT);
		addEEnumLiteral(generalDataTypesEEnum, generalDataTypes.INTEGER);
		addEEnumLiteral(generalDataTypesEEnum, generalDataTypes.SMALLINT);
		addEEnumLiteral(generalDataTypesEEnum, generalDataTypes.INTERVAL);
		addEEnumLiteral(generalDataTypesEEnum, generalDataTypes.DOUBLE);
		addEEnumLiteral(generalDataTypesEEnum, generalDataTypes.BIT);
		addEEnumLiteral(generalDataTypesEEnum, generalDataTypes.BOOLEAN);
		addEEnumLiteral(generalDataTypesEEnum, generalDataTypes.CHAR);
		addEEnumLiteral(generalDataTypesEEnum, generalDataTypes.VARCHAR);
		addEEnumLiteral(generalDataTypesEEnum, generalDataTypes.DATE);
		addEEnumLiteral(generalDataTypesEEnum, generalDataTypes.TIMESTAMP);

		initEEnum(cardinalityEEnum, Cardinality.class, "Cardinality");
		addEEnumLiteral(cardinalityEEnum, Cardinality.ZERO_OR_MORE);
		addEEnumLiteral(cardinalityEEnum, Cardinality.ONE_OR_MORE);
		addEEnumLiteral(cardinalityEEnum, Cardinality.EXACTLY_ONE);
		addEEnumLiteral(cardinalityEEnum, Cardinality.ZERO_OR_ONE);

		initEEnum(visibilityTypesEEnum, visibilityTypes.class, "visibilityTypes");
		addEEnumLiteral(visibilityTypesEEnum, visibilityTypes.PUBLIC);
		addEEnumLiteral(visibilityTypesEEnum, visibilityTypes.PROTECTED);
		addEEnumLiteral(visibilityTypesEEnum, visibilityTypes.PRIVATE);

		// Create resource
		createResource(eNS_URI);
	}

} //OmtgPackageImpl
