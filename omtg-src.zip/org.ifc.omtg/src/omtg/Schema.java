/**
 */
package omtg;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Schema</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link omtg.Schema#getClass_ <em>Class</em>}</li>
 *   <li>{@link omtg.Schema#getInvokeClass <em>Invoke Class</em>}</li>
 *   <li>{@link omtg.Schema#getRelationship <em>Relationship</em>}</li>
 *   <li>{@link omtg.Schema#getName <em>Name</em>}</li>
 * </ul>
 * </p>
 *
 * @see omtg.OmtgPackage#getSchema()
 * @model
 * @generated
 */
public interface Schema extends EObject {
	/**
	 * Returns the value of the '<em><b>Class</b></em>' containment reference list.
	 * The list contents are of type {@link omtg.element}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Class</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Class</em>' containment reference list.
	 * @see omtg.OmtgPackage#getSchema_Class()
	 * @model containment="true"
	 * @generated
	 */
	EList<element> getClass_();

	/**
	 * Returns the value of the '<em><b>Invoke Class</b></em>' reference list.
	 * The list contents are of type {@link omtg.Conventional}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Invoke Class</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Invoke Class</em>' reference list.
	 * @see omtg.OmtgPackage#getSchema_InvokeClass()
	 * @model transient="true" volatile="true" derived="true"
	 * @generated
	 */
	EList<Conventional> getInvokeClass();

	/**
	 * Returns the value of the '<em><b>Relationship</b></em>' containment reference list.
	 * The list contents are of type {@link omtg.baseRelationship}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Relationship</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Relationship</em>' containment reference list.
	 * @see omtg.OmtgPackage#getSchema_Relationship()
	 * @model containment="true"
	 * @generated
	 */
	EList<baseRelationship> getRelationship();

	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see omtg.OmtgPackage#getSchema_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link omtg.Schema#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

} // Schema
