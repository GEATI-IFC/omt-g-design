/**
 */
package omtg;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Network Class</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see omtg.OmtgPackage#getNetworkClass()
 * @model
 * @generated
 */
public interface NetworkClass extends geoField {
} // NetworkClass
