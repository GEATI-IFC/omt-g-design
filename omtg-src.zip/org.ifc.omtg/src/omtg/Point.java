/**
 */
package omtg;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Point</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see omtg.OmtgPackage#getPoint()
 * @model
 * @generated
 */
public interface Point extends geoObjectWithGeometry {
} // Point
