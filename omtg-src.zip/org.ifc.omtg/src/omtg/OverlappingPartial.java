/**
 */
package omtg;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Overlapping Partial</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see omtg.OmtgPackage#getOverlappingPartial()
 * @model
 * @generated
 */
public interface OverlappingPartial extends generalization {
} // OverlappingPartial
