/**
 */
package omtg;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Unidirectional Line</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see omtg.OmtgPackage#getUnidirectionalLine()
 * @model
 * @generated
 */
public interface UnidirectionalLine extends geoObjectWithGeometryAndTopology {
} // UnidirectionalLine
