/**
 */
package omtg;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>generalization</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see omtg.OmtgPackage#getgeneralization()
 * @model abstract="true"
 * @generated
 */
public interface generalization extends baseRelationship {
} // generalization
