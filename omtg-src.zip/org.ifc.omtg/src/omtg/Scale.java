/**
 */
package omtg;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Scale</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see omtg.OmtgPackage#getScale()
 * @model
 * @generated
 */
public interface Scale extends cartographicGeneralization {
} // Scale
