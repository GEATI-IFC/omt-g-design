/**
 */
package omtg;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Line</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see omtg.OmtgPackage#getLine()
 * @model
 * @generated
 */
public interface Line extends geoObjectWithGeometry {
} // Line
