/**
 */
package omtg;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Adjacent Polygons</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see omtg.OmtgPackage#getAdjacentPolygons()
 * @model
 * @generated
 */
public interface AdjacentPolygons extends geoField {
} // AdjacentPolygons
