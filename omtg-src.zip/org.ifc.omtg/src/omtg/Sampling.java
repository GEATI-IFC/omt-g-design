/**
 */
package omtg;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Sampling</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see omtg.OmtgPackage#getSampling()
 * @model
 * @generated
 */
public interface Sampling extends geoField {
} // Sampling
