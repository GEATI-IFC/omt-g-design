/**
 */
package omtg;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Conventional</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link omtg.Conventional#getMethod <em>Method</em>}</li>
 * </ul>
 * </p>
 *
 * @see omtg.OmtgPackage#getConventional()
 * @model
 * @generated
 */
public interface Conventional extends element, attributeSupport {
	/**
	 * Returns the value of the '<em><b>Method</b></em>' containment reference list.
	 * The list contents are of type {@link omtg.Method}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Method</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Method</em>' containment reference list.
	 * @see omtg.OmtgPackage#getConventional_Method()
	 * @model containment="true"
	 * @generated
	 */
	EList<Method> getMethod();

} // Conventional
