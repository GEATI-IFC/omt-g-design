/**
 */
package omtg;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Shape</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see omtg.OmtgPackage#getShape()
 * @model
 * @generated
 */
public interface Shape extends cartographicGeneralization {
} // Shape
