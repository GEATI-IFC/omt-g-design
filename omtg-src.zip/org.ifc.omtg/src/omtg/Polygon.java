/**
 */
package omtg;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Polygon</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see omtg.OmtgPackage#getPolygon()
 * @model
 * @generated
 */
public interface Polygon extends geoObjectWithGeometry {
} // Polygon
