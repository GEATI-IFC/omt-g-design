/**
 */
package omtg;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>geo Field</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see omtg.OmtgPackage#getgeoField()
 * @model abstract="true"
 * @generated
 */
public interface geoField extends Conventional {
} // geoField
