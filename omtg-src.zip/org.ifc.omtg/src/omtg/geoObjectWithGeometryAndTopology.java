/**
 */
package omtg;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>geo Object With Geometry And Topology</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see omtg.OmtgPackage#getgeoObjectWithGeometryAndTopology()
 * @model abstract="true"
 * @generated
 */
public interface geoObjectWithGeometryAndTopology extends geoObject {
} // geoObjectWithGeometryAndTopology
