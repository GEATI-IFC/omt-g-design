/**
 */
package omtg;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>geo Object With Geometry</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see omtg.OmtgPackage#getgeoObjectWithGeometry()
 * @model abstract="true"
 * @generated
 */
public interface geoObjectWithGeometry extends geoObject {
} // geoObjectWithGeometry
