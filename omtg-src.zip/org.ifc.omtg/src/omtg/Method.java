/**
 */
package omtg;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Method</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link omtg.Method#getName <em>Name</em>}</li>
 *   <li>{@link omtg.Method#getVisibility <em>Visibility</em>}</li>
 *   <li>{@link omtg.Method#getReturn <em>Return</em>}</li>
 *   <li>{@link omtg.Method#getAttibutes <em>Attibutes</em>}</li>
 * </ul>
 * </p>
 *
 * @see omtg.OmtgPackage#getMethod()
 * @model
 * @generated
 */
public interface Method extends EObject {
	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see omtg.OmtgPackage#getMethod_Name()
	 * @model required="true"
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link omtg.Method#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Visibility</b></em>' attribute.
	 * The default value is <code>"public"</code>.
	 * The literals are from the enumeration {@link omtg.visibilityTypes}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Visibility</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Visibility</em>' attribute.
	 * @see omtg.visibilityTypes
	 * @see #setVisibility(visibilityTypes)
	 * @see omtg.OmtgPackage#getMethod_Visibility()
	 * @model default="public" required="true"
	 * @generated
	 */
	visibilityTypes getVisibility();

	/**
	 * Sets the value of the '{@link omtg.Method#getVisibility <em>Visibility</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Visibility</em>' attribute.
	 * @see omtg.visibilityTypes
	 * @see #getVisibility()
	 * @generated
	 */
	void setVisibility(visibilityTypes value);

	/**
	 * Returns the value of the '<em><b>Return</b></em>' attribute.
	 * The literals are from the enumeration {@link omtg.generalDataTypes}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Return</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Return</em>' attribute.
	 * @see omtg.generalDataTypes
	 * @see #setReturn(generalDataTypes)
	 * @see omtg.OmtgPackage#getMethod_Return()
	 * @model
	 * @generated
	 */
	generalDataTypes getReturn();

	/**
	 * Sets the value of the '{@link omtg.Method#getReturn <em>Return</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Return</em>' attribute.
	 * @see omtg.generalDataTypes
	 * @see #getReturn()
	 * @generated
	 */
	void setReturn(generalDataTypes value);

	/**
	 * Returns the value of the '<em><b>Attibutes</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Attibutes</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Attibutes</em>' attribute.
	 * @see #setAttibutes(String)
	 * @see omtg.OmtgPackage#getMethod_Attibutes()
	 * @model
	 * @generated
	 */
	String getAttibutes();

	/**
	 * Sets the value of the '{@link omtg.Method#getAttibutes <em>Attibutes</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Attibutes</em>' attribute.
	 * @see #getAttibutes()
	 * @generated
	 */
	void setAttibutes(String value);

} // Method
