/**
 */
package omtg;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>geo Object</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see omtg.OmtgPackage#getgeoObject()
 * @model abstract="true"
 * @generated
 */
public interface geoObject extends Conventional {
} // geoObject
