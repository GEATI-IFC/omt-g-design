/**
 */
package omtg;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Network Association</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see omtg.OmtgPackage#getNetworkAssociation()
 * @model
 * @generated
 */
public interface NetworkAssociation extends association {
} // NetworkAssociation
