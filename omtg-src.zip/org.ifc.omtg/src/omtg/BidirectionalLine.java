/**
 */
package omtg;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Bidirectional Line</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see omtg.OmtgPackage#getBidirectionalLine()
 * @model
 * @generated
 */
public interface BidirectionalLine extends geoObjectWithGeometryAndTopology {
} // BidirectionalLine
