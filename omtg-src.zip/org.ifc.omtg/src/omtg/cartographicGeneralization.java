/**
 */
package omtg;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>cartographic Generalization</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see omtg.OmtgPackage#getcartographicGeneralization()
 * @model abstract="true"
 * @generated
 */
public interface cartographicGeneralization extends baseRelationship {
} // cartographicGeneralization
