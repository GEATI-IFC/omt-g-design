/**
 */
package omtg;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see omtg.OmtgFactory
 * @model kind="package"
 * @generated
 */
public interface OmtgPackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "omtg";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://www.ifc-camboriu.edu.br/~frozza/omtg";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "omtg";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	OmtgPackage eINSTANCE = omtg.impl.OmtgPackageImpl.init();

	/**
	 * The meta object id for the '{@link omtg.impl.SchemaImpl <em>Schema</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see omtg.impl.SchemaImpl
	 * @see omtg.impl.OmtgPackageImpl#getSchema()
	 * @generated
	 */
	int SCHEMA = 0;

	/**
	 * The feature id for the '<em><b>Class</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SCHEMA__CLASS = 0;

	/**
	 * The feature id for the '<em><b>Invoke Class</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SCHEMA__INVOKE_CLASS = 1;

	/**
	 * The feature id for the '<em><b>Relationship</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SCHEMA__RELATIONSHIP = 2;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SCHEMA__NAME = 3;

	/**
	 * The number of structural features of the '<em>Schema</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SCHEMA_FEATURE_COUNT = 4;

	/**
	 * The meta object id for the '{@link omtg.impl.elementImpl <em>element</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see omtg.impl.elementImpl
	 * @see omtg.impl.OmtgPackageImpl#getelement()
	 * @generated
	 */
	int ELEMENT = 1;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ELEMENT__NAME = 0;

	/**
	 * The number of structural features of the '<em>element</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ELEMENT_FEATURE_COUNT = 1;

	/**
	 * The meta object id for the '{@link omtg.impl.ConventionalImpl <em>Conventional</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see omtg.impl.ConventionalImpl
	 * @see omtg.impl.OmtgPackageImpl#getConventional()
	 * @generated
	 */
	int CONVENTIONAL = 2;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONVENTIONAL__NAME = ELEMENT__NAME;

	/**
	 * The feature id for the '<em><b>Attribute</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONVENTIONAL__ATTRIBUTE = ELEMENT_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Method</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONVENTIONAL__METHOD = ELEMENT_FEATURE_COUNT + 1;

	/**
	 * The number of structural features of the '<em>Conventional</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONVENTIONAL_FEATURE_COUNT = ELEMENT_FEATURE_COUNT + 2;

	/**
	 * The meta object id for the '{@link omtg.impl.AttributeImpl <em>Attribute</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see omtg.impl.AttributeImpl
	 * @see omtg.impl.OmtgPackageImpl#getAttribute()
	 * @generated
	 */
	int ATTRIBUTE = 3;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATTRIBUTE__NAME = 0;

	/**
	 * The feature id for the '<em><b>Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATTRIBUTE__TYPE = 1;

	/**
	 * The feature id for the '<em><b>Visibility</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATTRIBUTE__VISIBILITY = 2;

	/**
	 * The feature id for the '<em><b>Is Identificable</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATTRIBUTE__IS_IDENTIFICABLE = 3;

	/**
	 * The number of structural features of the '<em>Attribute</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATTRIBUTE_FEATURE_COUNT = 4;

	/**
	 * The meta object id for the '{@link omtg.impl.MethodImpl <em>Method</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see omtg.impl.MethodImpl
	 * @see omtg.impl.OmtgPackageImpl#getMethod()
	 * @generated
	 */
	int METHOD = 4;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int METHOD__NAME = 0;

	/**
	 * The feature id for the '<em><b>Visibility</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int METHOD__VISIBILITY = 1;

	/**
	 * The feature id for the '<em><b>Return</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int METHOD__RETURN = 2;

	/**
	 * The feature id for the '<em><b>Attibutes</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int METHOD__ATTIBUTES = 3;

	/**
	 * The number of structural features of the '<em>Method</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int METHOD_FEATURE_COUNT = 4;

	/**
	 * The meta object id for the '{@link omtg.impl.geoFieldImpl <em>geo Field</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see omtg.impl.geoFieldImpl
	 * @see omtg.impl.OmtgPackageImpl#getgeoField()
	 * @generated
	 */
	int GEO_FIELD = 5;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GEO_FIELD__NAME = CONVENTIONAL__NAME;

	/**
	 * The feature id for the '<em><b>Attribute</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GEO_FIELD__ATTRIBUTE = CONVENTIONAL__ATTRIBUTE;

	/**
	 * The feature id for the '<em><b>Method</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GEO_FIELD__METHOD = CONVENTIONAL__METHOD;

	/**
	 * The number of structural features of the '<em>geo Field</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GEO_FIELD_FEATURE_COUNT = CONVENTIONAL_FEATURE_COUNT + 0;

	/**
	 * The meta object id for the '{@link omtg.impl.geoObjectImpl <em>geo Object</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see omtg.impl.geoObjectImpl
	 * @see omtg.impl.OmtgPackageImpl#getgeoObject()
	 * @generated
	 */
	int GEO_OBJECT = 6;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GEO_OBJECT__NAME = CONVENTIONAL__NAME;

	/**
	 * The feature id for the '<em><b>Attribute</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GEO_OBJECT__ATTRIBUTE = CONVENTIONAL__ATTRIBUTE;

	/**
	 * The feature id for the '<em><b>Method</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GEO_OBJECT__METHOD = CONVENTIONAL__METHOD;

	/**
	 * The number of structural features of the '<em>geo Object</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GEO_OBJECT_FEATURE_COUNT = CONVENTIONAL_FEATURE_COUNT + 0;

	/**
	 * The meta object id for the '{@link omtg.impl.NetworkClassImpl <em>Network Class</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see omtg.impl.NetworkClassImpl
	 * @see omtg.impl.OmtgPackageImpl#getNetworkClass()
	 * @generated
	 */
	int NETWORK_CLASS = 7;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NETWORK_CLASS__NAME = GEO_FIELD__NAME;

	/**
	 * The feature id for the '<em><b>Attribute</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NETWORK_CLASS__ATTRIBUTE = GEO_FIELD__ATTRIBUTE;

	/**
	 * The feature id for the '<em><b>Method</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NETWORK_CLASS__METHOD = GEO_FIELD__METHOD;

	/**
	 * The number of structural features of the '<em>Network Class</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NETWORK_CLASS_FEATURE_COUNT = GEO_FIELD_FEATURE_COUNT + 0;

	/**
	 * The meta object id for the '{@link omtg.impl.SamplingImpl <em>Sampling</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see omtg.impl.SamplingImpl
	 * @see omtg.impl.OmtgPackageImpl#getSampling()
	 * @generated
	 */
	int SAMPLING = 8;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SAMPLING__NAME = GEO_FIELD__NAME;

	/**
	 * The feature id for the '<em><b>Attribute</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SAMPLING__ATTRIBUTE = GEO_FIELD__ATTRIBUTE;

	/**
	 * The feature id for the '<em><b>Method</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SAMPLING__METHOD = GEO_FIELD__METHOD;

	/**
	 * The number of structural features of the '<em>Sampling</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SAMPLING_FEATURE_COUNT = GEO_FIELD_FEATURE_COUNT + 0;

	/**
	 * The meta object id for the '{@link omtg.impl.geoObjectWithGeometryImpl <em>geo Object With Geometry</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see omtg.impl.geoObjectWithGeometryImpl
	 * @see omtg.impl.OmtgPackageImpl#getgeoObjectWithGeometry()
	 * @generated
	 */
	int GEO_OBJECT_WITH_GEOMETRY = 9;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GEO_OBJECT_WITH_GEOMETRY__NAME = GEO_OBJECT__NAME;

	/**
	 * The feature id for the '<em><b>Attribute</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GEO_OBJECT_WITH_GEOMETRY__ATTRIBUTE = GEO_OBJECT__ATTRIBUTE;

	/**
	 * The feature id for the '<em><b>Method</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GEO_OBJECT_WITH_GEOMETRY__METHOD = GEO_OBJECT__METHOD;

	/**
	 * The number of structural features of the '<em>geo Object With Geometry</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GEO_OBJECT_WITH_GEOMETRY_FEATURE_COUNT = GEO_OBJECT_FEATURE_COUNT + 0;

	/**
	 * The meta object id for the '{@link omtg.impl.AdjacentPolygonsImpl <em>Adjacent Polygons</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see omtg.impl.AdjacentPolygonsImpl
	 * @see omtg.impl.OmtgPackageImpl#getAdjacentPolygons()
	 * @generated
	 */
	int ADJACENT_POLYGONS = 10;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ADJACENT_POLYGONS__NAME = GEO_FIELD__NAME;

	/**
	 * The feature id for the '<em><b>Attribute</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ADJACENT_POLYGONS__ATTRIBUTE = GEO_FIELD__ATTRIBUTE;

	/**
	 * The feature id for the '<em><b>Method</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ADJACENT_POLYGONS__METHOD = GEO_FIELD__METHOD;

	/**
	 * The number of structural features of the '<em>Adjacent Polygons</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ADJACENT_POLYGONS_FEATURE_COUNT = GEO_FIELD_FEATURE_COUNT + 0;

	/**
	 * The meta object id for the '{@link omtg.impl.TesselationImpl <em>Tesselation</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see omtg.impl.TesselationImpl
	 * @see omtg.impl.OmtgPackageImpl#getTesselation()
	 * @generated
	 */
	int TESSELATION = 11;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TESSELATION__NAME = GEO_FIELD__NAME;

	/**
	 * The feature id for the '<em><b>Attribute</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TESSELATION__ATTRIBUTE = GEO_FIELD__ATTRIBUTE;

	/**
	 * The feature id for the '<em><b>Method</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TESSELATION__METHOD = GEO_FIELD__METHOD;

	/**
	 * The number of structural features of the '<em>Tesselation</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TESSELATION_FEATURE_COUNT = GEO_FIELD_FEATURE_COUNT + 0;

	/**
	 * The meta object id for the '{@link omtg.impl.IsolineImpl <em>Isoline</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see omtg.impl.IsolineImpl
	 * @see omtg.impl.OmtgPackageImpl#getIsoline()
	 * @generated
	 */
	int ISOLINE = 12;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ISOLINE__NAME = GEO_FIELD__NAME;

	/**
	 * The feature id for the '<em><b>Attribute</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ISOLINE__ATTRIBUTE = GEO_FIELD__ATTRIBUTE;

	/**
	 * The feature id for the '<em><b>Method</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ISOLINE__METHOD = GEO_FIELD__METHOD;

	/**
	 * The number of structural features of the '<em>Isoline</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ISOLINE_FEATURE_COUNT = GEO_FIELD_FEATURE_COUNT + 0;

	/**
	 * The meta object id for the '{@link omtg.impl.PolygonImpl <em>Polygon</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see omtg.impl.PolygonImpl
	 * @see omtg.impl.OmtgPackageImpl#getPolygon()
	 * @generated
	 */
	int POLYGON = 13;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int POLYGON__NAME = GEO_OBJECT_WITH_GEOMETRY__NAME;

	/**
	 * The feature id for the '<em><b>Attribute</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int POLYGON__ATTRIBUTE = GEO_OBJECT_WITH_GEOMETRY__ATTRIBUTE;

	/**
	 * The feature id for the '<em><b>Method</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int POLYGON__METHOD = GEO_OBJECT_WITH_GEOMETRY__METHOD;

	/**
	 * The number of structural features of the '<em>Polygon</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int POLYGON_FEATURE_COUNT = GEO_OBJECT_WITH_GEOMETRY_FEATURE_COUNT + 0;

	/**
	 * The meta object id for the '{@link omtg.impl.PointImpl <em>Point</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see omtg.impl.PointImpl
	 * @see omtg.impl.OmtgPackageImpl#getPoint()
	 * @generated
	 */
	int POINT = 14;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int POINT__NAME = GEO_OBJECT_WITH_GEOMETRY__NAME;

	/**
	 * The feature id for the '<em><b>Attribute</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int POINT__ATTRIBUTE = GEO_OBJECT_WITH_GEOMETRY__ATTRIBUTE;

	/**
	 * The feature id for the '<em><b>Method</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int POINT__METHOD = GEO_OBJECT_WITH_GEOMETRY__METHOD;

	/**
	 * The number of structural features of the '<em>Point</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int POINT_FEATURE_COUNT = GEO_OBJECT_WITH_GEOMETRY_FEATURE_COUNT + 0;

	/**
	 * The meta object id for the '{@link omtg.impl.LineImpl <em>Line</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see omtg.impl.LineImpl
	 * @see omtg.impl.OmtgPackageImpl#getLine()
	 * @generated
	 */
	int LINE = 15;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LINE__NAME = GEO_OBJECT_WITH_GEOMETRY__NAME;

	/**
	 * The feature id for the '<em><b>Attribute</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LINE__ATTRIBUTE = GEO_OBJECT_WITH_GEOMETRY__ATTRIBUTE;

	/**
	 * The feature id for the '<em><b>Method</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LINE__METHOD = GEO_OBJECT_WITH_GEOMETRY__METHOD;

	/**
	 * The number of structural features of the '<em>Line</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LINE_FEATURE_COUNT = GEO_OBJECT_WITH_GEOMETRY_FEATURE_COUNT + 0;

	/**
	 * The meta object id for the '{@link omtg.impl.geoObjectWithGeometryAndTopologyImpl <em>geo Object With Geometry And Topology</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see omtg.impl.geoObjectWithGeometryAndTopologyImpl
	 * @see omtg.impl.OmtgPackageImpl#getgeoObjectWithGeometryAndTopology()
	 * @generated
	 */
	int GEO_OBJECT_WITH_GEOMETRY_AND_TOPOLOGY = 16;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GEO_OBJECT_WITH_GEOMETRY_AND_TOPOLOGY__NAME = GEO_OBJECT__NAME;

	/**
	 * The feature id for the '<em><b>Attribute</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GEO_OBJECT_WITH_GEOMETRY_AND_TOPOLOGY__ATTRIBUTE = GEO_OBJECT__ATTRIBUTE;

	/**
	 * The feature id for the '<em><b>Method</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GEO_OBJECT_WITH_GEOMETRY_AND_TOPOLOGY__METHOD = GEO_OBJECT__METHOD;

	/**
	 * The number of structural features of the '<em>geo Object With Geometry And Topology</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GEO_OBJECT_WITH_GEOMETRY_AND_TOPOLOGY_FEATURE_COUNT = GEO_OBJECT_FEATURE_COUNT + 0;

	/**
	 * The meta object id for the '{@link omtg.impl.NodeImpl <em>Node</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see omtg.impl.NodeImpl
	 * @see omtg.impl.OmtgPackageImpl#getNode()
	 * @generated
	 */
	int NODE = 17;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NODE__NAME = GEO_OBJECT_WITH_GEOMETRY_AND_TOPOLOGY__NAME;

	/**
	 * The feature id for the '<em><b>Attribute</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NODE__ATTRIBUTE = GEO_OBJECT_WITH_GEOMETRY_AND_TOPOLOGY__ATTRIBUTE;

	/**
	 * The feature id for the '<em><b>Method</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NODE__METHOD = GEO_OBJECT_WITH_GEOMETRY_AND_TOPOLOGY__METHOD;

	/**
	 * The number of structural features of the '<em>Node</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NODE_FEATURE_COUNT = GEO_OBJECT_WITH_GEOMETRY_AND_TOPOLOGY_FEATURE_COUNT + 0;

	/**
	 * The meta object id for the '{@link omtg.impl.UnidirectionalLineImpl <em>Unidirectional Line</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see omtg.impl.UnidirectionalLineImpl
	 * @see omtg.impl.OmtgPackageImpl#getUnidirectionalLine()
	 * @generated
	 */
	int UNIDIRECTIONAL_LINE = 18;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int UNIDIRECTIONAL_LINE__NAME = GEO_OBJECT_WITH_GEOMETRY_AND_TOPOLOGY__NAME;

	/**
	 * The feature id for the '<em><b>Attribute</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int UNIDIRECTIONAL_LINE__ATTRIBUTE = GEO_OBJECT_WITH_GEOMETRY_AND_TOPOLOGY__ATTRIBUTE;

	/**
	 * The feature id for the '<em><b>Method</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int UNIDIRECTIONAL_LINE__METHOD = GEO_OBJECT_WITH_GEOMETRY_AND_TOPOLOGY__METHOD;

	/**
	 * The number of structural features of the '<em>Unidirectional Line</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int UNIDIRECTIONAL_LINE_FEATURE_COUNT = GEO_OBJECT_WITH_GEOMETRY_AND_TOPOLOGY_FEATURE_COUNT + 0;

	/**
	 * The meta object id for the '{@link omtg.impl.BidirectionalLineImpl <em>Bidirectional Line</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see omtg.impl.BidirectionalLineImpl
	 * @see omtg.impl.OmtgPackageImpl#getBidirectionalLine()
	 * @generated
	 */
	int BIDIRECTIONAL_LINE = 19;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BIDIRECTIONAL_LINE__NAME = GEO_OBJECT_WITH_GEOMETRY_AND_TOPOLOGY__NAME;

	/**
	 * The feature id for the '<em><b>Attribute</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BIDIRECTIONAL_LINE__ATTRIBUTE = GEO_OBJECT_WITH_GEOMETRY_AND_TOPOLOGY__ATTRIBUTE;

	/**
	 * The feature id for the '<em><b>Method</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BIDIRECTIONAL_LINE__METHOD = GEO_OBJECT_WITH_GEOMETRY_AND_TOPOLOGY__METHOD;

	/**
	 * The number of structural features of the '<em>Bidirectional Line</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BIDIRECTIONAL_LINE_FEATURE_COUNT = GEO_OBJECT_WITH_GEOMETRY_AND_TOPOLOGY_FEATURE_COUNT + 0;

	/**
	 * The meta object id for the '{@link omtg.impl.baseRelationshipImpl <em>base Relationship</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see omtg.impl.baseRelationshipImpl
	 * @see omtg.impl.OmtgPackageImpl#getbaseRelationship()
	 * @generated
	 */
	int BASE_RELATIONSHIP = 20;

	/**
	 * The feature id for the '<em><b>Source</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BASE_RELATIONSHIP__SOURCE = 0;

	/**
	 * The feature id for the '<em><b>Target</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BASE_RELATIONSHIP__TARGET = 1;

	/**
	 * The feature id for the '<em><b>Cardinality</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BASE_RELATIONSHIP__CARDINALITY = 2;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BASE_RELATIONSHIP__NAME = 3;

	/**
	 * The number of structural features of the '<em>base Relationship</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BASE_RELATIONSHIP_FEATURE_COUNT = 4;

	/**
	 * The meta object id for the '{@link omtg.impl.associationImpl <em>association</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see omtg.impl.associationImpl
	 * @see omtg.impl.OmtgPackageImpl#getassociation()
	 * @generated
	 */
	int ASSOCIATION = 21;

	/**
	 * The feature id for the '<em><b>Source</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ASSOCIATION__SOURCE = BASE_RELATIONSHIP__SOURCE;

	/**
	 * The feature id for the '<em><b>Target</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ASSOCIATION__TARGET = BASE_RELATIONSHIP__TARGET;

	/**
	 * The feature id for the '<em><b>Cardinality</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ASSOCIATION__CARDINALITY = BASE_RELATIONSHIP__CARDINALITY;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ASSOCIATION__NAME = BASE_RELATIONSHIP__NAME;

	/**
	 * The number of structural features of the '<em>association</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ASSOCIATION_FEATURE_COUNT = BASE_RELATIONSHIP_FEATURE_COUNT + 0;

	/**
	 * The meta object id for the '{@link omtg.impl.attributeSupportImpl <em>attribute Support</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see omtg.impl.attributeSupportImpl
	 * @see omtg.impl.OmtgPackageImpl#getattributeSupport()
	 * @generated
	 */
	int ATTRIBUTE_SUPPORT = 22;

	/**
	 * The feature id for the '<em><b>Attribute</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATTRIBUTE_SUPPORT__ATTRIBUTE = 0;

	/**
	 * The number of structural features of the '<em>attribute Support</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATTRIBUTE_SUPPORT_FEATURE_COUNT = 1;

	/**
	 * The meta object id for the '{@link omtg.impl.generalizationImpl <em>generalization</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see omtg.impl.generalizationImpl
	 * @see omtg.impl.OmtgPackageImpl#getgeneralization()
	 * @generated
	 */
	int GENERALIZATION = 23;

	/**
	 * The feature id for the '<em><b>Source</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GENERALIZATION__SOURCE = BASE_RELATIONSHIP__SOURCE;

	/**
	 * The feature id for the '<em><b>Target</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GENERALIZATION__TARGET = BASE_RELATIONSHIP__TARGET;

	/**
	 * The feature id for the '<em><b>Cardinality</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GENERALIZATION__CARDINALITY = BASE_RELATIONSHIP__CARDINALITY;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GENERALIZATION__NAME = BASE_RELATIONSHIP__NAME;

	/**
	 * The number of structural features of the '<em>generalization</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GENERALIZATION_FEATURE_COUNT = BASE_RELATIONSHIP_FEATURE_COUNT + 0;

	/**
	 * The meta object id for the '{@link omtg.impl.AgregationImpl <em>Agregation</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see omtg.impl.AgregationImpl
	 * @see omtg.impl.OmtgPackageImpl#getAgregation()
	 * @generated
	 */
	int AGREGATION = 24;

	/**
	 * The feature id for the '<em><b>Source</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AGREGATION__SOURCE = BASE_RELATIONSHIP__SOURCE;

	/**
	 * The feature id for the '<em><b>Target</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AGREGATION__TARGET = BASE_RELATIONSHIP__TARGET;

	/**
	 * The feature id for the '<em><b>Cardinality</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AGREGATION__CARDINALITY = BASE_RELATIONSHIP__CARDINALITY;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AGREGATION__NAME = BASE_RELATIONSHIP__NAME;

	/**
	 * The number of structural features of the '<em>Agregation</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AGREGATION_FEATURE_COUNT = BASE_RELATIONSHIP_FEATURE_COUNT + 0;

	/**
	 * The meta object id for the '{@link omtg.impl.SpatialAgregationImpl <em>Spatial Agregation</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see omtg.impl.SpatialAgregationImpl
	 * @see omtg.impl.OmtgPackageImpl#getSpatialAgregation()
	 * @generated
	 */
	int SPATIAL_AGREGATION = 25;

	/**
	 * The feature id for the '<em><b>Source</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SPATIAL_AGREGATION__SOURCE = BASE_RELATIONSHIP__SOURCE;

	/**
	 * The feature id for the '<em><b>Target</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SPATIAL_AGREGATION__TARGET = BASE_RELATIONSHIP__TARGET;

	/**
	 * The feature id for the '<em><b>Cardinality</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SPATIAL_AGREGATION__CARDINALITY = BASE_RELATIONSHIP__CARDINALITY;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SPATIAL_AGREGATION__NAME = BASE_RELATIONSHIP__NAME;

	/**
	 * The number of structural features of the '<em>Spatial Agregation</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SPATIAL_AGREGATION_FEATURE_COUNT = BASE_RELATIONSHIP_FEATURE_COUNT + 0;

	/**
	 * The meta object id for the '{@link omtg.impl.cartographicGeneralizationImpl <em>cartographic Generalization</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see omtg.impl.cartographicGeneralizationImpl
	 * @see omtg.impl.OmtgPackageImpl#getcartographicGeneralization()
	 * @generated
	 */
	int CARTOGRAPHIC_GENERALIZATION = 26;

	/**
	 * The feature id for the '<em><b>Source</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CARTOGRAPHIC_GENERALIZATION__SOURCE = BASE_RELATIONSHIP__SOURCE;

	/**
	 * The feature id for the '<em><b>Target</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CARTOGRAPHIC_GENERALIZATION__TARGET = BASE_RELATIONSHIP__TARGET;

	/**
	 * The feature id for the '<em><b>Cardinality</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CARTOGRAPHIC_GENERALIZATION__CARDINALITY = BASE_RELATIONSHIP__CARDINALITY;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CARTOGRAPHIC_GENERALIZATION__NAME = BASE_RELATIONSHIP__NAME;

	/**
	 * The number of structural features of the '<em>cartographic Generalization</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CARTOGRAPHIC_GENERALIZATION_FEATURE_COUNT = BASE_RELATIONSHIP_FEATURE_COUNT + 0;

	/**
	 * The meta object id for the '{@link omtg.impl.SimpleImpl <em>Simple</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see omtg.impl.SimpleImpl
	 * @see omtg.impl.OmtgPackageImpl#getSimple()
	 * @generated
	 */
	int SIMPLE = 27;

	/**
	 * The feature id for the '<em><b>Source</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SIMPLE__SOURCE = ASSOCIATION__SOURCE;

	/**
	 * The feature id for the '<em><b>Target</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SIMPLE__TARGET = ASSOCIATION__TARGET;

	/**
	 * The feature id for the '<em><b>Cardinality</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SIMPLE__CARDINALITY = ASSOCIATION__CARDINALITY;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SIMPLE__NAME = ASSOCIATION__NAME;

	/**
	 * The number of structural features of the '<em>Simple</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SIMPLE_FEATURE_COUNT = ASSOCIATION_FEATURE_COUNT + 0;

	/**
	 * The meta object id for the '{@link omtg.impl.SpatialImpl <em>Spatial</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see omtg.impl.SpatialImpl
	 * @see omtg.impl.OmtgPackageImpl#getSpatial()
	 * @generated
	 */
	int SPATIAL = 28;

	/**
	 * The feature id for the '<em><b>Source</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SPATIAL__SOURCE = ASSOCIATION__SOURCE;

	/**
	 * The feature id for the '<em><b>Target</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SPATIAL__TARGET = ASSOCIATION__TARGET;

	/**
	 * The feature id for the '<em><b>Cardinality</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SPATIAL__CARDINALITY = ASSOCIATION__CARDINALITY;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SPATIAL__NAME = ASSOCIATION__NAME;

	/**
	 * The number of structural features of the '<em>Spatial</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SPATIAL_FEATURE_COUNT = ASSOCIATION_FEATURE_COUNT + 0;

	/**
	 * The meta object id for the '{@link omtg.impl.NetworkAssociationImpl <em>Network Association</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see omtg.impl.NetworkAssociationImpl
	 * @see omtg.impl.OmtgPackageImpl#getNetworkAssociation()
	 * @generated
	 */
	int NETWORK_ASSOCIATION = 29;

	/**
	 * The feature id for the '<em><b>Source</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NETWORK_ASSOCIATION__SOURCE = ASSOCIATION__SOURCE;

	/**
	 * The feature id for the '<em><b>Target</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NETWORK_ASSOCIATION__TARGET = ASSOCIATION__TARGET;

	/**
	 * The feature id for the '<em><b>Cardinality</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NETWORK_ASSOCIATION__CARDINALITY = ASSOCIATION__CARDINALITY;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NETWORK_ASSOCIATION__NAME = ASSOCIATION__NAME;

	/**
	 * The number of structural features of the '<em>Network Association</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NETWORK_ASSOCIATION_FEATURE_COUNT = ASSOCIATION_FEATURE_COUNT + 0;

	/**
	 * The meta object id for the '{@link omtg.impl.DisjointPartialImpl <em>Disjoint Partial</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see omtg.impl.DisjointPartialImpl
	 * @see omtg.impl.OmtgPackageImpl#getDisjointPartial()
	 * @generated
	 */
	int DISJOINT_PARTIAL = 30;

	/**
	 * The feature id for the '<em><b>Source</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DISJOINT_PARTIAL__SOURCE = GENERALIZATION__SOURCE;

	/**
	 * The feature id for the '<em><b>Target</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DISJOINT_PARTIAL__TARGET = GENERALIZATION__TARGET;

	/**
	 * The feature id for the '<em><b>Cardinality</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DISJOINT_PARTIAL__CARDINALITY = GENERALIZATION__CARDINALITY;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DISJOINT_PARTIAL__NAME = GENERALIZATION__NAME;

	/**
	 * The number of structural features of the '<em>Disjoint Partial</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DISJOINT_PARTIAL_FEATURE_COUNT = GENERALIZATION_FEATURE_COUNT + 0;

	/**
	 * The meta object id for the '{@link omtg.impl.DisjointTotalImpl <em>Disjoint Total</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see omtg.impl.DisjointTotalImpl
	 * @see omtg.impl.OmtgPackageImpl#getDisjointTotal()
	 * @generated
	 */
	int DISJOINT_TOTAL = 31;

	/**
	 * The feature id for the '<em><b>Source</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DISJOINT_TOTAL__SOURCE = GENERALIZATION__SOURCE;

	/**
	 * The feature id for the '<em><b>Target</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DISJOINT_TOTAL__TARGET = GENERALIZATION__TARGET;

	/**
	 * The feature id for the '<em><b>Cardinality</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DISJOINT_TOTAL__CARDINALITY = GENERALIZATION__CARDINALITY;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DISJOINT_TOTAL__NAME = GENERALIZATION__NAME;

	/**
	 * The number of structural features of the '<em>Disjoint Total</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DISJOINT_TOTAL_FEATURE_COUNT = GENERALIZATION_FEATURE_COUNT + 0;

	/**
	 * The meta object id for the '{@link omtg.impl.OverlappingPartialImpl <em>Overlapping Partial</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see omtg.impl.OverlappingPartialImpl
	 * @see omtg.impl.OmtgPackageImpl#getOverlappingPartial()
	 * @generated
	 */
	int OVERLAPPING_PARTIAL = 32;

	/**
	 * The feature id for the '<em><b>Source</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OVERLAPPING_PARTIAL__SOURCE = GENERALIZATION__SOURCE;

	/**
	 * The feature id for the '<em><b>Target</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OVERLAPPING_PARTIAL__TARGET = GENERALIZATION__TARGET;

	/**
	 * The feature id for the '<em><b>Cardinality</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OVERLAPPING_PARTIAL__CARDINALITY = GENERALIZATION__CARDINALITY;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OVERLAPPING_PARTIAL__NAME = GENERALIZATION__NAME;

	/**
	 * The number of structural features of the '<em>Overlapping Partial</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OVERLAPPING_PARTIAL_FEATURE_COUNT = GENERALIZATION_FEATURE_COUNT + 0;

	/**
	 * The meta object id for the '{@link omtg.impl.OverlappingTotalImpl <em>Overlapping Total</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see omtg.impl.OverlappingTotalImpl
	 * @see omtg.impl.OmtgPackageImpl#getOverlappingTotal()
	 * @generated
	 */
	int OVERLAPPING_TOTAL = 33;

	/**
	 * The feature id for the '<em><b>Source</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OVERLAPPING_TOTAL__SOURCE = GENERALIZATION__SOURCE;

	/**
	 * The feature id for the '<em><b>Target</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OVERLAPPING_TOTAL__TARGET = GENERALIZATION__TARGET;

	/**
	 * The feature id for the '<em><b>Cardinality</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OVERLAPPING_TOTAL__CARDINALITY = GENERALIZATION__CARDINALITY;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OVERLAPPING_TOTAL__NAME = GENERALIZATION__NAME;

	/**
	 * The number of structural features of the '<em>Overlapping Total</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OVERLAPPING_TOTAL_FEATURE_COUNT = GENERALIZATION_FEATURE_COUNT + 0;

	/**
	 * The meta object id for the '{@link omtg.impl.ShapeImpl <em>Shape</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see omtg.impl.ShapeImpl
	 * @see omtg.impl.OmtgPackageImpl#getShape()
	 * @generated
	 */
	int SHAPE = 34;

	/**
	 * The feature id for the '<em><b>Source</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SHAPE__SOURCE = CARTOGRAPHIC_GENERALIZATION__SOURCE;

	/**
	 * The feature id for the '<em><b>Target</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SHAPE__TARGET = CARTOGRAPHIC_GENERALIZATION__TARGET;

	/**
	 * The feature id for the '<em><b>Cardinality</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SHAPE__CARDINALITY = CARTOGRAPHIC_GENERALIZATION__CARDINALITY;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SHAPE__NAME = CARTOGRAPHIC_GENERALIZATION__NAME;

	/**
	 * The number of structural features of the '<em>Shape</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SHAPE_FEATURE_COUNT = CARTOGRAPHIC_GENERALIZATION_FEATURE_COUNT + 0;

	/**
	 * The meta object id for the '{@link omtg.impl.ScaleImpl <em>Scale</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see omtg.impl.ScaleImpl
	 * @see omtg.impl.OmtgPackageImpl#getScale()
	 * @generated
	 */
	int SCALE = 35;

	/**
	 * The feature id for the '<em><b>Source</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SCALE__SOURCE = CARTOGRAPHIC_GENERALIZATION__SOURCE;

	/**
	 * The feature id for the '<em><b>Target</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SCALE__TARGET = CARTOGRAPHIC_GENERALIZATION__TARGET;

	/**
	 * The feature id for the '<em><b>Cardinality</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SCALE__CARDINALITY = CARTOGRAPHIC_GENERALIZATION__CARDINALITY;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SCALE__NAME = CARTOGRAPHIC_GENERALIZATION__NAME;

	/**
	 * The number of structural features of the '<em>Scale</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SCALE_FEATURE_COUNT = CARTOGRAPHIC_GENERALIZATION_FEATURE_COUNT + 0;

	/**
	 * The meta object id for the '{@link omtg.generalDataTypes <em>general Data Types</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see omtg.generalDataTypes
	 * @see omtg.impl.OmtgPackageImpl#getgeneralDataTypes()
	 * @generated
	 */
	int GENERAL_DATA_TYPES = 36;

	/**
	 * The meta object id for the '{@link omtg.Cardinality <em>Cardinality</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see omtg.Cardinality
	 * @see omtg.impl.OmtgPackageImpl#getCardinality()
	 * @generated
	 */
	int CARDINALITY = 37;

	/**
	 * The meta object id for the '{@link omtg.visibilityTypes <em>visibility Types</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see omtg.visibilityTypes
	 * @see omtg.impl.OmtgPackageImpl#getvisibilityTypes()
	 * @generated
	 */
	int VISIBILITY_TYPES = 38;


	/**
	 * Returns the meta object for class '{@link omtg.Schema <em>Schema</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Schema</em>'.
	 * @see omtg.Schema
	 * @generated
	 */
	EClass getSchema();

	/**
	 * Returns the meta object for the containment reference list '{@link omtg.Schema#getClass_ <em>Class</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Class</em>'.
	 * @see omtg.Schema#getClass_()
	 * @see #getSchema()
	 * @generated
	 */
	EReference getSchema_Class();

	/**
	 * Returns the meta object for the reference list '{@link omtg.Schema#getInvokeClass <em>Invoke Class</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Invoke Class</em>'.
	 * @see omtg.Schema#getInvokeClass()
	 * @see #getSchema()
	 * @generated
	 */
	EReference getSchema_InvokeClass();

	/**
	 * Returns the meta object for the containment reference list '{@link omtg.Schema#getRelationship <em>Relationship</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Relationship</em>'.
	 * @see omtg.Schema#getRelationship()
	 * @see #getSchema()
	 * @generated
	 */
	EReference getSchema_Relationship();

	/**
	 * Returns the meta object for the attribute '{@link omtg.Schema#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see omtg.Schema#getName()
	 * @see #getSchema()
	 * @generated
	 */
	EAttribute getSchema_Name();

	/**
	 * Returns the meta object for class '{@link omtg.element <em>element</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>element</em>'.
	 * @see omtg.element
	 * @generated
	 */
	EClass getelement();

	/**
	 * Returns the meta object for the attribute '{@link omtg.element#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see omtg.element#getName()
	 * @see #getelement()
	 * @generated
	 */
	EAttribute getelement_Name();

	/**
	 * Returns the meta object for class '{@link omtg.Conventional <em>Conventional</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Conventional</em>'.
	 * @see omtg.Conventional
	 * @generated
	 */
	EClass getConventional();

	/**
	 * Returns the meta object for the containment reference list '{@link omtg.Conventional#getMethod <em>Method</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Method</em>'.
	 * @see omtg.Conventional#getMethod()
	 * @see #getConventional()
	 * @generated
	 */
	EReference getConventional_Method();

	/**
	 * Returns the meta object for class '{@link omtg.Attribute <em>Attribute</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Attribute</em>'.
	 * @see omtg.Attribute
	 * @generated
	 */
	EClass getAttribute();

	/**
	 * Returns the meta object for the attribute '{@link omtg.Attribute#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see omtg.Attribute#getName()
	 * @see #getAttribute()
	 * @generated
	 */
	EAttribute getAttribute_Name();

	/**
	 * Returns the meta object for the attribute '{@link omtg.Attribute#getType <em>Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Type</em>'.
	 * @see omtg.Attribute#getType()
	 * @see #getAttribute()
	 * @generated
	 */
	EAttribute getAttribute_Type();

	/**
	 * Returns the meta object for the attribute '{@link omtg.Attribute#getVisibility <em>Visibility</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Visibility</em>'.
	 * @see omtg.Attribute#getVisibility()
	 * @see #getAttribute()
	 * @generated
	 */
	EAttribute getAttribute_Visibility();

	/**
	 * Returns the meta object for the attribute '{@link omtg.Attribute#isIsIdentificable <em>Is Identificable</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Is Identificable</em>'.
	 * @see omtg.Attribute#isIsIdentificable()
	 * @see #getAttribute()
	 * @generated
	 */
	EAttribute getAttribute_IsIdentificable();

	/**
	 * Returns the meta object for class '{@link omtg.Method <em>Method</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Method</em>'.
	 * @see omtg.Method
	 * @generated
	 */
	EClass getMethod();

	/**
	 * Returns the meta object for the attribute '{@link omtg.Method#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see omtg.Method#getName()
	 * @see #getMethod()
	 * @generated
	 */
	EAttribute getMethod_Name();

	/**
	 * Returns the meta object for the attribute '{@link omtg.Method#getVisibility <em>Visibility</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Visibility</em>'.
	 * @see omtg.Method#getVisibility()
	 * @see #getMethod()
	 * @generated
	 */
	EAttribute getMethod_Visibility();

	/**
	 * Returns the meta object for the attribute '{@link omtg.Method#getReturn <em>Return</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Return</em>'.
	 * @see omtg.Method#getReturn()
	 * @see #getMethod()
	 * @generated
	 */
	EAttribute getMethod_Return();

	/**
	 * Returns the meta object for the attribute '{@link omtg.Method#getAttibutes <em>Attibutes</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Attibutes</em>'.
	 * @see omtg.Method#getAttibutes()
	 * @see #getMethod()
	 * @generated
	 */
	EAttribute getMethod_Attibutes();

	/**
	 * Returns the meta object for class '{@link omtg.geoField <em>geo Field</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>geo Field</em>'.
	 * @see omtg.geoField
	 * @generated
	 */
	EClass getgeoField();

	/**
	 * Returns the meta object for class '{@link omtg.geoObject <em>geo Object</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>geo Object</em>'.
	 * @see omtg.geoObject
	 * @generated
	 */
	EClass getgeoObject();

	/**
	 * Returns the meta object for class '{@link omtg.NetworkClass <em>Network Class</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Network Class</em>'.
	 * @see omtg.NetworkClass
	 * @generated
	 */
	EClass getNetworkClass();

	/**
	 * Returns the meta object for class '{@link omtg.Sampling <em>Sampling</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Sampling</em>'.
	 * @see omtg.Sampling
	 * @generated
	 */
	EClass getSampling();

	/**
	 * Returns the meta object for class '{@link omtg.geoObjectWithGeometry <em>geo Object With Geometry</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>geo Object With Geometry</em>'.
	 * @see omtg.geoObjectWithGeometry
	 * @generated
	 */
	EClass getgeoObjectWithGeometry();

	/**
	 * Returns the meta object for class '{@link omtg.AdjacentPolygons <em>Adjacent Polygons</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Adjacent Polygons</em>'.
	 * @see omtg.AdjacentPolygons
	 * @generated
	 */
	EClass getAdjacentPolygons();

	/**
	 * Returns the meta object for class '{@link omtg.Tesselation <em>Tesselation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Tesselation</em>'.
	 * @see omtg.Tesselation
	 * @generated
	 */
	EClass getTesselation();

	/**
	 * Returns the meta object for class '{@link omtg.Isoline <em>Isoline</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Isoline</em>'.
	 * @see omtg.Isoline
	 * @generated
	 */
	EClass getIsoline();

	/**
	 * Returns the meta object for class '{@link omtg.Polygon <em>Polygon</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Polygon</em>'.
	 * @see omtg.Polygon
	 * @generated
	 */
	EClass getPolygon();

	/**
	 * Returns the meta object for class '{@link omtg.Point <em>Point</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Point</em>'.
	 * @see omtg.Point
	 * @generated
	 */
	EClass getPoint();

	/**
	 * Returns the meta object for class '{@link omtg.Line <em>Line</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Line</em>'.
	 * @see omtg.Line
	 * @generated
	 */
	EClass getLine();

	/**
	 * Returns the meta object for class '{@link omtg.geoObjectWithGeometryAndTopology <em>geo Object With Geometry And Topology</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>geo Object With Geometry And Topology</em>'.
	 * @see omtg.geoObjectWithGeometryAndTopology
	 * @generated
	 */
	EClass getgeoObjectWithGeometryAndTopology();

	/**
	 * Returns the meta object for class '{@link omtg.Node <em>Node</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Node</em>'.
	 * @see omtg.Node
	 * @generated
	 */
	EClass getNode();

	/**
	 * Returns the meta object for class '{@link omtg.UnidirectionalLine <em>Unidirectional Line</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Unidirectional Line</em>'.
	 * @see omtg.UnidirectionalLine
	 * @generated
	 */
	EClass getUnidirectionalLine();

	/**
	 * Returns the meta object for class '{@link omtg.BidirectionalLine <em>Bidirectional Line</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Bidirectional Line</em>'.
	 * @see omtg.BidirectionalLine
	 * @generated
	 */
	EClass getBidirectionalLine();

	/**
	 * Returns the meta object for class '{@link omtg.baseRelationship <em>base Relationship</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>base Relationship</em>'.
	 * @see omtg.baseRelationship
	 * @generated
	 */
	EClass getbaseRelationship();

	/**
	 * Returns the meta object for the reference '{@link omtg.baseRelationship#getSource <em>Source</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Source</em>'.
	 * @see omtg.baseRelationship#getSource()
	 * @see #getbaseRelationship()
	 * @generated
	 */
	EReference getbaseRelationship_Source();

	/**
	 * Returns the meta object for the reference '{@link omtg.baseRelationship#getTarget <em>Target</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Target</em>'.
	 * @see omtg.baseRelationship#getTarget()
	 * @see #getbaseRelationship()
	 * @generated
	 */
	EReference getbaseRelationship_Target();

	/**
	 * Returns the meta object for the attribute '{@link omtg.baseRelationship#getCardinality <em>Cardinality</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Cardinality</em>'.
	 * @see omtg.baseRelationship#getCardinality()
	 * @see #getbaseRelationship()
	 * @generated
	 */
	EAttribute getbaseRelationship_Cardinality();

	/**
	 * Returns the meta object for the attribute '{@link omtg.baseRelationship#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see omtg.baseRelationship#getName()
	 * @see #getbaseRelationship()
	 * @generated
	 */
	EAttribute getbaseRelationship_Name();

	/**
	 * Returns the meta object for class '{@link omtg.association <em>association</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>association</em>'.
	 * @see omtg.association
	 * @generated
	 */
	EClass getassociation();

	/**
	 * Returns the meta object for class '{@link omtg.attributeSupport <em>attribute Support</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>attribute Support</em>'.
	 * @see omtg.attributeSupport
	 * @generated
	 */
	EClass getattributeSupport();

	/**
	 * Returns the meta object for the containment reference list '{@link omtg.attributeSupport#getAttribute <em>Attribute</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Attribute</em>'.
	 * @see omtg.attributeSupport#getAttribute()
	 * @see #getattributeSupport()
	 * @generated
	 */
	EReference getattributeSupport_Attribute();

	/**
	 * Returns the meta object for class '{@link omtg.generalization <em>generalization</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>generalization</em>'.
	 * @see omtg.generalization
	 * @generated
	 */
	EClass getgeneralization();

	/**
	 * Returns the meta object for class '{@link omtg.Agregation <em>Agregation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Agregation</em>'.
	 * @see omtg.Agregation
	 * @generated
	 */
	EClass getAgregation();

	/**
	 * Returns the meta object for class '{@link omtg.SpatialAgregation <em>Spatial Agregation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Spatial Agregation</em>'.
	 * @see omtg.SpatialAgregation
	 * @generated
	 */
	EClass getSpatialAgregation();

	/**
	 * Returns the meta object for class '{@link omtg.cartographicGeneralization <em>cartographic Generalization</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>cartographic Generalization</em>'.
	 * @see omtg.cartographicGeneralization
	 * @generated
	 */
	EClass getcartographicGeneralization();

	/**
	 * Returns the meta object for class '{@link omtg.Simple <em>Simple</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Simple</em>'.
	 * @see omtg.Simple
	 * @generated
	 */
	EClass getSimple();

	/**
	 * Returns the meta object for class '{@link omtg.Spatial <em>Spatial</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Spatial</em>'.
	 * @see omtg.Spatial
	 * @generated
	 */
	EClass getSpatial();

	/**
	 * Returns the meta object for class '{@link omtg.NetworkAssociation <em>Network Association</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Network Association</em>'.
	 * @see omtg.NetworkAssociation
	 * @generated
	 */
	EClass getNetworkAssociation();

	/**
	 * Returns the meta object for class '{@link omtg.DisjointPartial <em>Disjoint Partial</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Disjoint Partial</em>'.
	 * @see omtg.DisjointPartial
	 * @generated
	 */
	EClass getDisjointPartial();

	/**
	 * Returns the meta object for class '{@link omtg.DisjointTotal <em>Disjoint Total</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Disjoint Total</em>'.
	 * @see omtg.DisjointTotal
	 * @generated
	 */
	EClass getDisjointTotal();

	/**
	 * Returns the meta object for class '{@link omtg.OverlappingPartial <em>Overlapping Partial</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Overlapping Partial</em>'.
	 * @see omtg.OverlappingPartial
	 * @generated
	 */
	EClass getOverlappingPartial();

	/**
	 * Returns the meta object for class '{@link omtg.OverlappingTotal <em>Overlapping Total</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Overlapping Total</em>'.
	 * @see omtg.OverlappingTotal
	 * @generated
	 */
	EClass getOverlappingTotal();

	/**
	 * Returns the meta object for class '{@link omtg.Shape <em>Shape</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Shape</em>'.
	 * @see omtg.Shape
	 * @generated
	 */
	EClass getShape();

	/**
	 * Returns the meta object for class '{@link omtg.Scale <em>Scale</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Scale</em>'.
	 * @see omtg.Scale
	 * @generated
	 */
	EClass getScale();

	/**
	 * Returns the meta object for enum '{@link omtg.generalDataTypes <em>general Data Types</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>general Data Types</em>'.
	 * @see omtg.generalDataTypes
	 * @generated
	 */
	EEnum getgeneralDataTypes();

	/**
	 * Returns the meta object for enum '{@link omtg.Cardinality <em>Cardinality</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Cardinality</em>'.
	 * @see omtg.Cardinality
	 * @generated
	 */
	EEnum getCardinality();

	/**
	 * Returns the meta object for enum '{@link omtg.visibilityTypes <em>visibility Types</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>visibility Types</em>'.
	 * @see omtg.visibilityTypes
	 * @generated
	 */
	EEnum getvisibilityTypes();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	OmtgFactory getOmtgFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link omtg.impl.SchemaImpl <em>Schema</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see omtg.impl.SchemaImpl
		 * @see omtg.impl.OmtgPackageImpl#getSchema()
		 * @generated
		 */
		EClass SCHEMA = eINSTANCE.getSchema();

		/**
		 * The meta object literal for the '<em><b>Class</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SCHEMA__CLASS = eINSTANCE.getSchema_Class();

		/**
		 * The meta object literal for the '<em><b>Invoke Class</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SCHEMA__INVOKE_CLASS = eINSTANCE.getSchema_InvokeClass();

		/**
		 * The meta object literal for the '<em><b>Relationship</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SCHEMA__RELATIONSHIP = eINSTANCE.getSchema_Relationship();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SCHEMA__NAME = eINSTANCE.getSchema_Name();

		/**
		 * The meta object literal for the '{@link omtg.impl.elementImpl <em>element</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see omtg.impl.elementImpl
		 * @see omtg.impl.OmtgPackageImpl#getelement()
		 * @generated
		 */
		EClass ELEMENT = eINSTANCE.getelement();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ELEMENT__NAME = eINSTANCE.getelement_Name();

		/**
		 * The meta object literal for the '{@link omtg.impl.ConventionalImpl <em>Conventional</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see omtg.impl.ConventionalImpl
		 * @see omtg.impl.OmtgPackageImpl#getConventional()
		 * @generated
		 */
		EClass CONVENTIONAL = eINSTANCE.getConventional();

		/**
		 * The meta object literal for the '<em><b>Method</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CONVENTIONAL__METHOD = eINSTANCE.getConventional_Method();

		/**
		 * The meta object literal for the '{@link omtg.impl.AttributeImpl <em>Attribute</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see omtg.impl.AttributeImpl
		 * @see omtg.impl.OmtgPackageImpl#getAttribute()
		 * @generated
		 */
		EClass ATTRIBUTE = eINSTANCE.getAttribute();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ATTRIBUTE__NAME = eINSTANCE.getAttribute_Name();

		/**
		 * The meta object literal for the '<em><b>Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ATTRIBUTE__TYPE = eINSTANCE.getAttribute_Type();

		/**
		 * The meta object literal for the '<em><b>Visibility</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ATTRIBUTE__VISIBILITY = eINSTANCE.getAttribute_Visibility();

		/**
		 * The meta object literal for the '<em><b>Is Identificable</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ATTRIBUTE__IS_IDENTIFICABLE = eINSTANCE.getAttribute_IsIdentificable();

		/**
		 * The meta object literal for the '{@link omtg.impl.MethodImpl <em>Method</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see omtg.impl.MethodImpl
		 * @see omtg.impl.OmtgPackageImpl#getMethod()
		 * @generated
		 */
		EClass METHOD = eINSTANCE.getMethod();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute METHOD__NAME = eINSTANCE.getMethod_Name();

		/**
		 * The meta object literal for the '<em><b>Visibility</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute METHOD__VISIBILITY = eINSTANCE.getMethod_Visibility();

		/**
		 * The meta object literal for the '<em><b>Return</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute METHOD__RETURN = eINSTANCE.getMethod_Return();

		/**
		 * The meta object literal for the '<em><b>Attibutes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute METHOD__ATTIBUTES = eINSTANCE.getMethod_Attibutes();

		/**
		 * The meta object literal for the '{@link omtg.impl.geoFieldImpl <em>geo Field</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see omtg.impl.geoFieldImpl
		 * @see omtg.impl.OmtgPackageImpl#getgeoField()
		 * @generated
		 */
		EClass GEO_FIELD = eINSTANCE.getgeoField();

		/**
		 * The meta object literal for the '{@link omtg.impl.geoObjectImpl <em>geo Object</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see omtg.impl.geoObjectImpl
		 * @see omtg.impl.OmtgPackageImpl#getgeoObject()
		 * @generated
		 */
		EClass GEO_OBJECT = eINSTANCE.getgeoObject();

		/**
		 * The meta object literal for the '{@link omtg.impl.NetworkClassImpl <em>Network Class</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see omtg.impl.NetworkClassImpl
		 * @see omtg.impl.OmtgPackageImpl#getNetworkClass()
		 * @generated
		 */
		EClass NETWORK_CLASS = eINSTANCE.getNetworkClass();

		/**
		 * The meta object literal for the '{@link omtg.impl.SamplingImpl <em>Sampling</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see omtg.impl.SamplingImpl
		 * @see omtg.impl.OmtgPackageImpl#getSampling()
		 * @generated
		 */
		EClass SAMPLING = eINSTANCE.getSampling();

		/**
		 * The meta object literal for the '{@link omtg.impl.geoObjectWithGeometryImpl <em>geo Object With Geometry</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see omtg.impl.geoObjectWithGeometryImpl
		 * @see omtg.impl.OmtgPackageImpl#getgeoObjectWithGeometry()
		 * @generated
		 */
		EClass GEO_OBJECT_WITH_GEOMETRY = eINSTANCE.getgeoObjectWithGeometry();

		/**
		 * The meta object literal for the '{@link omtg.impl.AdjacentPolygonsImpl <em>Adjacent Polygons</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see omtg.impl.AdjacentPolygonsImpl
		 * @see omtg.impl.OmtgPackageImpl#getAdjacentPolygons()
		 * @generated
		 */
		EClass ADJACENT_POLYGONS = eINSTANCE.getAdjacentPolygons();

		/**
		 * The meta object literal for the '{@link omtg.impl.TesselationImpl <em>Tesselation</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see omtg.impl.TesselationImpl
		 * @see omtg.impl.OmtgPackageImpl#getTesselation()
		 * @generated
		 */
		EClass TESSELATION = eINSTANCE.getTesselation();

		/**
		 * The meta object literal for the '{@link omtg.impl.IsolineImpl <em>Isoline</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see omtg.impl.IsolineImpl
		 * @see omtg.impl.OmtgPackageImpl#getIsoline()
		 * @generated
		 */
		EClass ISOLINE = eINSTANCE.getIsoline();

		/**
		 * The meta object literal for the '{@link omtg.impl.PolygonImpl <em>Polygon</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see omtg.impl.PolygonImpl
		 * @see omtg.impl.OmtgPackageImpl#getPolygon()
		 * @generated
		 */
		EClass POLYGON = eINSTANCE.getPolygon();

		/**
		 * The meta object literal for the '{@link omtg.impl.PointImpl <em>Point</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see omtg.impl.PointImpl
		 * @see omtg.impl.OmtgPackageImpl#getPoint()
		 * @generated
		 */
		EClass POINT = eINSTANCE.getPoint();

		/**
		 * The meta object literal for the '{@link omtg.impl.LineImpl <em>Line</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see omtg.impl.LineImpl
		 * @see omtg.impl.OmtgPackageImpl#getLine()
		 * @generated
		 */
		EClass LINE = eINSTANCE.getLine();

		/**
		 * The meta object literal for the '{@link omtg.impl.geoObjectWithGeometryAndTopologyImpl <em>geo Object With Geometry And Topology</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see omtg.impl.geoObjectWithGeometryAndTopologyImpl
		 * @see omtg.impl.OmtgPackageImpl#getgeoObjectWithGeometryAndTopology()
		 * @generated
		 */
		EClass GEO_OBJECT_WITH_GEOMETRY_AND_TOPOLOGY = eINSTANCE.getgeoObjectWithGeometryAndTopology();

		/**
		 * The meta object literal for the '{@link omtg.impl.NodeImpl <em>Node</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see omtg.impl.NodeImpl
		 * @see omtg.impl.OmtgPackageImpl#getNode()
		 * @generated
		 */
		EClass NODE = eINSTANCE.getNode();

		/**
		 * The meta object literal for the '{@link omtg.impl.UnidirectionalLineImpl <em>Unidirectional Line</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see omtg.impl.UnidirectionalLineImpl
		 * @see omtg.impl.OmtgPackageImpl#getUnidirectionalLine()
		 * @generated
		 */
		EClass UNIDIRECTIONAL_LINE = eINSTANCE.getUnidirectionalLine();

		/**
		 * The meta object literal for the '{@link omtg.impl.BidirectionalLineImpl <em>Bidirectional Line</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see omtg.impl.BidirectionalLineImpl
		 * @see omtg.impl.OmtgPackageImpl#getBidirectionalLine()
		 * @generated
		 */
		EClass BIDIRECTIONAL_LINE = eINSTANCE.getBidirectionalLine();

		/**
		 * The meta object literal for the '{@link omtg.impl.baseRelationshipImpl <em>base Relationship</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see omtg.impl.baseRelationshipImpl
		 * @see omtg.impl.OmtgPackageImpl#getbaseRelationship()
		 * @generated
		 */
		EClass BASE_RELATIONSHIP = eINSTANCE.getbaseRelationship();

		/**
		 * The meta object literal for the '<em><b>Source</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference BASE_RELATIONSHIP__SOURCE = eINSTANCE.getbaseRelationship_Source();

		/**
		 * The meta object literal for the '<em><b>Target</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference BASE_RELATIONSHIP__TARGET = eINSTANCE.getbaseRelationship_Target();

		/**
		 * The meta object literal for the '<em><b>Cardinality</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute BASE_RELATIONSHIP__CARDINALITY = eINSTANCE.getbaseRelationship_Cardinality();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute BASE_RELATIONSHIP__NAME = eINSTANCE.getbaseRelationship_Name();

		/**
		 * The meta object literal for the '{@link omtg.impl.associationImpl <em>association</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see omtg.impl.associationImpl
		 * @see omtg.impl.OmtgPackageImpl#getassociation()
		 * @generated
		 */
		EClass ASSOCIATION = eINSTANCE.getassociation();

		/**
		 * The meta object literal for the '{@link omtg.impl.attributeSupportImpl <em>attribute Support</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see omtg.impl.attributeSupportImpl
		 * @see omtg.impl.OmtgPackageImpl#getattributeSupport()
		 * @generated
		 */
		EClass ATTRIBUTE_SUPPORT = eINSTANCE.getattributeSupport();

		/**
		 * The meta object literal for the '<em><b>Attribute</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ATTRIBUTE_SUPPORT__ATTRIBUTE = eINSTANCE.getattributeSupport_Attribute();

		/**
		 * The meta object literal for the '{@link omtg.impl.generalizationImpl <em>generalization</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see omtg.impl.generalizationImpl
		 * @see omtg.impl.OmtgPackageImpl#getgeneralization()
		 * @generated
		 */
		EClass GENERALIZATION = eINSTANCE.getgeneralization();

		/**
		 * The meta object literal for the '{@link omtg.impl.AgregationImpl <em>Agregation</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see omtg.impl.AgregationImpl
		 * @see omtg.impl.OmtgPackageImpl#getAgregation()
		 * @generated
		 */
		EClass AGREGATION = eINSTANCE.getAgregation();

		/**
		 * The meta object literal for the '{@link omtg.impl.SpatialAgregationImpl <em>Spatial Agregation</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see omtg.impl.SpatialAgregationImpl
		 * @see omtg.impl.OmtgPackageImpl#getSpatialAgregation()
		 * @generated
		 */
		EClass SPATIAL_AGREGATION = eINSTANCE.getSpatialAgregation();

		/**
		 * The meta object literal for the '{@link omtg.impl.cartographicGeneralizationImpl <em>cartographic Generalization</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see omtg.impl.cartographicGeneralizationImpl
		 * @see omtg.impl.OmtgPackageImpl#getcartographicGeneralization()
		 * @generated
		 */
		EClass CARTOGRAPHIC_GENERALIZATION = eINSTANCE.getcartographicGeneralization();

		/**
		 * The meta object literal for the '{@link omtg.impl.SimpleImpl <em>Simple</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see omtg.impl.SimpleImpl
		 * @see omtg.impl.OmtgPackageImpl#getSimple()
		 * @generated
		 */
		EClass SIMPLE = eINSTANCE.getSimple();

		/**
		 * The meta object literal for the '{@link omtg.impl.SpatialImpl <em>Spatial</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see omtg.impl.SpatialImpl
		 * @see omtg.impl.OmtgPackageImpl#getSpatial()
		 * @generated
		 */
		EClass SPATIAL = eINSTANCE.getSpatial();

		/**
		 * The meta object literal for the '{@link omtg.impl.NetworkAssociationImpl <em>Network Association</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see omtg.impl.NetworkAssociationImpl
		 * @see omtg.impl.OmtgPackageImpl#getNetworkAssociation()
		 * @generated
		 */
		EClass NETWORK_ASSOCIATION = eINSTANCE.getNetworkAssociation();

		/**
		 * The meta object literal for the '{@link omtg.impl.DisjointPartialImpl <em>Disjoint Partial</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see omtg.impl.DisjointPartialImpl
		 * @see omtg.impl.OmtgPackageImpl#getDisjointPartial()
		 * @generated
		 */
		EClass DISJOINT_PARTIAL = eINSTANCE.getDisjointPartial();

		/**
		 * The meta object literal for the '{@link omtg.impl.DisjointTotalImpl <em>Disjoint Total</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see omtg.impl.DisjointTotalImpl
		 * @see omtg.impl.OmtgPackageImpl#getDisjointTotal()
		 * @generated
		 */
		EClass DISJOINT_TOTAL = eINSTANCE.getDisjointTotal();

		/**
		 * The meta object literal for the '{@link omtg.impl.OverlappingPartialImpl <em>Overlapping Partial</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see omtg.impl.OverlappingPartialImpl
		 * @see omtg.impl.OmtgPackageImpl#getOverlappingPartial()
		 * @generated
		 */
		EClass OVERLAPPING_PARTIAL = eINSTANCE.getOverlappingPartial();

		/**
		 * The meta object literal for the '{@link omtg.impl.OverlappingTotalImpl <em>Overlapping Total</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see omtg.impl.OverlappingTotalImpl
		 * @see omtg.impl.OmtgPackageImpl#getOverlappingTotal()
		 * @generated
		 */
		EClass OVERLAPPING_TOTAL = eINSTANCE.getOverlappingTotal();

		/**
		 * The meta object literal for the '{@link omtg.impl.ShapeImpl <em>Shape</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see omtg.impl.ShapeImpl
		 * @see omtg.impl.OmtgPackageImpl#getShape()
		 * @generated
		 */
		EClass SHAPE = eINSTANCE.getShape();

		/**
		 * The meta object literal for the '{@link omtg.impl.ScaleImpl <em>Scale</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see omtg.impl.ScaleImpl
		 * @see omtg.impl.OmtgPackageImpl#getScale()
		 * @generated
		 */
		EClass SCALE = eINSTANCE.getScale();

		/**
		 * The meta object literal for the '{@link omtg.generalDataTypes <em>general Data Types</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see omtg.generalDataTypes
		 * @see omtg.impl.OmtgPackageImpl#getgeneralDataTypes()
		 * @generated
		 */
		EEnum GENERAL_DATA_TYPES = eINSTANCE.getgeneralDataTypes();

		/**
		 * The meta object literal for the '{@link omtg.Cardinality <em>Cardinality</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see omtg.Cardinality
		 * @see omtg.impl.OmtgPackageImpl#getCardinality()
		 * @generated
		 */
		EEnum CARDINALITY = eINSTANCE.getCardinality();

		/**
		 * The meta object literal for the '{@link omtg.visibilityTypes <em>visibility Types</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see omtg.visibilityTypes
		 * @see omtg.impl.OmtgPackageImpl#getvisibilityTypes()
		 * @generated
		 */
		EEnum VISIBILITY_TYPES = eINSTANCE.getvisibilityTypes();

	}

} //OmtgPackage
