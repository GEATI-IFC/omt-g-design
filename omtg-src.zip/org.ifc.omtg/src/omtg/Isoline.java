/**
 */
package omtg;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Isoline</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see omtg.OmtgPackage#getIsoline()
 * @model
 * @generated
 */
public interface Isoline extends geoField {
} // Isoline
