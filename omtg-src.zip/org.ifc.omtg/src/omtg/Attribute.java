/**
 */
package omtg;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Attribute</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link omtg.Attribute#getName <em>Name</em>}</li>
 *   <li>{@link omtg.Attribute#getType <em>Type</em>}</li>
 *   <li>{@link omtg.Attribute#getVisibility <em>Visibility</em>}</li>
 *   <li>{@link omtg.Attribute#isIsIdentificable <em>Is Identificable</em>}</li>
 * </ul>
 * </p>
 *
 * @see omtg.OmtgPackage#getAttribute()
 * @model
 * @generated
 */
public interface Attribute extends EObject {
	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see omtg.OmtgPackage#getAttribute_Name()
	 * @model required="true"
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link omtg.Attribute#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Type</b></em>' attribute.
	 * The default value is <code>"VARCHAR"</code>.
	 * The literals are from the enumeration {@link omtg.generalDataTypes}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Type</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Type</em>' attribute.
	 * @see omtg.generalDataTypes
	 * @see #setType(generalDataTypes)
	 * @see omtg.OmtgPackage#getAttribute_Type()
	 * @model default="VARCHAR" required="true"
	 * @generated
	 */
	generalDataTypes getType();

	/**
	 * Sets the value of the '{@link omtg.Attribute#getType <em>Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Type</em>' attribute.
	 * @see omtg.generalDataTypes
	 * @see #getType()
	 * @generated
	 */
	void setType(generalDataTypes value);

	/**
	 * Returns the value of the '<em><b>Visibility</b></em>' attribute.
	 * The literals are from the enumeration {@link omtg.visibilityTypes}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Visibility</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Visibility</em>' attribute.
	 * @see omtg.visibilityTypes
	 * @see #setVisibility(visibilityTypes)
	 * @see omtg.OmtgPackage#getAttribute_Visibility()
	 * @model
	 * @generated
	 */
	visibilityTypes getVisibility();

	/**
	 * Sets the value of the '{@link omtg.Attribute#getVisibility <em>Visibility</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Visibility</em>' attribute.
	 * @see omtg.visibilityTypes
	 * @see #getVisibility()
	 * @generated
	 */
	void setVisibility(visibilityTypes value);

	/**
	 * Returns the value of the '<em><b>Is Identificable</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Is Identificable</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Is Identificable</em>' attribute.
	 * @see #setIsIdentificable(boolean)
	 * @see omtg.OmtgPackage#getAttribute_IsIdentificable()
	 * @model required="true"
	 * @generated
	 */
	boolean isIsIdentificable();

	/**
	 * Sets the value of the '{@link omtg.Attribute#isIsIdentificable <em>Is Identificable</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Is Identificable</em>' attribute.
	 * @see #isIsIdentificable()
	 * @generated
	 */
	void setIsIdentificable(boolean value);

} // Attribute
