/**
 */
package omtg.util;

import omtg.*;

import org.eclipse.emf.common.notify.Adapter;
import org.eclipse.emf.common.notify.Notifier;

import org.eclipse.emf.common.notify.impl.AdapterFactoryImpl;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * The <b>Adapter Factory</b> for the model.
 * It provides an adapter <code>createXXX</code> method for each class of the model.
 * <!-- end-user-doc -->
 * @see omtg.OmtgPackage
 * @generated
 */
public class OmtgAdapterFactory extends AdapterFactoryImpl {
	/**
	 * The cached model package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static OmtgPackage modelPackage;

	/**
	 * Creates an instance of the adapter factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public OmtgAdapterFactory() {
		if (modelPackage == null) {
			modelPackage = OmtgPackage.eINSTANCE;
		}
	}

	/**
	 * Returns whether this factory is applicable for the type of the object.
	 * <!-- begin-user-doc -->
	 * This implementation returns <code>true</code> if the object is either the model's package or is an instance object of the model.
	 * <!-- end-user-doc -->
	 * @return whether this factory is applicable for the type of the object.
	 * @generated
	 */
	@Override
	public boolean isFactoryForType(Object object) {
		if (object == modelPackage) {
			return true;
		}
		if (object instanceof EObject) {
			return ((EObject)object).eClass().getEPackage() == modelPackage;
		}
		return false;
	}

	/**
	 * The switch that delegates to the <code>createXXX</code> methods.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected OmtgSwitch<Adapter> modelSwitch =
		new OmtgSwitch<Adapter>() {
			@Override
			public Adapter caseSchema(Schema object) {
				return createSchemaAdapter();
			}
			@Override
			public Adapter caseelement(element object) {
				return createelementAdapter();
			}
			@Override
			public Adapter caseConventional(Conventional object) {
				return createConventionalAdapter();
			}
			@Override
			public Adapter caseAttribute(Attribute object) {
				return createAttributeAdapter();
			}
			@Override
			public Adapter caseMethod(Method object) {
				return createMethodAdapter();
			}
			@Override
			public Adapter casegeoField(geoField object) {
				return creategeoFieldAdapter();
			}
			@Override
			public Adapter casegeoObject(geoObject object) {
				return creategeoObjectAdapter();
			}
			@Override
			public Adapter caseNetworkClass(NetworkClass object) {
				return createNetworkClassAdapter();
			}
			@Override
			public Adapter caseSampling(Sampling object) {
				return createSamplingAdapter();
			}
			@Override
			public Adapter casegeoObjectWithGeometry(geoObjectWithGeometry object) {
				return creategeoObjectWithGeometryAdapter();
			}
			@Override
			public Adapter caseAdjacentPolygons(AdjacentPolygons object) {
				return createAdjacentPolygonsAdapter();
			}
			@Override
			public Adapter caseTesselation(Tesselation object) {
				return createTesselationAdapter();
			}
			@Override
			public Adapter caseIsoline(Isoline object) {
				return createIsolineAdapter();
			}
			@Override
			public Adapter casePolygon(Polygon object) {
				return createPolygonAdapter();
			}
			@Override
			public Adapter casePoint(Point object) {
				return createPointAdapter();
			}
			@Override
			public Adapter caseLine(Line object) {
				return createLineAdapter();
			}
			@Override
			public Adapter casegeoObjectWithGeometryAndTopology(geoObjectWithGeometryAndTopology object) {
				return creategeoObjectWithGeometryAndTopologyAdapter();
			}
			@Override
			public Adapter caseNode(Node object) {
				return createNodeAdapter();
			}
			@Override
			public Adapter caseUnidirectionalLine(UnidirectionalLine object) {
				return createUnidirectionalLineAdapter();
			}
			@Override
			public Adapter caseBidirectionalLine(BidirectionalLine object) {
				return createBidirectionalLineAdapter();
			}
			@Override
			public Adapter casebaseRelationship(baseRelationship object) {
				return createbaseRelationshipAdapter();
			}
			@Override
			public Adapter caseassociation(association object) {
				return createassociationAdapter();
			}
			@Override
			public Adapter caseattributeSupport(attributeSupport object) {
				return createattributeSupportAdapter();
			}
			@Override
			public Adapter casegeneralization(generalization object) {
				return creategeneralizationAdapter();
			}
			@Override
			public Adapter caseAgregation(Agregation object) {
				return createAgregationAdapter();
			}
			@Override
			public Adapter caseSpatialAgregation(SpatialAgregation object) {
				return createSpatialAgregationAdapter();
			}
			@Override
			public Adapter casecartographicGeneralization(cartographicGeneralization object) {
				return createcartographicGeneralizationAdapter();
			}
			@Override
			public Adapter caseSimple(Simple object) {
				return createSimpleAdapter();
			}
			@Override
			public Adapter caseSpatial(Spatial object) {
				return createSpatialAdapter();
			}
			@Override
			public Adapter caseNetworkAssociation(NetworkAssociation object) {
				return createNetworkAssociationAdapter();
			}
			@Override
			public Adapter caseDisjointPartial(DisjointPartial object) {
				return createDisjointPartialAdapter();
			}
			@Override
			public Adapter caseDisjointTotal(DisjointTotal object) {
				return createDisjointTotalAdapter();
			}
			@Override
			public Adapter caseOverlappingPartial(OverlappingPartial object) {
				return createOverlappingPartialAdapter();
			}
			@Override
			public Adapter caseOverlappingTotal(OverlappingTotal object) {
				return createOverlappingTotalAdapter();
			}
			@Override
			public Adapter caseShape(Shape object) {
				return createShapeAdapter();
			}
			@Override
			public Adapter caseScale(Scale object) {
				return createScaleAdapter();
			}
			@Override
			public Adapter defaultCase(EObject object) {
				return createEObjectAdapter();
			}
		};

	/**
	 * Creates an adapter for the <code>target</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param target the object to adapt.
	 * @return the adapter for the <code>target</code>.
	 * @generated
	 */
	@Override
	public Adapter createAdapter(Notifier target) {
		return modelSwitch.doSwitch((EObject)target);
	}


	/**
	 * Creates a new adapter for an object of class '{@link omtg.Schema <em>Schema</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see omtg.Schema
	 * @generated
	 */
	public Adapter createSchemaAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link omtg.element <em>element</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see omtg.element
	 * @generated
	 */
	public Adapter createelementAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link omtg.Conventional <em>Conventional</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see omtg.Conventional
	 * @generated
	 */
	public Adapter createConventionalAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link omtg.Attribute <em>Attribute</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see omtg.Attribute
	 * @generated
	 */
	public Adapter createAttributeAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link omtg.Method <em>Method</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see omtg.Method
	 * @generated
	 */
	public Adapter createMethodAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link omtg.geoField <em>geo Field</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see omtg.geoField
	 * @generated
	 */
	public Adapter creategeoFieldAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link omtg.geoObject <em>geo Object</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see omtg.geoObject
	 * @generated
	 */
	public Adapter creategeoObjectAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link omtg.NetworkClass <em>Network Class</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see omtg.NetworkClass
	 * @generated
	 */
	public Adapter createNetworkClassAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link omtg.Sampling <em>Sampling</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see omtg.Sampling
	 * @generated
	 */
	public Adapter createSamplingAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link omtg.geoObjectWithGeometry <em>geo Object With Geometry</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see omtg.geoObjectWithGeometry
	 * @generated
	 */
	public Adapter creategeoObjectWithGeometryAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link omtg.AdjacentPolygons <em>Adjacent Polygons</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see omtg.AdjacentPolygons
	 * @generated
	 */
	public Adapter createAdjacentPolygonsAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link omtg.Tesselation <em>Tesselation</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see omtg.Tesselation
	 * @generated
	 */
	public Adapter createTesselationAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link omtg.Isoline <em>Isoline</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see omtg.Isoline
	 * @generated
	 */
	public Adapter createIsolineAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link omtg.Polygon <em>Polygon</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see omtg.Polygon
	 * @generated
	 */
	public Adapter createPolygonAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link omtg.Point <em>Point</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see omtg.Point
	 * @generated
	 */
	public Adapter createPointAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link omtg.Line <em>Line</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see omtg.Line
	 * @generated
	 */
	public Adapter createLineAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link omtg.geoObjectWithGeometryAndTopology <em>geo Object With Geometry And Topology</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see omtg.geoObjectWithGeometryAndTopology
	 * @generated
	 */
	public Adapter creategeoObjectWithGeometryAndTopologyAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link omtg.Node <em>Node</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see omtg.Node
	 * @generated
	 */
	public Adapter createNodeAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link omtg.UnidirectionalLine <em>Unidirectional Line</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see omtg.UnidirectionalLine
	 * @generated
	 */
	public Adapter createUnidirectionalLineAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link omtg.BidirectionalLine <em>Bidirectional Line</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see omtg.BidirectionalLine
	 * @generated
	 */
	public Adapter createBidirectionalLineAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link omtg.baseRelationship <em>base Relationship</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see omtg.baseRelationship
	 * @generated
	 */
	public Adapter createbaseRelationshipAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link omtg.association <em>association</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see omtg.association
	 * @generated
	 */
	public Adapter createassociationAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link omtg.attributeSupport <em>attribute Support</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see omtg.attributeSupport
	 * @generated
	 */
	public Adapter createattributeSupportAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link omtg.generalization <em>generalization</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see omtg.generalization
	 * @generated
	 */
	public Adapter creategeneralizationAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link omtg.Agregation <em>Agregation</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see omtg.Agregation
	 * @generated
	 */
	public Adapter createAgregationAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link omtg.SpatialAgregation <em>Spatial Agregation</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see omtg.SpatialAgregation
	 * @generated
	 */
	public Adapter createSpatialAgregationAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link omtg.cartographicGeneralization <em>cartographic Generalization</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see omtg.cartographicGeneralization
	 * @generated
	 */
	public Adapter createcartographicGeneralizationAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link omtg.Simple <em>Simple</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see omtg.Simple
	 * @generated
	 */
	public Adapter createSimpleAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link omtg.Spatial <em>Spatial</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see omtg.Spatial
	 * @generated
	 */
	public Adapter createSpatialAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link omtg.NetworkAssociation <em>Network Association</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see omtg.NetworkAssociation
	 * @generated
	 */
	public Adapter createNetworkAssociationAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link omtg.DisjointPartial <em>Disjoint Partial</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see omtg.DisjointPartial
	 * @generated
	 */
	public Adapter createDisjointPartialAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link omtg.DisjointTotal <em>Disjoint Total</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see omtg.DisjointTotal
	 * @generated
	 */
	public Adapter createDisjointTotalAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link omtg.OverlappingPartial <em>Overlapping Partial</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see omtg.OverlappingPartial
	 * @generated
	 */
	public Adapter createOverlappingPartialAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link omtg.OverlappingTotal <em>Overlapping Total</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see omtg.OverlappingTotal
	 * @generated
	 */
	public Adapter createOverlappingTotalAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link omtg.Shape <em>Shape</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see omtg.Shape
	 * @generated
	 */
	public Adapter createShapeAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link omtg.Scale <em>Scale</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see omtg.Scale
	 * @generated
	 */
	public Adapter createScaleAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for the default case.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @generated
	 */
	public Adapter createEObjectAdapter() {
		return null;
	}

} //OmtgAdapterFactory
