/**
 */
package omtg.util;

import omtg.*;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.util.Switch;

/**
 * <!-- begin-user-doc -->
 * The <b>Switch</b> for the model's inheritance hierarchy.
 * It supports the call {@link #doSwitch(EObject) doSwitch(object)}
 * to invoke the <code>caseXXX</code> method for each class of the model,
 * starting with the actual class of the object
 * and proceeding up the inheritance hierarchy
 * until a non-null result is returned,
 * which is the result of the switch.
 * <!-- end-user-doc -->
 * @see omtg.OmtgPackage
 * @generated
 */
public class OmtgSwitch<T> extends Switch<T> {
	/**
	 * The cached model package
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static OmtgPackage modelPackage;

	/**
	 * Creates an instance of the switch.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public OmtgSwitch() {
		if (modelPackage == null) {
			modelPackage = OmtgPackage.eINSTANCE;
		}
	}

	/**
	 * Checks whether this is a switch for the given package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @parameter ePackage the package in question.
	 * @return whether this is a switch for the given package.
	 * @generated
	 */
	@Override
	protected boolean isSwitchFor(EPackage ePackage) {
		return ePackage == modelPackage;
	}

	/**
	 * Calls <code>caseXXX</code> for each class of the model until one returns a non null result; it yields that result.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the first non-null result returned by a <code>caseXXX</code> call.
	 * @generated
	 */
	@Override
	protected T doSwitch(int classifierID, EObject theEObject) {
		switch (classifierID) {
			case OmtgPackage.SCHEMA: {
				Schema schema = (Schema)theEObject;
				T result = caseSchema(schema);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case OmtgPackage.ELEMENT: {
				element element = (element)theEObject;
				T result = caseelement(element);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case OmtgPackage.CONVENTIONAL: {
				Conventional conventional = (Conventional)theEObject;
				T result = caseConventional(conventional);
				if (result == null) result = caseelement(conventional);
				if (result == null) result = caseattributeSupport(conventional);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case OmtgPackage.ATTRIBUTE: {
				Attribute attribute = (Attribute)theEObject;
				T result = caseAttribute(attribute);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case OmtgPackage.METHOD: {
				Method method = (Method)theEObject;
				T result = caseMethod(method);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case OmtgPackage.GEO_FIELD: {
				geoField geoField = (geoField)theEObject;
				T result = casegeoField(geoField);
				if (result == null) result = caseConventional(geoField);
				if (result == null) result = caseelement(geoField);
				if (result == null) result = caseattributeSupport(geoField);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case OmtgPackage.GEO_OBJECT: {
				geoObject geoObject = (geoObject)theEObject;
				T result = casegeoObject(geoObject);
				if (result == null) result = caseConventional(geoObject);
				if (result == null) result = caseelement(geoObject);
				if (result == null) result = caseattributeSupport(geoObject);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case OmtgPackage.NETWORK_CLASS: {
				NetworkClass networkClass = (NetworkClass)theEObject;
				T result = caseNetworkClass(networkClass);
				if (result == null) result = casegeoField(networkClass);
				if (result == null) result = caseConventional(networkClass);
				if (result == null) result = caseelement(networkClass);
				if (result == null) result = caseattributeSupport(networkClass);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case OmtgPackage.SAMPLING: {
				Sampling sampling = (Sampling)theEObject;
				T result = caseSampling(sampling);
				if (result == null) result = casegeoField(sampling);
				if (result == null) result = caseConventional(sampling);
				if (result == null) result = caseelement(sampling);
				if (result == null) result = caseattributeSupport(sampling);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case OmtgPackage.GEO_OBJECT_WITH_GEOMETRY: {
				geoObjectWithGeometry geoObjectWithGeometry = (geoObjectWithGeometry)theEObject;
				T result = casegeoObjectWithGeometry(geoObjectWithGeometry);
				if (result == null) result = casegeoObject(geoObjectWithGeometry);
				if (result == null) result = caseConventional(geoObjectWithGeometry);
				if (result == null) result = caseelement(geoObjectWithGeometry);
				if (result == null) result = caseattributeSupport(geoObjectWithGeometry);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case OmtgPackage.ADJACENT_POLYGONS: {
				AdjacentPolygons adjacentPolygons = (AdjacentPolygons)theEObject;
				T result = caseAdjacentPolygons(adjacentPolygons);
				if (result == null) result = casegeoField(adjacentPolygons);
				if (result == null) result = caseConventional(adjacentPolygons);
				if (result == null) result = caseelement(adjacentPolygons);
				if (result == null) result = caseattributeSupport(adjacentPolygons);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case OmtgPackage.TESSELATION: {
				Tesselation tesselation = (Tesselation)theEObject;
				T result = caseTesselation(tesselation);
				if (result == null) result = casegeoField(tesselation);
				if (result == null) result = caseConventional(tesselation);
				if (result == null) result = caseelement(tesselation);
				if (result == null) result = caseattributeSupport(tesselation);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case OmtgPackage.ISOLINE: {
				Isoline isoline = (Isoline)theEObject;
				T result = caseIsoline(isoline);
				if (result == null) result = casegeoField(isoline);
				if (result == null) result = caseConventional(isoline);
				if (result == null) result = caseelement(isoline);
				if (result == null) result = caseattributeSupport(isoline);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case OmtgPackage.POLYGON: {
				Polygon polygon = (Polygon)theEObject;
				T result = casePolygon(polygon);
				if (result == null) result = casegeoObjectWithGeometry(polygon);
				if (result == null) result = casegeoObject(polygon);
				if (result == null) result = caseConventional(polygon);
				if (result == null) result = caseelement(polygon);
				if (result == null) result = caseattributeSupport(polygon);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case OmtgPackage.POINT: {
				Point point = (Point)theEObject;
				T result = casePoint(point);
				if (result == null) result = casegeoObjectWithGeometry(point);
				if (result == null) result = casegeoObject(point);
				if (result == null) result = caseConventional(point);
				if (result == null) result = caseelement(point);
				if (result == null) result = caseattributeSupport(point);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case OmtgPackage.LINE: {
				Line line = (Line)theEObject;
				T result = caseLine(line);
				if (result == null) result = casegeoObjectWithGeometry(line);
				if (result == null) result = casegeoObject(line);
				if (result == null) result = caseConventional(line);
				if (result == null) result = caseelement(line);
				if (result == null) result = caseattributeSupport(line);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case OmtgPackage.GEO_OBJECT_WITH_GEOMETRY_AND_TOPOLOGY: {
				geoObjectWithGeometryAndTopology geoObjectWithGeometryAndTopology = (geoObjectWithGeometryAndTopology)theEObject;
				T result = casegeoObjectWithGeometryAndTopology(geoObjectWithGeometryAndTopology);
				if (result == null) result = casegeoObject(geoObjectWithGeometryAndTopology);
				if (result == null) result = caseConventional(geoObjectWithGeometryAndTopology);
				if (result == null) result = caseelement(geoObjectWithGeometryAndTopology);
				if (result == null) result = caseattributeSupport(geoObjectWithGeometryAndTopology);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case OmtgPackage.NODE: {
				Node node = (Node)theEObject;
				T result = caseNode(node);
				if (result == null) result = casegeoObjectWithGeometryAndTopology(node);
				if (result == null) result = casegeoObject(node);
				if (result == null) result = caseConventional(node);
				if (result == null) result = caseelement(node);
				if (result == null) result = caseattributeSupport(node);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case OmtgPackage.UNIDIRECTIONAL_LINE: {
				UnidirectionalLine unidirectionalLine = (UnidirectionalLine)theEObject;
				T result = caseUnidirectionalLine(unidirectionalLine);
				if (result == null) result = casegeoObjectWithGeometryAndTopology(unidirectionalLine);
				if (result == null) result = casegeoObject(unidirectionalLine);
				if (result == null) result = caseConventional(unidirectionalLine);
				if (result == null) result = caseelement(unidirectionalLine);
				if (result == null) result = caseattributeSupport(unidirectionalLine);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case OmtgPackage.BIDIRECTIONAL_LINE: {
				BidirectionalLine bidirectionalLine = (BidirectionalLine)theEObject;
				T result = caseBidirectionalLine(bidirectionalLine);
				if (result == null) result = casegeoObjectWithGeometryAndTopology(bidirectionalLine);
				if (result == null) result = casegeoObject(bidirectionalLine);
				if (result == null) result = caseConventional(bidirectionalLine);
				if (result == null) result = caseelement(bidirectionalLine);
				if (result == null) result = caseattributeSupport(bidirectionalLine);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case OmtgPackage.BASE_RELATIONSHIP: {
				baseRelationship baseRelationship = (baseRelationship)theEObject;
				T result = casebaseRelationship(baseRelationship);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case OmtgPackage.ASSOCIATION: {
				association association = (association)theEObject;
				T result = caseassociation(association);
				if (result == null) result = casebaseRelationship(association);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case OmtgPackage.ATTRIBUTE_SUPPORT: {
				attributeSupport attributeSupport = (attributeSupport)theEObject;
				T result = caseattributeSupport(attributeSupport);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case OmtgPackage.GENERALIZATION: {
				generalization generalization = (generalization)theEObject;
				T result = casegeneralization(generalization);
				if (result == null) result = casebaseRelationship(generalization);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case OmtgPackage.AGREGATION: {
				Agregation agregation = (Agregation)theEObject;
				T result = caseAgregation(agregation);
				if (result == null) result = casebaseRelationship(agregation);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case OmtgPackage.SPATIAL_AGREGATION: {
				SpatialAgregation spatialAgregation = (SpatialAgregation)theEObject;
				T result = caseSpatialAgregation(spatialAgregation);
				if (result == null) result = casebaseRelationship(spatialAgregation);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case OmtgPackage.CARTOGRAPHIC_GENERALIZATION: {
				cartographicGeneralization cartographicGeneralization = (cartographicGeneralization)theEObject;
				T result = casecartographicGeneralization(cartographicGeneralization);
				if (result == null) result = casebaseRelationship(cartographicGeneralization);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case OmtgPackage.SIMPLE: {
				Simple simple = (Simple)theEObject;
				T result = caseSimple(simple);
				if (result == null) result = caseassociation(simple);
				if (result == null) result = casebaseRelationship(simple);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case OmtgPackage.SPATIAL: {
				Spatial spatial = (Spatial)theEObject;
				T result = caseSpatial(spatial);
				if (result == null) result = caseassociation(spatial);
				if (result == null) result = casebaseRelationship(spatial);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case OmtgPackage.NETWORK_ASSOCIATION: {
				NetworkAssociation networkAssociation = (NetworkAssociation)theEObject;
				T result = caseNetworkAssociation(networkAssociation);
				if (result == null) result = caseassociation(networkAssociation);
				if (result == null) result = casebaseRelationship(networkAssociation);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case OmtgPackage.DISJOINT_PARTIAL: {
				DisjointPartial disjointPartial = (DisjointPartial)theEObject;
				T result = caseDisjointPartial(disjointPartial);
				if (result == null) result = casegeneralization(disjointPartial);
				if (result == null) result = casebaseRelationship(disjointPartial);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case OmtgPackage.DISJOINT_TOTAL: {
				DisjointTotal disjointTotal = (DisjointTotal)theEObject;
				T result = caseDisjointTotal(disjointTotal);
				if (result == null) result = casegeneralization(disjointTotal);
				if (result == null) result = casebaseRelationship(disjointTotal);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case OmtgPackage.OVERLAPPING_PARTIAL: {
				OverlappingPartial overlappingPartial = (OverlappingPartial)theEObject;
				T result = caseOverlappingPartial(overlappingPartial);
				if (result == null) result = casegeneralization(overlappingPartial);
				if (result == null) result = casebaseRelationship(overlappingPartial);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case OmtgPackage.OVERLAPPING_TOTAL: {
				OverlappingTotal overlappingTotal = (OverlappingTotal)theEObject;
				T result = caseOverlappingTotal(overlappingTotal);
				if (result == null) result = casegeneralization(overlappingTotal);
				if (result == null) result = casebaseRelationship(overlappingTotal);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case OmtgPackage.SHAPE: {
				Shape shape = (Shape)theEObject;
				T result = caseShape(shape);
				if (result == null) result = casecartographicGeneralization(shape);
				if (result == null) result = casebaseRelationship(shape);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case OmtgPackage.SCALE: {
				Scale scale = (Scale)theEObject;
				T result = caseScale(scale);
				if (result == null) result = casecartographicGeneralization(scale);
				if (result == null) result = casebaseRelationship(scale);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			default: return defaultCase(theEObject);
		}
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Schema</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Schema</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseSchema(Schema object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>element</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>element</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseelement(element object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Conventional</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Conventional</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseConventional(Conventional object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Attribute</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Attribute</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseAttribute(Attribute object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Method</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Method</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseMethod(Method object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>geo Field</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>geo Field</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T casegeoField(geoField object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>geo Object</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>geo Object</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T casegeoObject(geoObject object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Network Class</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Network Class</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseNetworkClass(NetworkClass object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Sampling</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Sampling</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseSampling(Sampling object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>geo Object With Geometry</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>geo Object With Geometry</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T casegeoObjectWithGeometry(geoObjectWithGeometry object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Adjacent Polygons</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Adjacent Polygons</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseAdjacentPolygons(AdjacentPolygons object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Tesselation</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Tesselation</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseTesselation(Tesselation object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Isoline</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Isoline</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseIsoline(Isoline object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Polygon</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Polygon</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T casePolygon(Polygon object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Point</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Point</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T casePoint(Point object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Line</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Line</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseLine(Line object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>geo Object With Geometry And Topology</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>geo Object With Geometry And Topology</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T casegeoObjectWithGeometryAndTopology(geoObjectWithGeometryAndTopology object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Node</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Node</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseNode(Node object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Unidirectional Line</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Unidirectional Line</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseUnidirectionalLine(UnidirectionalLine object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Bidirectional Line</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Bidirectional Line</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseBidirectionalLine(BidirectionalLine object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>base Relationship</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>base Relationship</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T casebaseRelationship(baseRelationship object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>association</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>association</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseassociation(association object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>attribute Support</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>attribute Support</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseattributeSupport(attributeSupport object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>generalization</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>generalization</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T casegeneralization(generalization object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Agregation</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Agregation</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseAgregation(Agregation object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Spatial Agregation</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Spatial Agregation</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseSpatialAgregation(SpatialAgregation object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>cartographic Generalization</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>cartographic Generalization</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T casecartographicGeneralization(cartographicGeneralization object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Simple</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Simple</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseSimple(Simple object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Spatial</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Spatial</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseSpatial(Spatial object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Network Association</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Network Association</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseNetworkAssociation(NetworkAssociation object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Disjoint Partial</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Disjoint Partial</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseDisjointPartial(DisjointPartial object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Disjoint Total</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Disjoint Total</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseDisjointTotal(DisjointTotal object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Overlapping Partial</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Overlapping Partial</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseOverlappingPartial(OverlappingPartial object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Overlapping Total</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Overlapping Total</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseOverlappingTotal(OverlappingTotal object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Shape</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Shape</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseShape(Shape object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Scale</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Scale</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseScale(Scale object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>EObject</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch, but this is the last case anyway.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>EObject</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject)
	 * @generated
	 */
	@Override
	public T defaultCase(EObject object) {
		return null;
	}

} //OmtgSwitch
