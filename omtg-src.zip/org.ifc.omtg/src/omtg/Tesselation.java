/**
 */
package omtg;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Tesselation</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see omtg.OmtgPackage#getTesselation()
 * @model
 * @generated
 */
public interface Tesselation extends geoField {
} // Tesselation
