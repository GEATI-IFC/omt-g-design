package ui;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.Platform;
import org.eclipse.emf.mwe.core.WorkflowFacade;
import org.eclipse.emf.mwe.core.issues.MWEDiagnostic;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.ui.internal.wizards.datatransfer.WizardFileSystemResourceExportPage1;

public class ExportWizardPage extends WizardFileSystemResourceExportPage1  {

	private List<IResource> selectedResources;



	protected ExportWizardPage(String name, IStructuredSelection selection) {
		super(name, selection);
	}

	/**
	 * 
	 * @param f
	 * @return Array with Modeling Workflow Engine diagnostic
	 * @since 1.0.0
	 */
	private MWEDiagnostic[] extracted(WorkflowFacade f) {
		return f.check().getErrors();
	}

	

	@SuppressWarnings("unchecked")
	@Override
	public boolean finish() {
		
		try {
			
			selectedResources = this.getSelectedResources();

			Map<String, String> slotContents = new HashMap<String, String>();
			
			slotContents.put("model", selectedResources.get(0).getFullPath().toString() );
			slotContents.put("src-gen",  this.getDestinationValue() );
			
			
			WorkflowFacade f = new WorkflowFacade( "jar:" + Platform.getBundle("org.ifc.omtg.export.postgis").getLocation().split("reference:")[1] + "!/workflow/postgis.mwe"  ,slotContents );			
			
			f.run();			
			
		} catch (Exception e) {
			
			System.out.print( "[OMT-G DESIGN] ERROR: ");
			System.out.println ( e.getMessage() );

			
		}		
			
		return true;
	}
	
}