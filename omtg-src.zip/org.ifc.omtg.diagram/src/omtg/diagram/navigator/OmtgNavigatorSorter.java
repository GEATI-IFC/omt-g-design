package omtg.diagram.navigator;

import omtg.diagram.part.OmtgVisualIDRegistry;

import org.eclipse.jface.viewers.ViewerSorter;

/**
 * @generated
 */
public class OmtgNavigatorSorter extends ViewerSorter {

	/**
	 * @generated
	 */
	private static final int GROUP_CATEGORY = 7052;

	/**
	 * @generated
	 */
	public int category(Object element) {
		if (element instanceof OmtgNavigatorItem) {
			OmtgNavigatorItem item = (OmtgNavigatorItem) element;
			return OmtgVisualIDRegistry.getVisualID(item.getView());
		}
		return GROUP_CATEGORY;
	}

}
