package omtg.diagram.navigator;

import omtg.Agregation;
import omtg.DisjointPartial;
import omtg.DisjointTotal;
import omtg.NetworkAssociation;
import omtg.OverlappingPartial;
import omtg.OverlappingTotal;
import omtg.Scale;
import omtg.Schema;
import omtg.Shape;
import omtg.Simple;
import omtg.Spatial;
import omtg.SpatialAgregation;
import omtg.diagram.edit.parts.AdjacentPolygonsEditPart;
import omtg.diagram.edit.parts.AdjacentPolygonsNameEditPart;
import omtg.diagram.edit.parts.AgregationEditPart;
import omtg.diagram.edit.parts.Attribute10EditPart;
import omtg.diagram.edit.parts.Attribute11EditPart;
import omtg.diagram.edit.parts.Attribute12EditPart;
import omtg.diagram.edit.parts.Attribute2EditPart;
import omtg.diagram.edit.parts.Attribute3EditPart;
import omtg.diagram.edit.parts.Attribute4EditPart;
import omtg.diagram.edit.parts.Attribute5EditPart;
import omtg.diagram.edit.parts.Attribute6EditPart;
import omtg.diagram.edit.parts.Attribute7EditPart;
import omtg.diagram.edit.parts.Attribute8EditPart;
import omtg.diagram.edit.parts.Attribute9EditPart;
import omtg.diagram.edit.parts.AttributeEditPart;
import omtg.diagram.edit.parts.AttributeNameType10EditPart;
import omtg.diagram.edit.parts.AttributeNameType11EditPart;
import omtg.diagram.edit.parts.AttributeNameType12EditPart;
import omtg.diagram.edit.parts.AttributeNameType2EditPart;
import omtg.diagram.edit.parts.AttributeNameType3EditPart;
import omtg.diagram.edit.parts.AttributeNameType4EditPart;
import omtg.diagram.edit.parts.AttributeNameType5EditPart;
import omtg.diagram.edit.parts.AttributeNameType6EditPart;
import omtg.diagram.edit.parts.AttributeNameType7EditPart;
import omtg.diagram.edit.parts.AttributeNameType8EditPart;
import omtg.diagram.edit.parts.AttributeNameType9EditPart;
import omtg.diagram.edit.parts.AttributeNameTypeEditPart;
import omtg.diagram.edit.parts.BidirectionalLineEditPart;
import omtg.diagram.edit.parts.BidirectionalLineNameEditPart;
import omtg.diagram.edit.parts.ConventionalEditPart;
import omtg.diagram.edit.parts.ConventionalNameEditPart;
import omtg.diagram.edit.parts.DisjointPartialEditPart;
import omtg.diagram.edit.parts.DisjointTotalEditPart;
import omtg.diagram.edit.parts.IsolineEditPart;
import omtg.diagram.edit.parts.IsolineNameEditPart;
import omtg.diagram.edit.parts.LineEditPart;
import omtg.diagram.edit.parts.LineNameEditPart;
import omtg.diagram.edit.parts.Method10EditPart;
import omtg.diagram.edit.parts.Method11EditPart;
import omtg.diagram.edit.parts.Method12EditPart;
import omtg.diagram.edit.parts.Method2EditPart;
import omtg.diagram.edit.parts.Method3EditPart;
import omtg.diagram.edit.parts.Method4EditPart;
import omtg.diagram.edit.parts.Method5EditPart;
import omtg.diagram.edit.parts.Method6EditPart;
import omtg.diagram.edit.parts.Method7EditPart;
import omtg.diagram.edit.parts.Method8EditPart;
import omtg.diagram.edit.parts.Method9EditPart;
import omtg.diagram.edit.parts.MethodEditPart;
import omtg.diagram.edit.parts.MethodNameAttibutesReturn10EditPart;
import omtg.diagram.edit.parts.MethodNameAttibutesReturn11EditPart;
import omtg.diagram.edit.parts.MethodNameAttibutesReturn12EditPart;
import omtg.diagram.edit.parts.MethodNameAttibutesReturn2EditPart;
import omtg.diagram.edit.parts.MethodNameAttibutesReturn3EditPart;
import omtg.diagram.edit.parts.MethodNameAttibutesReturn4EditPart;
import omtg.diagram.edit.parts.MethodNameAttibutesReturn5EditPart;
import omtg.diagram.edit.parts.MethodNameAttibutesReturn6EditPart;
import omtg.diagram.edit.parts.MethodNameAttibutesReturn7EditPart;
import omtg.diagram.edit.parts.MethodNameAttibutesReturn8EditPart;
import omtg.diagram.edit.parts.MethodNameAttibutesReturn9EditPart;
import omtg.diagram.edit.parts.MethodNameAttibutesReturnEditPart;
import omtg.diagram.edit.parts.NetworkAssociationEditPart;
import omtg.diagram.edit.parts.NetworkClassEditPart;
import omtg.diagram.edit.parts.NetworkClassNameEditPart;
import omtg.diagram.edit.parts.NodeEditPart;
import omtg.diagram.edit.parts.NodeNameEditPart;
import omtg.diagram.edit.parts.OverlappingPartialEditPart;
import omtg.diagram.edit.parts.OverlappingTotalEditPart;
import omtg.diagram.edit.parts.PointEditPart;
import omtg.diagram.edit.parts.PointNameEditPart;
import omtg.diagram.edit.parts.PolygonEditPart;
import omtg.diagram.edit.parts.PolygonNameEditPart;
import omtg.diagram.edit.parts.SamplingEditPart;
import omtg.diagram.edit.parts.SamplingNameEditPart;
import omtg.diagram.edit.parts.ScaleEditPart;
import omtg.diagram.edit.parts.SchemaEditPart;
import omtg.diagram.edit.parts.ShapeEditPart;
import omtg.diagram.edit.parts.SimpleEditPart;
import omtg.diagram.edit.parts.SpatialAgregationEditPart;
import omtg.diagram.edit.parts.SpatialEditPart;
import omtg.diagram.edit.parts.TesselationEditPart;
import omtg.diagram.edit.parts.TesselationNameEditPart;
import omtg.diagram.edit.parts.UnidirectionalLineEditPart;
import omtg.diagram.edit.parts.UnidirectionalLineNameEditPart;
import omtg.diagram.part.OmtgDiagramEditorPlugin;
import omtg.diagram.part.OmtgVisualIDRegistry;
import omtg.diagram.providers.OmtgElementTypes;
import omtg.diagram.providers.OmtgParserProvider;

import org.eclipse.gmf.runtime.common.ui.services.parser.IParser;
import org.eclipse.gmf.runtime.common.ui.services.parser.ParserOptions;
import org.eclipse.gmf.runtime.emf.core.util.EObjectAdapter;
import org.eclipse.gmf.runtime.emf.type.core.IElementType;
import org.eclipse.gmf.runtime.notation.View;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.jface.resource.ImageRegistry;
import org.eclipse.jface.viewers.ITreePathLabelProvider;
import org.eclipse.jface.viewers.LabelProvider;
import org.eclipse.jface.viewers.TreePath;
import org.eclipse.jface.viewers.ViewerLabel;
import org.eclipse.swt.graphics.Image;
import org.eclipse.ui.IMemento;
import org.eclipse.ui.navigator.ICommonContentExtensionSite;
import org.eclipse.ui.navigator.ICommonLabelProvider;

/**
 * @generated
 */
public class OmtgNavigatorLabelProvider extends LabelProvider implements
		ICommonLabelProvider, ITreePathLabelProvider {

	/**
	 * @generated
	 */
	static {
		OmtgDiagramEditorPlugin
				.getInstance()
				.getImageRegistry()
				.put("Navigator?UnknownElement", ImageDescriptor.getMissingImageDescriptor()); //$NON-NLS-1$
		OmtgDiagramEditorPlugin
				.getInstance()
				.getImageRegistry()
				.put("Navigator?ImageNotFound", ImageDescriptor.getMissingImageDescriptor()); //$NON-NLS-1$
	}

	/**
	 * @generated
	 */
	public void updateLabel(ViewerLabel label, TreePath elementPath) {
		Object element = elementPath.getLastSegment();
		if (element instanceof OmtgNavigatorItem
				&& !isOwnView(((OmtgNavigatorItem) element).getView())) {
			return;
		}
		label.setText(getText(element));
		label.setImage(getImage(element));
	}

	/**
	 * @generated
	 */
	public Image getImage(Object element) {
		if (element instanceof OmtgNavigatorGroup) {
			OmtgNavigatorGroup group = (OmtgNavigatorGroup) element;
			return OmtgDiagramEditorPlugin.getInstance().getBundledImage(
					group.getIcon());
		}

		if (element instanceof OmtgNavigatorItem) {
			OmtgNavigatorItem navigatorItem = (OmtgNavigatorItem) element;
			if (!isOwnView(navigatorItem.getView())) {
				return super.getImage(element);
			}
			return getImage(navigatorItem.getView());
		}

		return super.getImage(element);
	}

	/**
	 * @generated
	 */
	public Image getImage(View view) {
		switch (OmtgVisualIDRegistry.getVisualID(view)) {
		case Attribute8EditPart.VISUAL_ID:
			return getImage(
					"Navigator?Node?http://www.ifc-camboriu.edu.br/~frozza/omtg?Attribute", OmtgElementTypes.Attribute_3008); //$NON-NLS-1$
		case DisjointTotalEditPart.VISUAL_ID:
			return getImage(
					"Navigator?Link?http://www.ifc-camboriu.edu.br/~frozza/omtg?DisjointTotal", OmtgElementTypes.DisjointTotal_4010); //$NON-NLS-1$
		case DisjointPartialEditPart.VISUAL_ID:
			return getImage(
					"Navigator?Link?http://www.ifc-camboriu.edu.br/~frozza/omtg?DisjointPartial", OmtgElementTypes.DisjointPartial_4003); //$NON-NLS-1$
		case SpatialAgregationEditPart.VISUAL_ID:
			return getImage(
					"Navigator?Link?http://www.ifc-camboriu.edu.br/~frozza/omtg?SpatialAgregation", OmtgElementTypes.SpatialAgregation_4001); //$NON-NLS-1$
		case NetworkAssociationEditPart.VISUAL_ID:
			return getImage(
					"Navigator?Link?http://www.ifc-camboriu.edu.br/~frozza/omtg?NetworkAssociation", OmtgElementTypes.NetworkAssociation_4009); //$NON-NLS-1$
		case ShapeEditPart.VISUAL_ID:
			return getImage(
					"Navigator?Link?http://www.ifc-camboriu.edu.br/~frozza/omtg?Shape", OmtgElementTypes.Shape_4006); //$NON-NLS-1$
		case NetworkClassEditPart.VISUAL_ID:
			return getImage(
					"Navigator?TopLevelNode?http://www.ifc-camboriu.edu.br/~frozza/omtg?NetworkClass", OmtgElementTypes.NetworkClass_2016); //$NON-NLS-1$
		case PointEditPart.VISUAL_ID:
			return getImage(
					"Navigator?TopLevelNode?http://www.ifc-camboriu.edu.br/~frozza/omtg?Point", OmtgElementTypes.Point_2014); //$NON-NLS-1$
		case AdjacentPolygonsEditPart.VISUAL_ID:
			return getImage(
					"Navigator?TopLevelNode?http://www.ifc-camboriu.edu.br/~frozza/omtg?AdjacentPolygons", OmtgElementTypes.AdjacentPolygons_2020); //$NON-NLS-1$
		case Method10EditPart.VISUAL_ID:
			return getImage(
					"Navigator?Node?http://www.ifc-camboriu.edu.br/~frozza/omtg?Method", OmtgElementTypes.Method_3021); //$NON-NLS-1$
		case TesselationEditPart.VISUAL_ID:
			return getImage(
					"Navigator?TopLevelNode?http://www.ifc-camboriu.edu.br/~frozza/omtg?Tesselation", OmtgElementTypes.Tesselation_2022); //$NON-NLS-1$
		case SpatialEditPart.VISUAL_ID:
			return getImage(
					"Navigator?Link?http://www.ifc-camboriu.edu.br/~frozza/omtg?Spatial", OmtgElementTypes.Spatial_4008); //$NON-NLS-1$
		case BidirectionalLineEditPart.VISUAL_ID:
			return getImage(
					"Navigator?TopLevelNode?http://www.ifc-camboriu.edu.br/~frozza/omtg?BidirectionalLine", OmtgElementTypes.BidirectionalLine_2021); //$NON-NLS-1$
		case Method5EditPart.VISUAL_ID:
			return getImage(
					"Navigator?Node?http://www.ifc-camboriu.edu.br/~frozza/omtg?Method", OmtgElementTypes.Method_3016); //$NON-NLS-1$
		case MethodEditPart.VISUAL_ID:
			return getImage(
					"Navigator?Node?http://www.ifc-camboriu.edu.br/~frozza/omtg?Method", OmtgElementTypes.Method_3012); //$NON-NLS-1$
		case LineEditPart.VISUAL_ID:
			return getImage(
					"Navigator?TopLevelNode?http://www.ifc-camboriu.edu.br/~frozza/omtg?Line", OmtgElementTypes.Line_2015); //$NON-NLS-1$
		case Method6EditPart.VISUAL_ID:
			return getImage(
					"Navigator?Node?http://www.ifc-camboriu.edu.br/~frozza/omtg?Method", OmtgElementTypes.Method_3017); //$NON-NLS-1$
		case SchemaEditPart.VISUAL_ID:
			return getImage(
					"Navigator?Diagram?http://www.ifc-camboriu.edu.br/~frozza/omtg?Schema", OmtgElementTypes.Schema_1000); //$NON-NLS-1$
		case Attribute9EditPart.VISUAL_ID:
			return getImage(
					"Navigator?Node?http://www.ifc-camboriu.edu.br/~frozza/omtg?Attribute", OmtgElementTypes.Attribute_3009); //$NON-NLS-1$
		case Attribute4EditPart.VISUAL_ID:
			return getImage(
					"Navigator?Node?http://www.ifc-camboriu.edu.br/~frozza/omtg?Attribute", OmtgElementTypes.Attribute_3004); //$NON-NLS-1$
		case ScaleEditPart.VISUAL_ID:
			return getImage(
					"Navigator?Link?http://www.ifc-camboriu.edu.br/~frozza/omtg?Scale", OmtgElementTypes.Scale_4005); //$NON-NLS-1$
		case Attribute7EditPart.VISUAL_ID:
			return getImage(
					"Navigator?Node?http://www.ifc-camboriu.edu.br/~frozza/omtg?Attribute", OmtgElementTypes.Attribute_3007); //$NON-NLS-1$
		case Attribute3EditPart.VISUAL_ID:
			return getImage(
					"Navigator?Node?http://www.ifc-camboriu.edu.br/~frozza/omtg?Attribute", OmtgElementTypes.Attribute_3003); //$NON-NLS-1$
		case Method2EditPart.VISUAL_ID:
			return getImage(
					"Navigator?Node?http://www.ifc-camboriu.edu.br/~frozza/omtg?Method", OmtgElementTypes.Method_3013); //$NON-NLS-1$
		case AgregationEditPart.VISUAL_ID:
			return getImage(
					"Navigator?Link?http://www.ifc-camboriu.edu.br/~frozza/omtg?Agregation", OmtgElementTypes.Agregation_4007); //$NON-NLS-1$
		case Method11EditPart.VISUAL_ID:
			return getImage(
					"Navigator?Node?http://www.ifc-camboriu.edu.br/~frozza/omtg?Method", OmtgElementTypes.Method_3023); //$NON-NLS-1$
		case SimpleEditPart.VISUAL_ID:
			return getImage(
					"Navigator?Link?http://www.ifc-camboriu.edu.br/~frozza/omtg?Simple", OmtgElementTypes.Simple_4004); //$NON-NLS-1$
		case OverlappingTotalEditPart.VISUAL_ID:
			return getImage(
					"Navigator?Link?http://www.ifc-camboriu.edu.br/~frozza/omtg?OverlappingTotal", OmtgElementTypes.OverlappingTotal_4002); //$NON-NLS-1$
		case Method8EditPart.VISUAL_ID:
			return getImage(
					"Navigator?Node?http://www.ifc-camboriu.edu.br/~frozza/omtg?Method", OmtgElementTypes.Method_3019); //$NON-NLS-1$
		case Attribute5EditPart.VISUAL_ID:
			return getImage(
					"Navigator?Node?http://www.ifc-camboriu.edu.br/~frozza/omtg?Attribute", OmtgElementTypes.Attribute_3005); //$NON-NLS-1$
		case Method9EditPart.VISUAL_ID:
			return getImage(
					"Navigator?Node?http://www.ifc-camboriu.edu.br/~frozza/omtg?Method", OmtgElementTypes.Method_3020); //$NON-NLS-1$
		case NodeEditPart.VISUAL_ID:
			return getImage(
					"Navigator?TopLevelNode?http://www.ifc-camboriu.edu.br/~frozza/omtg?Node", OmtgElementTypes.Node_2019); //$NON-NLS-1$
		case SamplingEditPart.VISUAL_ID:
			return getImage(
					"Navigator?TopLevelNode?http://www.ifc-camboriu.edu.br/~frozza/omtg?Sampling", OmtgElementTypes.Sampling_2025); //$NON-NLS-1$
		case Method4EditPart.VISUAL_ID:
			return getImage(
					"Navigator?Node?http://www.ifc-camboriu.edu.br/~frozza/omtg?Method", OmtgElementTypes.Method_3015); //$NON-NLS-1$
		case Attribute2EditPart.VISUAL_ID:
			return getImage(
					"Navigator?Node?http://www.ifc-camboriu.edu.br/~frozza/omtg?Attribute", OmtgElementTypes.Attribute_3002); //$NON-NLS-1$
		case Attribute11EditPart.VISUAL_ID:
			return getImage(
					"Navigator?Node?http://www.ifc-camboriu.edu.br/~frozza/omtg?Attribute", OmtgElementTypes.Attribute_3011); //$NON-NLS-1$
		case PolygonEditPart.VISUAL_ID:
			return getImage(
					"Navigator?TopLevelNode?http://www.ifc-camboriu.edu.br/~frozza/omtg?Polygon", OmtgElementTypes.Polygon_2013); //$NON-NLS-1$
		case Method12EditPart.VISUAL_ID:
			return getImage(
					"Navigator?Node?http://www.ifc-camboriu.edu.br/~frozza/omtg?Method", OmtgElementTypes.Method_3024); //$NON-NLS-1$
		case Method7EditPart.VISUAL_ID:
			return getImage(
					"Navigator?Node?http://www.ifc-camboriu.edu.br/~frozza/omtg?Method", OmtgElementTypes.Method_3018); //$NON-NLS-1$
		case Attribute12EditPart.VISUAL_ID:
			return getImage(
					"Navigator?Node?http://www.ifc-camboriu.edu.br/~frozza/omtg?Attribute", OmtgElementTypes.Attribute_3022); //$NON-NLS-1$
		case OverlappingPartialEditPart.VISUAL_ID:
			return getImage(
					"Navigator?Link?http://www.ifc-camboriu.edu.br/~frozza/omtg?OverlappingPartial", OmtgElementTypes.OverlappingPartial_4011); //$NON-NLS-1$
		case Attribute10EditPart.VISUAL_ID:
			return getImage(
					"Navigator?Node?http://www.ifc-camboriu.edu.br/~frozza/omtg?Attribute", OmtgElementTypes.Attribute_3010); //$NON-NLS-1$
		case AttributeEditPart.VISUAL_ID:
			return getImage(
					"Navigator?Node?http://www.ifc-camboriu.edu.br/~frozza/omtg?Attribute", OmtgElementTypes.Attribute_3001); //$NON-NLS-1$
		case IsolineEditPart.VISUAL_ID:
			return getImage(
					"Navigator?TopLevelNode?http://www.ifc-camboriu.edu.br/~frozza/omtg?Isoline", OmtgElementTypes.Isoline_2018); //$NON-NLS-1$
		case ConventionalEditPart.VISUAL_ID:
			return getImage(
					"Navigator?TopLevelNode?http://www.ifc-camboriu.edu.br/~frozza/omtg?Conventional", OmtgElementTypes.Conventional_2024); //$NON-NLS-1$
		case Attribute6EditPart.VISUAL_ID:
			return getImage(
					"Navigator?Node?http://www.ifc-camboriu.edu.br/~frozza/omtg?Attribute", OmtgElementTypes.Attribute_3006); //$NON-NLS-1$
		case Method3EditPart.VISUAL_ID:
			return getImage(
					"Navigator?Node?http://www.ifc-camboriu.edu.br/~frozza/omtg?Method", OmtgElementTypes.Method_3014); //$NON-NLS-1$
		case UnidirectionalLineEditPart.VISUAL_ID:
			return getImage(
					"Navigator?TopLevelNode?http://www.ifc-camboriu.edu.br/~frozza/omtg?UnidirectionalLine", OmtgElementTypes.UnidirectionalLine_2023); //$NON-NLS-1$
		}
		return getImage("Navigator?UnknownElement", null); //$NON-NLS-1$
	}

	/**
	 * @generated
	 */
	private Image getImage(String key, IElementType elementType) {
		ImageRegistry imageRegistry = OmtgDiagramEditorPlugin.getInstance()
				.getImageRegistry();
		Image image = imageRegistry.get(key);
		if (image == null && elementType != null
				&& OmtgElementTypes.isKnownElementType(elementType)) {
			image = OmtgElementTypes.getImage(elementType);
			imageRegistry.put(key, image);
		}

		if (image == null) {
			image = imageRegistry.get("Navigator?ImageNotFound"); //$NON-NLS-1$
			imageRegistry.put(key, image);
		}
		return image;
	}

	/**
	 * @generated
	 */
	public String getText(Object element) {
		if (element instanceof OmtgNavigatorGroup) {
			OmtgNavigatorGroup group = (OmtgNavigatorGroup) element;
			return group.getGroupName();
		}

		if (element instanceof OmtgNavigatorItem) {
			OmtgNavigatorItem navigatorItem = (OmtgNavigatorItem) element;
			if (!isOwnView(navigatorItem.getView())) {
				return null;
			}
			return getText(navigatorItem.getView());
		}

		return super.getText(element);
	}

	/**
	 * @generated
	 */
	public String getText(View view) {
		if (view.getElement() != null && view.getElement().eIsProxy()) {
			return getUnresolvedDomainElementProxyText(view);
		}
		switch (OmtgVisualIDRegistry.getVisualID(view)) {
		case Attribute8EditPart.VISUAL_ID:
			return getAttribute_3008Text(view);
		case DisjointTotalEditPart.VISUAL_ID:
			return getDisjointTotal_4010Text(view);
		case DisjointPartialEditPart.VISUAL_ID:
			return getDisjointPartial_4003Text(view);
		case SpatialAgregationEditPart.VISUAL_ID:
			return getSpatialAgregation_4001Text(view);
		case NetworkAssociationEditPart.VISUAL_ID:
			return getNetworkAssociation_4009Text(view);
		case ShapeEditPart.VISUAL_ID:
			return getShape_4006Text(view);
		case NetworkClassEditPart.VISUAL_ID:
			return getNetworkClass_2016Text(view);
		case PointEditPart.VISUAL_ID:
			return getPoint_2014Text(view);
		case AdjacentPolygonsEditPart.VISUAL_ID:
			return getAdjacentPolygons_2020Text(view);
		case Method10EditPart.VISUAL_ID:
			return getMethod_3021Text(view);
		case TesselationEditPart.VISUAL_ID:
			return getTesselation_2022Text(view);
		case SpatialEditPart.VISUAL_ID:
			return getSpatial_4008Text(view);
		case BidirectionalLineEditPart.VISUAL_ID:
			return getBidirectionalLine_2021Text(view);
		case Method5EditPart.VISUAL_ID:
			return getMethod_3016Text(view);
		case MethodEditPart.VISUAL_ID:
			return getMethod_3012Text(view);
		case LineEditPart.VISUAL_ID:
			return getLine_2015Text(view);
		case Method6EditPart.VISUAL_ID:
			return getMethod_3017Text(view);
		case SchemaEditPart.VISUAL_ID:
			return getSchema_1000Text(view);
		case Attribute9EditPart.VISUAL_ID:
			return getAttribute_3009Text(view);
		case Attribute4EditPart.VISUAL_ID:
			return getAttribute_3004Text(view);
		case ScaleEditPart.VISUAL_ID:
			return getScale_4005Text(view);
		case Attribute7EditPart.VISUAL_ID:
			return getAttribute_3007Text(view);
		case Attribute3EditPart.VISUAL_ID:
			return getAttribute_3003Text(view);
		case Method2EditPart.VISUAL_ID:
			return getMethod_3013Text(view);
		case AgregationEditPart.VISUAL_ID:
			return getAgregation_4007Text(view);
		case Method11EditPart.VISUAL_ID:
			return getMethod_3023Text(view);
		case SimpleEditPart.VISUAL_ID:
			return getSimple_4004Text(view);
		case OverlappingTotalEditPart.VISUAL_ID:
			return getOverlappingTotal_4002Text(view);
		case Method8EditPart.VISUAL_ID:
			return getMethod_3019Text(view);
		case Attribute5EditPart.VISUAL_ID:
			return getAttribute_3005Text(view);
		case Method9EditPart.VISUAL_ID:
			return getMethod_3020Text(view);
		case NodeEditPart.VISUAL_ID:
			return getNode_2019Text(view);
		case SamplingEditPart.VISUAL_ID:
			return getSampling_2025Text(view);
		case Method4EditPart.VISUAL_ID:
			return getMethod_3015Text(view);
		case Attribute2EditPart.VISUAL_ID:
			return getAttribute_3002Text(view);
		case Attribute11EditPart.VISUAL_ID:
			return getAttribute_3011Text(view);
		case PolygonEditPart.VISUAL_ID:
			return getPolygon_2013Text(view);
		case Method12EditPart.VISUAL_ID:
			return getMethod_3024Text(view);
		case Method7EditPart.VISUAL_ID:
			return getMethod_3018Text(view);
		case Attribute12EditPart.VISUAL_ID:
			return getAttribute_3022Text(view);
		case OverlappingPartialEditPart.VISUAL_ID:
			return getOverlappingPartial_4011Text(view);
		case Attribute10EditPart.VISUAL_ID:
			return getAttribute_3010Text(view);
		case AttributeEditPart.VISUAL_ID:
			return getAttribute_3001Text(view);
		case IsolineEditPart.VISUAL_ID:
			return getIsoline_2018Text(view);
		case ConventionalEditPart.VISUAL_ID:
			return getConventional_2024Text(view);
		case Attribute6EditPart.VISUAL_ID:
			return getAttribute_3006Text(view);
		case Method3EditPart.VISUAL_ID:
			return getMethod_3014Text(view);
		case UnidirectionalLineEditPart.VISUAL_ID:
			return getUnidirectionalLine_2023Text(view);
		}
		return getUnknownElementText(view);
	}

	/**
	 * @generated
	 */
	private String getAttribute_3008Text(View view) {
		IParser parser = OmtgParserProvider.getParser(
				OmtgElementTypes.Attribute_3008,
				view.getElement() != null ? view.getElement() : view,
				OmtgVisualIDRegistry
						.getType(AttributeNameType8EditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(
					view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			OmtgDiagramEditorPlugin.getInstance().logError(
					"Parser was not found for label " + 5015); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	 * @generated
	 */
	private String getDisjointTotal_4010Text(View view) {
		DisjointTotal domainModelElement = (DisjointTotal) view.getElement();
		if (domainModelElement != null) {
			return domainModelElement.getName();
		} else {
			OmtgDiagramEditorPlugin.getInstance().logError(
					"No domain element for view with visualID = " + 4010); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	 * @generated
	 */
	private String getDisjointPartial_4003Text(View view) {
		DisjointPartial domainModelElement = (DisjointPartial) view
				.getElement();
		if (domainModelElement != null) {
			return domainModelElement.getName();
		} else {
			OmtgDiagramEditorPlugin.getInstance().logError(
					"No domain element for view with visualID = " + 4003); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	 * @generated
	 */
	private String getSpatialAgregation_4001Text(View view) {
		SpatialAgregation domainModelElement = (SpatialAgregation) view
				.getElement();
		if (domainModelElement != null) {
			return domainModelElement.getName();
		} else {
			OmtgDiagramEditorPlugin.getInstance().logError(
					"No domain element for view with visualID = " + 4001); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	 * @generated
	 */
	private String getNetworkAssociation_4009Text(View view) {
		NetworkAssociation domainModelElement = (NetworkAssociation) view
				.getElement();
		if (domainModelElement != null) {
			return domainModelElement.getName();
		} else {
			OmtgDiagramEditorPlugin.getInstance().logError(
					"No domain element for view with visualID = " + 4009); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	 * @generated
	 */
	private String getShape_4006Text(View view) {
		Shape domainModelElement = (Shape) view.getElement();
		if (domainModelElement != null) {
			return domainModelElement.getName();
		} else {
			OmtgDiagramEditorPlugin.getInstance().logError(
					"No domain element for view with visualID = " + 4006); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	 * @generated
	 */
	private String getNetworkClass_2016Text(View view) {
		IParser parser = OmtgParserProvider.getParser(
				OmtgElementTypes.NetworkClass_2016,
				view.getElement() != null ? view.getElement() : view,
				OmtgVisualIDRegistry
						.getType(NetworkClassNameEditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(
					view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			OmtgDiagramEditorPlugin.getInstance().logError(
					"Parser was not found for label " + 5040); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	 * @generated
	 */
	private String getPoint_2014Text(View view) {
		IParser parser = OmtgParserProvider.getParser(
				OmtgElementTypes.Point_2014,
				view.getElement() != null ? view.getElement() : view,
				OmtgVisualIDRegistry.getType(PointNameEditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(
					view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			OmtgDiagramEditorPlugin.getInstance().logError(
					"Parser was not found for label " + 5038); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	 * @generated
	 */
	private String getAdjacentPolygons_2020Text(View view) {
		IParser parser = OmtgParserProvider.getParser(
				OmtgElementTypes.AdjacentPolygons_2020,
				view.getElement() != null ? view.getElement() : view,
				OmtgVisualIDRegistry
						.getType(AdjacentPolygonsNameEditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(
					view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			OmtgDiagramEditorPlugin.getInstance().logError(
					"Parser was not found for label " + 5044); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	 * @generated
	 */
	private String getMethod_3021Text(View view) {
		IParser parser = OmtgParserProvider
				.getParser(
						OmtgElementTypes.Method_3021,
						view.getElement() != null ? view.getElement() : view,
						OmtgVisualIDRegistry
								.getType(MethodNameAttibutesReturn10EditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(
					view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			OmtgDiagramEditorPlugin.getInstance().logError(
					"Parser was not found for label " + 5033); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	 * @generated
	 */
	private String getTesselation_2022Text(View view) {
		IParser parser = OmtgParserProvider
				.getParser(OmtgElementTypes.Tesselation_2022,
						view.getElement() != null ? view.getElement() : view,
						OmtgVisualIDRegistry
								.getType(TesselationNameEditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(
					view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			OmtgDiagramEditorPlugin.getInstance().logError(
					"Parser was not found for label " + 5046); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	 * @generated
	 */
	private String getSpatial_4008Text(View view) {
		Spatial domainModelElement = (Spatial) view.getElement();
		if (domainModelElement != null) {
			return domainModelElement.getName();
		} else {
			OmtgDiagramEditorPlugin.getInstance().logError(
					"No domain element for view with visualID = " + 4008); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	 * @generated
	 */
	private String getBidirectionalLine_2021Text(View view) {
		IParser parser = OmtgParserProvider.getParser(
				OmtgElementTypes.BidirectionalLine_2021,
				view.getElement() != null ? view.getElement() : view,
				OmtgVisualIDRegistry
						.getType(BidirectionalLineNameEditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(
					view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			OmtgDiagramEditorPlugin.getInstance().logError(
					"Parser was not found for label " + 5045); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	 * @generated
	 */
	private String getMethod_3016Text(View view) {
		IParser parser = OmtgParserProvider.getParser(
				OmtgElementTypes.Method_3016,
				view.getElement() != null ? view.getElement() : view,
				OmtgVisualIDRegistry
						.getType(MethodNameAttibutesReturn5EditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(
					view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			OmtgDiagramEditorPlugin.getInstance().logError(
					"Parser was not found for label " + 5028); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	 * @generated
	 */
	private String getMethod_3012Text(View view) {
		IParser parser = OmtgParserProvider.getParser(
				OmtgElementTypes.Method_3012,
				view.getElement() != null ? view.getElement() : view,
				OmtgVisualIDRegistry
						.getType(MethodNameAttibutesReturnEditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(
					view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			OmtgDiagramEditorPlugin.getInstance().logError(
					"Parser was not found for label " + 5023); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	 * @generated
	 */
	private String getLine_2015Text(View view) {
		IParser parser = OmtgParserProvider.getParser(
				OmtgElementTypes.Line_2015,
				view.getElement() != null ? view.getElement() : view,
				OmtgVisualIDRegistry.getType(LineNameEditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(
					view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			OmtgDiagramEditorPlugin.getInstance().logError(
					"Parser was not found for label " + 5039); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	 * @generated
	 */
	private String getMethod_3017Text(View view) {
		IParser parser = OmtgParserProvider.getParser(
				OmtgElementTypes.Method_3017,
				view.getElement() != null ? view.getElement() : view,
				OmtgVisualIDRegistry
						.getType(MethodNameAttibutesReturn6EditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(
					view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			OmtgDiagramEditorPlugin.getInstance().logError(
					"Parser was not found for label " + 5029); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	 * @generated
	 */
	private String getSchema_1000Text(View view) {
		Schema domainModelElement = (Schema) view.getElement();
		if (domainModelElement != null) {
			return domainModelElement.getName();
		} else {
			OmtgDiagramEditorPlugin.getInstance().logError(
					"No domain element for view with visualID = " + 1000); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	 * @generated
	 */
	private String getAttribute_3009Text(View view) {
		IParser parser = OmtgParserProvider.getParser(
				OmtgElementTypes.Attribute_3009,
				view.getElement() != null ? view.getElement() : view,
				OmtgVisualIDRegistry
						.getType(AttributeNameType9EditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(
					view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			OmtgDiagramEditorPlugin.getInstance().logError(
					"Parser was not found for label " + 5017); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	 * @generated
	 */
	private String getAttribute_3004Text(View view) {
		IParser parser = OmtgParserProvider.getParser(
				OmtgElementTypes.Attribute_3004,
				view.getElement() != null ? view.getElement() : view,
				OmtgVisualIDRegistry
						.getType(AttributeNameType4EditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(
					view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			OmtgDiagramEditorPlugin.getInstance().logError(
					"Parser was not found for label " + 5007); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	 * @generated
	 */
	private String getScale_4005Text(View view) {
		Scale domainModelElement = (Scale) view.getElement();
		if (domainModelElement != null) {
			return domainModelElement.getName();
		} else {
			OmtgDiagramEditorPlugin.getInstance().logError(
					"No domain element for view with visualID = " + 4005); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	 * @generated
	 */
	private String getAttribute_3007Text(View view) {
		IParser parser = OmtgParserProvider.getParser(
				OmtgElementTypes.Attribute_3007,
				view.getElement() != null ? view.getElement() : view,
				OmtgVisualIDRegistry
						.getType(AttributeNameType7EditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(
					view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			OmtgDiagramEditorPlugin.getInstance().logError(
					"Parser was not found for label " + 5013); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	 * @generated
	 */
	private String getAttribute_3003Text(View view) {
		IParser parser = OmtgParserProvider.getParser(
				OmtgElementTypes.Attribute_3003,
				view.getElement() != null ? view.getElement() : view,
				OmtgVisualIDRegistry
						.getType(AttributeNameType3EditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(
					view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			OmtgDiagramEditorPlugin.getInstance().logError(
					"Parser was not found for label " + 5005); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	 * @generated
	 */
	private String getMethod_3013Text(View view) {
		IParser parser = OmtgParserProvider.getParser(
				OmtgElementTypes.Method_3013,
				view.getElement() != null ? view.getElement() : view,
				OmtgVisualIDRegistry
						.getType(MethodNameAttibutesReturn2EditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(
					view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			OmtgDiagramEditorPlugin.getInstance().logError(
					"Parser was not found for label " + 5024); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	 * @generated
	 */
	private String getAgregation_4007Text(View view) {
		Agregation domainModelElement = (Agregation) view.getElement();
		if (domainModelElement != null) {
			return domainModelElement.getName();
		} else {
			OmtgDiagramEditorPlugin.getInstance().logError(
					"No domain element for view with visualID = " + 4007); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	 * @generated
	 */
	private String getMethod_3023Text(View view) {
		IParser parser = OmtgParserProvider
				.getParser(
						OmtgElementTypes.Method_3023,
						view.getElement() != null ? view.getElement() : view,
						OmtgVisualIDRegistry
								.getType(MethodNameAttibutesReturn11EditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(
					view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			OmtgDiagramEditorPlugin.getInstance().logError(
					"Parser was not found for label " + 5035); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	 * @generated
	 */
	private String getSimple_4004Text(View view) {
		Simple domainModelElement = (Simple) view.getElement();
		if (domainModelElement != null) {
			return domainModelElement.getName();
		} else {
			OmtgDiagramEditorPlugin.getInstance().logError(
					"No domain element for view with visualID = " + 4004); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	 * @generated
	 */
	private String getOverlappingTotal_4002Text(View view) {
		OverlappingTotal domainModelElement = (OverlappingTotal) view
				.getElement();
		if (domainModelElement != null) {
			return domainModelElement.getName();
		} else {
			OmtgDiagramEditorPlugin.getInstance().logError(
					"No domain element for view with visualID = " + 4002); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	 * @generated
	 */
	private String getMethod_3019Text(View view) {
		IParser parser = OmtgParserProvider.getParser(
				OmtgElementTypes.Method_3019,
				view.getElement() != null ? view.getElement() : view,
				OmtgVisualIDRegistry
						.getType(MethodNameAttibutesReturn8EditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(
					view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			OmtgDiagramEditorPlugin.getInstance().logError(
					"Parser was not found for label " + 5031); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	 * @generated
	 */
	private String getAttribute_3005Text(View view) {
		IParser parser = OmtgParserProvider.getParser(
				OmtgElementTypes.Attribute_3005,
				view.getElement() != null ? view.getElement() : view,
				OmtgVisualIDRegistry
						.getType(AttributeNameType5EditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(
					view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			OmtgDiagramEditorPlugin.getInstance().logError(
					"Parser was not found for label " + 5009); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	 * @generated
	 */
	private String getMethod_3020Text(View view) {
		IParser parser = OmtgParserProvider.getParser(
				OmtgElementTypes.Method_3020,
				view.getElement() != null ? view.getElement() : view,
				OmtgVisualIDRegistry
						.getType(MethodNameAttibutesReturn9EditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(
					view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			OmtgDiagramEditorPlugin.getInstance().logError(
					"Parser was not found for label " + 5032); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	 * @generated
	 */
	private String getNode_2019Text(View view) {
		IParser parser = OmtgParserProvider.getParser(
				OmtgElementTypes.Node_2019,
				view.getElement() != null ? view.getElement() : view,
				OmtgVisualIDRegistry.getType(NodeNameEditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(
					view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			OmtgDiagramEditorPlugin.getInstance().logError(
					"Parser was not found for label " + 5043); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	 * @generated
	 */
	private String getSampling_2025Text(View view) {
		IParser parser = OmtgParserProvider.getParser(
				OmtgElementTypes.Sampling_2025,
				view.getElement() != null ? view.getElement() : view,
				OmtgVisualIDRegistry.getType(SamplingNameEditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(
					view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			OmtgDiagramEditorPlugin.getInstance().logError(
					"Parser was not found for label " + 5049); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	 * @generated
	 */
	private String getMethod_3015Text(View view) {
		IParser parser = OmtgParserProvider.getParser(
				OmtgElementTypes.Method_3015,
				view.getElement() != null ? view.getElement() : view,
				OmtgVisualIDRegistry
						.getType(MethodNameAttibutesReturn4EditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(
					view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			OmtgDiagramEditorPlugin.getInstance().logError(
					"Parser was not found for label " + 5027); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	 * @generated
	 */
	private String getAttribute_3002Text(View view) {
		IParser parser = OmtgParserProvider.getParser(
				OmtgElementTypes.Attribute_3002,
				view.getElement() != null ? view.getElement() : view,
				OmtgVisualIDRegistry
						.getType(AttributeNameType2EditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(
					view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			OmtgDiagramEditorPlugin.getInstance().logError(
					"Parser was not found for label " + 5003); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	 * @generated
	 */
	private String getAttribute_3011Text(View view) {
		IParser parser = OmtgParserProvider.getParser(
				OmtgElementTypes.Attribute_3011,
				view.getElement() != null ? view.getElement() : view,
				OmtgVisualIDRegistry
						.getType(AttributeNameType11EditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(
					view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			OmtgDiagramEditorPlugin.getInstance().logError(
					"Parser was not found for label " + 5021); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	 * @generated
	 */
	private String getPolygon_2013Text(View view) {
		IParser parser = OmtgParserProvider.getParser(
				OmtgElementTypes.Polygon_2013,
				view.getElement() != null ? view.getElement() : view,
				OmtgVisualIDRegistry.getType(PolygonNameEditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(
					view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			OmtgDiagramEditorPlugin.getInstance().logError(
					"Parser was not found for label " + 5037); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	 * @generated
	 */
	private String getMethod_3024Text(View view) {
		IParser parser = OmtgParserProvider
				.getParser(
						OmtgElementTypes.Method_3024,
						view.getElement() != null ? view.getElement() : view,
						OmtgVisualIDRegistry
								.getType(MethodNameAttibutesReturn12EditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(
					view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			OmtgDiagramEditorPlugin.getInstance().logError(
					"Parser was not found for label " + 5036); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	 * @generated
	 */
	private String getMethod_3018Text(View view) {
		IParser parser = OmtgParserProvider.getParser(
				OmtgElementTypes.Method_3018,
				view.getElement() != null ? view.getElement() : view,
				OmtgVisualIDRegistry
						.getType(MethodNameAttibutesReturn7EditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(
					view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			OmtgDiagramEditorPlugin.getInstance().logError(
					"Parser was not found for label " + 5030); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	 * @generated
	 */
	private String getAttribute_3022Text(View view) {
		IParser parser = OmtgParserProvider.getParser(
				OmtgElementTypes.Attribute_3022,
				view.getElement() != null ? view.getElement() : view,
				OmtgVisualIDRegistry
						.getType(AttributeNameType12EditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(
					view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			OmtgDiagramEditorPlugin.getInstance().logError(
					"Parser was not found for label " + 5034); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	 * @generated
	 */
	private String getOverlappingPartial_4011Text(View view) {
		OverlappingPartial domainModelElement = (OverlappingPartial) view
				.getElement();
		if (domainModelElement != null) {
			return domainModelElement.getName();
		} else {
			OmtgDiagramEditorPlugin.getInstance().logError(
					"No domain element for view with visualID = " + 4011); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	 * @generated
	 */
	private String getAttribute_3010Text(View view) {
		IParser parser = OmtgParserProvider.getParser(
				OmtgElementTypes.Attribute_3010,
				view.getElement() != null ? view.getElement() : view,
				OmtgVisualIDRegistry
						.getType(AttributeNameType10EditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(
					view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			OmtgDiagramEditorPlugin.getInstance().logError(
					"Parser was not found for label " + 5019); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	 * @generated
	 */
	private String getAttribute_3001Text(View view) {
		IParser parser = OmtgParserProvider.getParser(
				OmtgElementTypes.Attribute_3001,
				view.getElement() != null ? view.getElement() : view,
				OmtgVisualIDRegistry
						.getType(AttributeNameTypeEditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(
					view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			OmtgDiagramEditorPlugin.getInstance().logError(
					"Parser was not found for label " + 5001); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	 * @generated
	 */
	private String getIsoline_2018Text(View view) {
		IParser parser = OmtgParserProvider.getParser(
				OmtgElementTypes.Isoline_2018,
				view.getElement() != null ? view.getElement() : view,
				OmtgVisualIDRegistry.getType(IsolineNameEditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(
					view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			OmtgDiagramEditorPlugin.getInstance().logError(
					"Parser was not found for label " + 5042); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	 * @generated
	 */
	private String getConventional_2024Text(View view) {
		IParser parser = OmtgParserProvider.getParser(
				OmtgElementTypes.Conventional_2024,
				view.getElement() != null ? view.getElement() : view,
				OmtgVisualIDRegistry
						.getType(ConventionalNameEditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(
					view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			OmtgDiagramEditorPlugin.getInstance().logError(
					"Parser was not found for label " + 5048); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	 * @generated
	 */
	private String getAttribute_3006Text(View view) {
		IParser parser = OmtgParserProvider.getParser(
				OmtgElementTypes.Attribute_3006,
				view.getElement() != null ? view.getElement() : view,
				OmtgVisualIDRegistry
						.getType(AttributeNameType6EditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(
					view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			OmtgDiagramEditorPlugin.getInstance().logError(
					"Parser was not found for label " + 5011); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	 * @generated
	 */
	private String getMethod_3014Text(View view) {
		IParser parser = OmtgParserProvider.getParser(
				OmtgElementTypes.Method_3014,
				view.getElement() != null ? view.getElement() : view,
				OmtgVisualIDRegistry
						.getType(MethodNameAttibutesReturn3EditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(
					view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			OmtgDiagramEditorPlugin.getInstance().logError(
					"Parser was not found for label " + 5025); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	 * @generated
	 */
	private String getUnidirectionalLine_2023Text(View view) {
		IParser parser = OmtgParserProvider.getParser(
				OmtgElementTypes.UnidirectionalLine_2023,
				view.getElement() != null ? view.getElement() : view,
				OmtgVisualIDRegistry
						.getType(UnidirectionalLineNameEditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(
					view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			OmtgDiagramEditorPlugin.getInstance().logError(
					"Parser was not found for label " + 5047); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	 * @generated
	 */
	private String getUnknownElementText(View view) {
		return "<UnknownElement Visual_ID = " + view.getType() + ">"; //$NON-NLS-1$  //$NON-NLS-2$
	}

	/**
	 * @generated
	 */
	private String getUnresolvedDomainElementProxyText(View view) {
		return "<Unresolved domain element Visual_ID = " + view.getType() + ">"; //$NON-NLS-1$  //$NON-NLS-2$
	}

	/**
	 * @generated
	 */
	public void init(ICommonContentExtensionSite aConfig) {
	}

	/**
	 * @generated
	 */
	public void restoreState(IMemento aMemento) {
	}

	/**
	 * @generated
	 */
	public void saveState(IMemento aMemento) {
	}

	/**
	 * @generated
	 */
	public String getDescription(Object anElement) {
		return null;
	}

	/**
	 * @generated
	 */
	private boolean isOwnView(View view) {
		return SchemaEditPart.MODEL_ID.equals(OmtgVisualIDRegistry
				.getModelID(view));
	}

}
