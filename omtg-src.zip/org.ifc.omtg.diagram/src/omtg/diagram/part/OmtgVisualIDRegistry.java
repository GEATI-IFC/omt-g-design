package omtg.diagram.part;

import omtg.OmtgPackage;
import omtg.Schema;
import omtg.diagram.edit.parts.*;

import org.eclipse.core.runtime.Platform;
import org.eclipse.emf.ecore.EAnnotation;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.gmf.runtime.notation.Diagram;
import org.eclipse.gmf.runtime.notation.View;
import org.eclipse.gmf.tooling.runtime.structure.DiagramStructure;

/**
 * This registry is used to determine which type of visual object should be
 * created for the corresponding Diagram, Node, ChildNode or Link represented
 * by a domain model object.
 * 
 * @generated
 */
public class OmtgVisualIDRegistry {

	/**
	 * @generated
	 */
	private static final String DEBUG_KEY = "org.ifc.omtg.diagram/debug/visualID"; //$NON-NLS-1$

	/**
	 * @generated
	 */
	public static int getVisualID(View view) {
		if (view instanceof Diagram) {
			if (SchemaEditPart.MODEL_ID.equals(view.getType())) {
				return SchemaEditPart.VISUAL_ID;
			} else {
				return -1;
			}
		}
		return omtg.diagram.part.OmtgVisualIDRegistry.getVisualID(view
				.getType());
	}

	/**
	 * @generated
	 */
	public static String getModelID(View view) {
		View diagram = view.getDiagram();
		while (view != diagram) {
			EAnnotation annotation = view.getEAnnotation("Shortcut"); //$NON-NLS-1$
			if (annotation != null) {
				return (String) annotation.getDetails().get("modelID"); //$NON-NLS-1$
			}
			view = (View) view.eContainer();
		}
		return diagram != null ? diagram.getType() : null;
	}

	/**
	 * @generated
	 */
	public static int getVisualID(String type) {
		try {
			return Integer.parseInt(type);
		} catch (NumberFormatException e) {
			if (Boolean.TRUE.toString().equalsIgnoreCase(
					Platform.getDebugOption(DEBUG_KEY))) {
				OmtgDiagramEditorPlugin.getInstance().logError(
						"Unable to parse view type as a visualID number: "
								+ type);
			}
		}
		return -1;
	}

	/**
	 * @generated
	 */
	public static String getType(int visualID) {
		return Integer.toString(visualID);
	}

	/**
	 * @generated
	 */
	public static int getDiagramVisualID(EObject domainElement) {
		if (domainElement == null) {
			return -1;
		}
		if (OmtgPackage.eINSTANCE.getSchema().isSuperTypeOf(
				domainElement.eClass())
				&& isDiagram((Schema) domainElement)) {
			return SchemaEditPart.VISUAL_ID;
		}
		return -1;
	}

	/**
	 * @generated
	 */
	public static int getNodeVisualID(View containerView, EObject domainElement) {
		if (domainElement == null) {
			return -1;
		}
		String containerModelID = omtg.diagram.part.OmtgVisualIDRegistry
				.getModelID(containerView);
		if (!SchemaEditPart.MODEL_ID.equals(containerModelID)) {
			return -1;
		}
		int containerVisualID;
		if (SchemaEditPart.MODEL_ID.equals(containerModelID)) {
			containerVisualID = omtg.diagram.part.OmtgVisualIDRegistry
					.getVisualID(containerView);
		} else {
			if (containerView instanceof Diagram) {
				containerVisualID = SchemaEditPart.VISUAL_ID;
			} else {
				return -1;
			}
		}
		switch (containerVisualID) {
		case SchemaEditPart.VISUAL_ID:
			if (OmtgPackage.eINSTANCE.getPolygon().isSuperTypeOf(
					domainElement.eClass())) {
				return PolygonEditPart.VISUAL_ID;
			}
			if (OmtgPackage.eINSTANCE.getPoint().isSuperTypeOf(
					domainElement.eClass())) {
				return PointEditPart.VISUAL_ID;
			}
			if (OmtgPackage.eINSTANCE.getLine().isSuperTypeOf(
					domainElement.eClass())) {
				return LineEditPart.VISUAL_ID;
			}
			if (OmtgPackage.eINSTANCE.getNetworkClass().isSuperTypeOf(
					domainElement.eClass())) {
				return NetworkClassEditPart.VISUAL_ID;
			}
			if (OmtgPackage.eINSTANCE.getSampling().isSuperTypeOf(
					domainElement.eClass())) {
				return SamplingEditPart.VISUAL_ID;
			}
			if (OmtgPackage.eINSTANCE.getIsoline().isSuperTypeOf(
					domainElement.eClass())) {
				return IsolineEditPart.VISUAL_ID;
			}
			if (OmtgPackage.eINSTANCE.getNode().isSuperTypeOf(
					domainElement.eClass())) {
				return NodeEditPart.VISUAL_ID;
			}
			if (OmtgPackage.eINSTANCE.getAdjacentPolygons().isSuperTypeOf(
					domainElement.eClass())) {
				return AdjacentPolygonsEditPart.VISUAL_ID;
			}
			if (OmtgPackage.eINSTANCE.getBidirectionalLine().isSuperTypeOf(
					domainElement.eClass())) {
				return BidirectionalLineEditPart.VISUAL_ID;
			}
			if (OmtgPackage.eINSTANCE.getTesselation().isSuperTypeOf(
					domainElement.eClass())) {
				return TesselationEditPart.VISUAL_ID;
			}
			if (OmtgPackage.eINSTANCE.getUnidirectionalLine().isSuperTypeOf(
					domainElement.eClass())) {
				return UnidirectionalLineEditPart.VISUAL_ID;
			}
			if (OmtgPackage.eINSTANCE.getConventional().isSuperTypeOf(
					domainElement.eClass())) {
				return ConventionalEditPart.VISUAL_ID;
			}
			break;
		case PolygonBaseClassCompartmentGraphicalEditPart.VISUAL_ID:
			if (OmtgPackage.eINSTANCE.getAttribute().isSuperTypeOf(
					domainElement.eClass())) {
				return AttributeEditPart.VISUAL_ID;
			}
			break;
		case PolygonBaseClassCompartmentGraphical2EditPart.VISUAL_ID:
			if (OmtgPackage.eINSTANCE.getMethod().isSuperTypeOf(
					domainElement.eClass())) {
				return MethodEditPart.VISUAL_ID;
			}
			break;
		case PointBaseClassCompartmentGraphicalEditPart.VISUAL_ID:
			if (OmtgPackage.eINSTANCE.getAttribute().isSuperTypeOf(
					domainElement.eClass())) {
				return Attribute2EditPart.VISUAL_ID;
			}
			break;
		case PointBaseClassCompartmentGraphical2EditPart.VISUAL_ID:
			if (OmtgPackage.eINSTANCE.getMethod().isSuperTypeOf(
					domainElement.eClass())) {
				return Method2EditPart.VISUAL_ID;
			}
			break;
		case LineBaseClassCompartmentGraphicalEditPart.VISUAL_ID:
			if (OmtgPackage.eINSTANCE.getAttribute().isSuperTypeOf(
					domainElement.eClass())) {
				return Attribute3EditPart.VISUAL_ID;
			}
			break;
		case LineBaseClassCompartmentGraphical2EditPart.VISUAL_ID:
			if (OmtgPackage.eINSTANCE.getMethod().isSuperTypeOf(
					domainElement.eClass())) {
				return Method3EditPart.VISUAL_ID;
			}
			break;
		case NetworkClassBaseClassCompartmentGraphicalEditPart.VISUAL_ID:
			if (OmtgPackage.eINSTANCE.getAttribute().isSuperTypeOf(
					domainElement.eClass())) {
				return Attribute4EditPart.VISUAL_ID;
			}
			break;
		case NetworkClassBaseClassCompartmentGraphical2EditPart.VISUAL_ID:
			if (OmtgPackage.eINSTANCE.getMethod().isSuperTypeOf(
					domainElement.eClass())) {
				return Method4EditPart.VISUAL_ID;
			}
			break;
		case SamplingBaseClassCompartmentGraphicalEditPart.VISUAL_ID:
			if (OmtgPackage.eINSTANCE.getAttribute().isSuperTypeOf(
					domainElement.eClass())) {
				return Attribute5EditPart.VISUAL_ID;
			}
			break;
		case SamplingBaseClassCompartmentGraphical2EditPart.VISUAL_ID:
			if (OmtgPackage.eINSTANCE.getMethod().isSuperTypeOf(
					domainElement.eClass())) {
				return Method5EditPart.VISUAL_ID;
			}
			break;
		case IsolineBaseClassCompartmentGraphicalEditPart.VISUAL_ID:
			if (OmtgPackage.eINSTANCE.getAttribute().isSuperTypeOf(
					domainElement.eClass())) {
				return Attribute6EditPart.VISUAL_ID;
			}
			break;
		case IsolineBaseClassCompartmentGraphical2EditPart.VISUAL_ID:
			if (OmtgPackage.eINSTANCE.getMethod().isSuperTypeOf(
					domainElement.eClass())) {
				return Method6EditPart.VISUAL_ID;
			}
			break;
		case NodeBaseClassCompartmentGraphicalEditPart.VISUAL_ID:
			if (OmtgPackage.eINSTANCE.getAttribute().isSuperTypeOf(
					domainElement.eClass())) {
				return Attribute7EditPart.VISUAL_ID;
			}
			break;
		case NodeBaseClassCompartmentGraphical2EditPart.VISUAL_ID:
			if (OmtgPackage.eINSTANCE.getMethod().isSuperTypeOf(
					domainElement.eClass())) {
				return Method7EditPart.VISUAL_ID;
			}
			break;
		case AdjacentPolygonsBaseClassCompartmentGraphicalEditPart.VISUAL_ID:
			if (OmtgPackage.eINSTANCE.getAttribute().isSuperTypeOf(
					domainElement.eClass())) {
				return Attribute8EditPart.VISUAL_ID;
			}
			break;
		case AdjacentPolygonsBaseClassCompartmentGraphical2EditPart.VISUAL_ID:
			if (OmtgPackage.eINSTANCE.getMethod().isSuperTypeOf(
					domainElement.eClass())) {
				return Method8EditPart.VISUAL_ID;
			}
			break;
		case BidirectionalLineBaseClassCompartmentGraphicalEditPart.VISUAL_ID:
			if (OmtgPackage.eINSTANCE.getAttribute().isSuperTypeOf(
					domainElement.eClass())) {
				return Attribute9EditPart.VISUAL_ID;
			}
			break;
		case BidirectionalLineBaseClassCompartmentGraphical2EditPart.VISUAL_ID:
			if (OmtgPackage.eINSTANCE.getMethod().isSuperTypeOf(
					domainElement.eClass())) {
				return Method9EditPart.VISUAL_ID;
			}
			break;
		case TesselationBaseClassCompartmentGraphicalEditPart.VISUAL_ID:
			if (OmtgPackage.eINSTANCE.getAttribute().isSuperTypeOf(
					domainElement.eClass())) {
				return Attribute10EditPart.VISUAL_ID;
			}
			break;
		case TesselationBaseClassCompartmentGraphical2EditPart.VISUAL_ID:
			if (OmtgPackage.eINSTANCE.getMethod().isSuperTypeOf(
					domainElement.eClass())) {
				return Method10EditPart.VISUAL_ID;
			}
			break;
		case UnidirectionalLineBaseClassCompartmentGraphicalEditPart.VISUAL_ID:
			if (OmtgPackage.eINSTANCE.getAttribute().isSuperTypeOf(
					domainElement.eClass())) {
				return Attribute11EditPart.VISUAL_ID;
			}
			break;
		case UnidirectionalLineBaseClassCompartmentGraphical2EditPart.VISUAL_ID:
			if (OmtgPackage.eINSTANCE.getMethod().isSuperTypeOf(
					domainElement.eClass())) {
				return Method11EditPart.VISUAL_ID;
			}
			break;
		case ConventionalBaseClassCompartmentGraphicalEditPart.VISUAL_ID:
			if (OmtgPackage.eINSTANCE.getAttribute().isSuperTypeOf(
					domainElement.eClass())) {
				return Attribute12EditPart.VISUAL_ID;
			}
			break;
		case ConventionalBaseClassCompartmentGraphical2EditPart.VISUAL_ID:
			if (OmtgPackage.eINSTANCE.getMethod().isSuperTypeOf(
					domainElement.eClass())) {
				return Method12EditPart.VISUAL_ID;
			}
			break;
		}
		return -1;
	}

	/**
	 * @generated
	 */
	public static boolean canCreateNode(View containerView, int nodeVisualID) {
		String containerModelID = omtg.diagram.part.OmtgVisualIDRegistry
				.getModelID(containerView);
		if (!SchemaEditPart.MODEL_ID.equals(containerModelID)) {
			return false;
		}
		int containerVisualID;
		if (SchemaEditPart.MODEL_ID.equals(containerModelID)) {
			containerVisualID = omtg.diagram.part.OmtgVisualIDRegistry
					.getVisualID(containerView);
		} else {
			if (containerView instanceof Diagram) {
				containerVisualID = SchemaEditPart.VISUAL_ID;
			} else {
				return false;
			}
		}
		switch (containerVisualID) {
		case SchemaEditPart.VISUAL_ID:
			if (PolygonEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (PointEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (LineEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (NetworkClassEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (SamplingEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (IsolineEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (NodeEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (AdjacentPolygonsEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (BidirectionalLineEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (TesselationEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (UnidirectionalLineEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (ConventionalEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case PolygonEditPart.VISUAL_ID:
			if (PolygonNameEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (PolygonBaseClassCompartmentGraphicalEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (PolygonBaseClassCompartmentGraphical2EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case PointEditPart.VISUAL_ID:
			if (PointNameEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (PointBaseClassCompartmentGraphicalEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (PointBaseClassCompartmentGraphical2EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case LineEditPart.VISUAL_ID:
			if (LineNameEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (LineBaseClassCompartmentGraphicalEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (LineBaseClassCompartmentGraphical2EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case NetworkClassEditPart.VISUAL_ID:
			if (NetworkClassNameEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (NetworkClassBaseClassCompartmentGraphicalEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (NetworkClassBaseClassCompartmentGraphical2EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case SamplingEditPart.VISUAL_ID:
			if (SamplingNameEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (SamplingBaseClassCompartmentGraphicalEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (SamplingBaseClassCompartmentGraphical2EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case IsolineEditPart.VISUAL_ID:
			if (IsolineNameEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (IsolineBaseClassCompartmentGraphicalEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (IsolineBaseClassCompartmentGraphical2EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case NodeEditPart.VISUAL_ID:
			if (NodeNameEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (NodeBaseClassCompartmentGraphicalEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (NodeBaseClassCompartmentGraphical2EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case AdjacentPolygonsEditPart.VISUAL_ID:
			if (AdjacentPolygonsNameEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (AdjacentPolygonsBaseClassCompartmentGraphicalEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (AdjacentPolygonsBaseClassCompartmentGraphical2EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case BidirectionalLineEditPart.VISUAL_ID:
			if (BidirectionalLineNameEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (BidirectionalLineBaseClassCompartmentGraphicalEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (BidirectionalLineBaseClassCompartmentGraphical2EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case TesselationEditPart.VISUAL_ID:
			if (TesselationNameEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (TesselationBaseClassCompartmentGraphicalEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (TesselationBaseClassCompartmentGraphical2EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case UnidirectionalLineEditPart.VISUAL_ID:
			if (UnidirectionalLineNameEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (UnidirectionalLineBaseClassCompartmentGraphicalEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (UnidirectionalLineBaseClassCompartmentGraphical2EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case ConventionalEditPart.VISUAL_ID:
			if (ConventionalNameEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (ConventionalBaseClassCompartmentGraphicalEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (ConventionalBaseClassCompartmentGraphical2EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case AttributeEditPart.VISUAL_ID:
			if (AttributeNameTypeEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case MethodEditPart.VISUAL_ID:
			if (MethodNameAttibutesReturnEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case Attribute2EditPart.VISUAL_ID:
			if (AttributeNameType2EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case Method2EditPart.VISUAL_ID:
			if (MethodNameAttibutesReturn2EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case Attribute3EditPart.VISUAL_ID:
			if (AttributeNameType3EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case Method3EditPart.VISUAL_ID:
			if (MethodNameAttibutesReturn3EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case Attribute4EditPart.VISUAL_ID:
			if (AttributeNameType4EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case Method4EditPart.VISUAL_ID:
			if (MethodNameAttibutesReturn4EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case Attribute5EditPart.VISUAL_ID:
			if (AttributeNameType5EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case Method5EditPart.VISUAL_ID:
			if (MethodNameAttibutesReturn5EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case Attribute6EditPart.VISUAL_ID:
			if (AttributeNameType6EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case Method6EditPart.VISUAL_ID:
			if (MethodNameAttibutesReturn6EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case Attribute7EditPart.VISUAL_ID:
			if (AttributeNameType7EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case Method7EditPart.VISUAL_ID:
			if (MethodNameAttibutesReturn7EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case Attribute8EditPart.VISUAL_ID:
			if (AttributeNameType8EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case Method8EditPart.VISUAL_ID:
			if (MethodNameAttibutesReturn8EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case Attribute9EditPart.VISUAL_ID:
			if (AttributeNameType9EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case Method9EditPart.VISUAL_ID:
			if (MethodNameAttibutesReturn9EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case Attribute10EditPart.VISUAL_ID:
			if (AttributeNameType10EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case Method10EditPart.VISUAL_ID:
			if (MethodNameAttibutesReturn10EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case Attribute11EditPart.VISUAL_ID:
			if (AttributeNameType11EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case Method11EditPart.VISUAL_ID:
			if (MethodNameAttibutesReturn11EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case Attribute12EditPart.VISUAL_ID:
			if (AttributeNameType12EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case Method12EditPart.VISUAL_ID:
			if (MethodNameAttibutesReturn12EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case PolygonBaseClassCompartmentGraphicalEditPart.VISUAL_ID:
			if (AttributeEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case PolygonBaseClassCompartmentGraphical2EditPart.VISUAL_ID:
			if (MethodEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case PointBaseClassCompartmentGraphicalEditPart.VISUAL_ID:
			if (Attribute2EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case PointBaseClassCompartmentGraphical2EditPart.VISUAL_ID:
			if (Method2EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case LineBaseClassCompartmentGraphicalEditPart.VISUAL_ID:
			if (Attribute3EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case LineBaseClassCompartmentGraphical2EditPart.VISUAL_ID:
			if (Method3EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case NetworkClassBaseClassCompartmentGraphicalEditPart.VISUAL_ID:
			if (Attribute4EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case NetworkClassBaseClassCompartmentGraphical2EditPart.VISUAL_ID:
			if (Method4EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case SamplingBaseClassCompartmentGraphicalEditPart.VISUAL_ID:
			if (Attribute5EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case SamplingBaseClassCompartmentGraphical2EditPart.VISUAL_ID:
			if (Method5EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case IsolineBaseClassCompartmentGraphicalEditPart.VISUAL_ID:
			if (Attribute6EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case IsolineBaseClassCompartmentGraphical2EditPart.VISUAL_ID:
			if (Method6EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case NodeBaseClassCompartmentGraphicalEditPart.VISUAL_ID:
			if (Attribute7EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case NodeBaseClassCompartmentGraphical2EditPart.VISUAL_ID:
			if (Method7EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case AdjacentPolygonsBaseClassCompartmentGraphicalEditPart.VISUAL_ID:
			if (Attribute8EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case AdjacentPolygonsBaseClassCompartmentGraphical2EditPart.VISUAL_ID:
			if (Method8EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case BidirectionalLineBaseClassCompartmentGraphicalEditPart.VISUAL_ID:
			if (Attribute9EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case BidirectionalLineBaseClassCompartmentGraphical2EditPart.VISUAL_ID:
			if (Method9EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case TesselationBaseClassCompartmentGraphicalEditPart.VISUAL_ID:
			if (Attribute10EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case TesselationBaseClassCompartmentGraphical2EditPart.VISUAL_ID:
			if (Method10EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case UnidirectionalLineBaseClassCompartmentGraphicalEditPart.VISUAL_ID:
			if (Attribute11EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case UnidirectionalLineBaseClassCompartmentGraphical2EditPart.VISUAL_ID:
			if (Method11EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case ConventionalBaseClassCompartmentGraphicalEditPart.VISUAL_ID:
			if (Attribute12EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case ConventionalBaseClassCompartmentGraphical2EditPart.VISUAL_ID:
			if (Method12EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		}
		return false;
	}

	/**
	 * @generated
	 */
	public static int getLinkWithClassVisualID(EObject domainElement) {
		if (domainElement == null) {
			return -1;
		}
		if (OmtgPackage.eINSTANCE.getSpatialAgregation().isSuperTypeOf(
				domainElement.eClass())) {
			return SpatialAgregationEditPart.VISUAL_ID;
		}
		if (OmtgPackage.eINSTANCE.getOverlappingTotal().isSuperTypeOf(
				domainElement.eClass())) {
			return OverlappingTotalEditPart.VISUAL_ID;
		}
		if (OmtgPackage.eINSTANCE.getDisjointPartial().isSuperTypeOf(
				domainElement.eClass())) {
			return DisjointPartialEditPart.VISUAL_ID;
		}
		if (OmtgPackage.eINSTANCE.getSimple().isSuperTypeOf(
				domainElement.eClass())) {
			return SimpleEditPart.VISUAL_ID;
		}
		if (OmtgPackage.eINSTANCE.getScale().isSuperTypeOf(
				domainElement.eClass())) {
			return ScaleEditPart.VISUAL_ID;
		}
		if (OmtgPackage.eINSTANCE.getShape().isSuperTypeOf(
				domainElement.eClass())) {
			return ShapeEditPart.VISUAL_ID;
		}
		if (OmtgPackage.eINSTANCE.getAgregation().isSuperTypeOf(
				domainElement.eClass())) {
			return AgregationEditPart.VISUAL_ID;
		}
		if (OmtgPackage.eINSTANCE.getSpatial().isSuperTypeOf(
				domainElement.eClass())) {
			return SpatialEditPart.VISUAL_ID;
		}
		if (OmtgPackage.eINSTANCE.getNetworkAssociation().isSuperTypeOf(
				domainElement.eClass())) {
			return NetworkAssociationEditPart.VISUAL_ID;
		}
		if (OmtgPackage.eINSTANCE.getDisjointTotal().isSuperTypeOf(
				domainElement.eClass())) {
			return DisjointTotalEditPart.VISUAL_ID;
		}
		if (OmtgPackage.eINSTANCE.getOverlappingPartial().isSuperTypeOf(
				domainElement.eClass())) {
			return OverlappingPartialEditPart.VISUAL_ID;
		}
		return -1;
	}

	/**
	 * User can change implementation of this method to handle some specific
	 * situations not covered by default logic.
	 * 
	 * @generated
	 */
	private static boolean isDiagram(Schema element) {
		return true;
	}

	/**
	 * @generated
	 */
	public static boolean checkNodeVisualID(View containerView,
			EObject domainElement, int candidate) {
		if (candidate == -1) {
			//unrecognized id is always bad
			return false;
		}
		int basic = getNodeVisualID(containerView, domainElement);
		return basic == candidate;
	}

	/**
	 * @generated
	 */
	public static boolean isCompartmentVisualID(int visualID) {
		switch (visualID) {
		case PolygonBaseClassCompartmentGraphicalEditPart.VISUAL_ID:
		case PolygonBaseClassCompartmentGraphical2EditPart.VISUAL_ID:
		case PointBaseClassCompartmentGraphicalEditPart.VISUAL_ID:
		case PointBaseClassCompartmentGraphical2EditPart.VISUAL_ID:
		case LineBaseClassCompartmentGraphicalEditPart.VISUAL_ID:
		case LineBaseClassCompartmentGraphical2EditPart.VISUAL_ID:
		case NetworkClassBaseClassCompartmentGraphicalEditPart.VISUAL_ID:
		case NetworkClassBaseClassCompartmentGraphical2EditPart.VISUAL_ID:
		case SamplingBaseClassCompartmentGraphicalEditPart.VISUAL_ID:
		case SamplingBaseClassCompartmentGraphical2EditPart.VISUAL_ID:
		case IsolineBaseClassCompartmentGraphicalEditPart.VISUAL_ID:
		case IsolineBaseClassCompartmentGraphical2EditPart.VISUAL_ID:
		case NodeBaseClassCompartmentGraphicalEditPart.VISUAL_ID:
		case NodeBaseClassCompartmentGraphical2EditPart.VISUAL_ID:
		case AdjacentPolygonsBaseClassCompartmentGraphicalEditPart.VISUAL_ID:
		case AdjacentPolygonsBaseClassCompartmentGraphical2EditPart.VISUAL_ID:
		case BidirectionalLineBaseClassCompartmentGraphicalEditPart.VISUAL_ID:
		case BidirectionalLineBaseClassCompartmentGraphical2EditPart.VISUAL_ID:
		case TesselationBaseClassCompartmentGraphicalEditPart.VISUAL_ID:
		case TesselationBaseClassCompartmentGraphical2EditPart.VISUAL_ID:
		case UnidirectionalLineBaseClassCompartmentGraphicalEditPart.VISUAL_ID:
		case UnidirectionalLineBaseClassCompartmentGraphical2EditPart.VISUAL_ID:
		case ConventionalBaseClassCompartmentGraphicalEditPart.VISUAL_ID:
		case ConventionalBaseClassCompartmentGraphical2EditPart.VISUAL_ID:
			return true;
		default:
			break;
		}
		return false;
	}

	/**
	 * @generated
	 */
	public static boolean isSemanticLeafVisualID(int visualID) {
		switch (visualID) {
		case SchemaEditPart.VISUAL_ID:
			return false;
		case AttributeEditPart.VISUAL_ID:
		case Attribute2EditPart.VISUAL_ID:
		case Attribute3EditPart.VISUAL_ID:
		case Attribute4EditPart.VISUAL_ID:
		case Attribute5EditPart.VISUAL_ID:
		case Attribute6EditPart.VISUAL_ID:
		case Attribute7EditPart.VISUAL_ID:
		case Attribute8EditPart.VISUAL_ID:
		case Attribute9EditPart.VISUAL_ID:
		case Attribute10EditPart.VISUAL_ID:
		case Attribute11EditPart.VISUAL_ID:
		case MethodEditPart.VISUAL_ID:
		case Method2EditPart.VISUAL_ID:
		case Method3EditPart.VISUAL_ID:
		case Method4EditPart.VISUAL_ID:
		case Method5EditPart.VISUAL_ID:
		case Method6EditPart.VISUAL_ID:
		case Method7EditPart.VISUAL_ID:
		case Method8EditPart.VISUAL_ID:
		case Method9EditPart.VISUAL_ID:
		case Method10EditPart.VISUAL_ID:
		case Attribute12EditPart.VISUAL_ID:
		case Method11EditPart.VISUAL_ID:
		case Method12EditPart.VISUAL_ID:
			return true;
		default:
			break;
		}
		return false;
	}

	/**
	 * @generated
	 */
	public static final DiagramStructure TYPED_INSTANCE = new DiagramStructure() {
		/**
		 * @generated
		 */
		@Override
		public int getVisualID(View view) {
			return omtg.diagram.part.OmtgVisualIDRegistry.getVisualID(view);
		}

		/**
		 * @generated
		 */
		@Override
		public String getModelID(View view) {
			return omtg.diagram.part.OmtgVisualIDRegistry.getModelID(view);
		}

		/**
		 * @generated
		 */
		@Override
		public int getNodeVisualID(View containerView, EObject domainElement) {
			return omtg.diagram.part.OmtgVisualIDRegistry.getNodeVisualID(
					containerView, domainElement);
		}

		/**
		 * @generated
		 */
		@Override
		public boolean checkNodeVisualID(View containerView,
				EObject domainElement, int candidate) {
			return omtg.diagram.part.OmtgVisualIDRegistry.checkNodeVisualID(
					containerView, domainElement, candidate);
		}

		/**
		 * @generated
		 */
		@Override
		public boolean isCompartmentVisualID(int visualID) {
			return omtg.diagram.part.OmtgVisualIDRegistry
					.isCompartmentVisualID(visualID);
		}

		/**
		 * @generated
		 */
		@Override
		public boolean isSemanticLeafVisualID(int visualID) {
			return omtg.diagram.part.OmtgVisualIDRegistry
					.isSemanticLeafVisualID(visualID);
		}
	};

}
