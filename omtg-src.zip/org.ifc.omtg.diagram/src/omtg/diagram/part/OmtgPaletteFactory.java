package omtg.diagram.part;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import omtg.diagram.providers.OmtgElementTypes;

import org.eclipse.gef.Tool;
import org.eclipse.gef.palette.PaletteContainer;
import org.eclipse.gef.palette.PaletteDrawer;
import org.eclipse.gef.palette.PaletteRoot;
import org.eclipse.gef.palette.ToolEntry;
import org.eclipse.gmf.runtime.diagram.ui.tools.UnspecifiedTypeConnectionTool;
import org.eclipse.gmf.runtime.diagram.ui.tools.UnspecifiedTypeCreationTool;
import org.eclipse.gmf.runtime.emf.type.core.IElementType;

/**
 * @generated
 */
public class OmtgPaletteFactory {

	/**
	 * @generated
	 */
	public void fillPalette(PaletteRoot paletteRoot) {
		paletteRoot.add(createOMTG1Group());
		paletteRoot.add(createField2Group());
		paletteRoot.add(createGeometry3Group());
		paletteRoot.add(createTopology4Group());
		paletteRoot.add(createRelationship5Group());
		paletteRoot.add(createAggregation6Group());
		paletteRoot.add(createGeneralization7Group());
		paletteRoot.add(createCartographicgeneralization8Group());
	}

	/**
	 * Creates "OMT-G" palette tool group
	 * @generated
	 */
	private PaletteContainer createOMTG1Group() {
		PaletteDrawer paletteContainer = new PaletteDrawer(
				Messages.OMTG1Group_title);
		paletteContainer.setId("createOMTG1Group"); //$NON-NLS-1$
		paletteContainer.add(createConventional1CreationTool());
		paletteContainer.add(createAttribute2CreationTool());
		paletteContainer.add(createMethod3CreationTool());
		return paletteContainer;
	}

	/**
	 * Creates "Field" palette tool group
	 * @generated
	 */
	private PaletteContainer createField2Group() {
		PaletteDrawer paletteContainer = new PaletteDrawer(
				Messages.Field2Group_title);
		paletteContainer.setId("createField2Group"); //$NON-NLS-1$
		paletteContainer.setDescription(Messages.Field2Group_desc);
		paletteContainer.add(createNetworkClass1CreationTool());
		paletteContainer.add(createAdjacentPolygons2CreationTool());
		paletteContainer.add(createTesselation3CreationTool());
		paletteContainer.add(createSampling4CreationTool());
		paletteContainer.add(createIsoline5CreationTool());
		return paletteContainer;
	}

	/**
	 * Creates "Geometry" palette tool group
	 * @generated
	 */
	private PaletteContainer createGeometry3Group() {
		PaletteDrawer paletteContainer = new PaletteDrawer(
				Messages.Geometry3Group_title);
		paletteContainer.setId("createGeometry3Group"); //$NON-NLS-1$
		paletteContainer.setDescription(Messages.Geometry3Group_desc);
		paletteContainer.add(createPolygon1CreationTool());
		paletteContainer.add(createPoint2CreationTool());
		paletteContainer.add(createLine3CreationTool());
		return paletteContainer;
	}

	/**
	 * Creates "Topology" palette tool group
	 * @generated
	 */
	private PaletteContainer createTopology4Group() {
		PaletteDrawer paletteContainer = new PaletteDrawer(
				Messages.Topology4Group_title);
		paletteContainer.setId("createTopology4Group"); //$NON-NLS-1$
		paletteContainer.setDescription(Messages.Topology4Group_desc);
		paletteContainer.add(createNode1CreationTool());
		paletteContainer.add(createBidirectionalLine2CreationTool());
		paletteContainer.add(createUnidirectionalLine3CreationTool());
		return paletteContainer;
	}

	/**
	 * Creates "Relationship" palette tool group
	 * @generated
	 */
	private PaletteContainer createRelationship5Group() {
		PaletteDrawer paletteContainer = new PaletteDrawer(
				Messages.Relationship5Group_title);
		paletteContainer.setId("createRelationship5Group"); //$NON-NLS-1$
		paletteContainer.add(createSimple1CreationTool());
		paletteContainer.add(createSpatial2CreationTool());
		paletteContainer.add(createNetworkAssociation3CreationTool());
		return paletteContainer;
	}

	/**
	 * Creates "Aggregation" palette tool group
	 * @generated
	 */
	private PaletteContainer createAggregation6Group() {
		PaletteDrawer paletteContainer = new PaletteDrawer(
				Messages.Aggregation6Group_title);
		paletteContainer.setId("createAggregation6Group"); //$NON-NLS-1$
		paletteContainer.add(createAgregation1CreationTool());
		paletteContainer.add(createSpatialAgregation2CreationTool());
		return paletteContainer;
	}

	/**
	 * Creates "Generalization" palette tool group
	 * @generated
	 */
	private PaletteContainer createGeneralization7Group() {
		PaletteDrawer paletteContainer = new PaletteDrawer(
				Messages.Generalization7Group_title);
		paletteContainer.setId("createGeneralization7Group"); //$NON-NLS-1$
		paletteContainer.add(createDisjointPartial1CreationTool());
		paletteContainer.add(createDisjointTotal2CreationTool());
		paletteContainer.add(createOverlappingPartial3CreationTool());
		paletteContainer.add(createOverlappingTotal4CreationTool());
		return paletteContainer;
	}

	/**
	 * Creates "Cartographic generalization" palette tool group
	 * @generated
	 */
	private PaletteContainer createCartographicgeneralization8Group() {
		PaletteDrawer paletteContainer = new PaletteDrawer(
				Messages.Cartographicgeneralization8Group_title);
		paletteContainer.setId("createCartographicgeneralization8Group"); //$NON-NLS-1$
		paletteContainer.add(createShape1CreationTool());
		paletteContainer.add(createScale2CreationTool());
		return paletteContainer;
	}

	/**
	 * @generated
	 */
	private ToolEntry createConventional1CreationTool() {
		NodeToolEntry entry = new NodeToolEntry(
				Messages.Conventional1CreationTool_title,
				Messages.Conventional1CreationTool_desc,
				Collections.singletonList(OmtgElementTypes.Conventional_2024));
		entry.setId("createConventional1CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(OmtgElementTypes
				.getImageDescriptor(OmtgElementTypes.Conventional_2024));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	 * @generated
	 */
	private ToolEntry createAttribute2CreationTool() {
		ArrayList<IElementType> types = new ArrayList<IElementType>(12);
		types.add(OmtgElementTypes.Attribute_3001);
		types.add(OmtgElementTypes.Attribute_3002);
		types.add(OmtgElementTypes.Attribute_3003);
		types.add(OmtgElementTypes.Attribute_3004);
		types.add(OmtgElementTypes.Attribute_3005);
		types.add(OmtgElementTypes.Attribute_3006);
		types.add(OmtgElementTypes.Attribute_3007);
		types.add(OmtgElementTypes.Attribute_3008);
		types.add(OmtgElementTypes.Attribute_3009);
		types.add(OmtgElementTypes.Attribute_3010);
		types.add(OmtgElementTypes.Attribute_3011);
		types.add(OmtgElementTypes.Attribute_3022);
		NodeToolEntry entry = new NodeToolEntry(
				Messages.Attribute2CreationTool_title,
				Messages.Attribute2CreationTool_desc, types);
		entry.setId("createAttribute2CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(OmtgElementTypes
				.getImageDescriptor(OmtgElementTypes.Attribute_3001));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	 * @generated
	 */
	private ToolEntry createMethod3CreationTool() {
		ArrayList<IElementType> types = new ArrayList<IElementType>(12);
		types.add(OmtgElementTypes.Method_3012);
		types.add(OmtgElementTypes.Method_3013);
		types.add(OmtgElementTypes.Method_3014);
		types.add(OmtgElementTypes.Method_3015);
		types.add(OmtgElementTypes.Method_3016);
		types.add(OmtgElementTypes.Method_3017);
		types.add(OmtgElementTypes.Method_3018);
		types.add(OmtgElementTypes.Method_3019);
		types.add(OmtgElementTypes.Method_3020);
		types.add(OmtgElementTypes.Method_3021);
		types.add(OmtgElementTypes.Method_3023);
		types.add(OmtgElementTypes.Method_3024);
		NodeToolEntry entry = new NodeToolEntry(
				Messages.Method3CreationTool_title,
				Messages.Method3CreationTool_desc, types);
		entry.setId("createMethod3CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(OmtgElementTypes
				.getImageDescriptor(OmtgElementTypes.Method_3012));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	 * @generated
	 */
	private ToolEntry createNetworkClass1CreationTool() {
		NodeToolEntry entry = new NodeToolEntry(
				Messages.NetworkClass1CreationTool_title,
				Messages.NetworkClass1CreationTool_desc,
				Collections.singletonList(OmtgElementTypes.NetworkClass_2016));
		entry.setId("createNetworkClass1CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(OmtgElementTypes
				.getImageDescriptor(OmtgElementTypes.NetworkClass_2016));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	 * @generated
	 */
	private ToolEntry createAdjacentPolygons2CreationTool() {
		NodeToolEntry entry = new NodeToolEntry(
				Messages.AdjacentPolygons2CreationTool_title,
				Messages.AdjacentPolygons2CreationTool_desc,
				Collections
						.singletonList(OmtgElementTypes.AdjacentPolygons_2020));
		entry.setId("createAdjacentPolygons2CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(OmtgElementTypes
				.getImageDescriptor(OmtgElementTypes.AdjacentPolygons_2020));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	 * @generated
	 */
	private ToolEntry createTesselation3CreationTool() {
		NodeToolEntry entry = new NodeToolEntry(
				Messages.Tesselation3CreationTool_title,
				Messages.Tesselation3CreationTool_desc,
				Collections.singletonList(OmtgElementTypes.Tesselation_2022));
		entry.setId("createTesselation3CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(OmtgElementTypes
				.getImageDescriptor(OmtgElementTypes.Tesselation_2022));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	 * @generated
	 */
	private ToolEntry createSampling4CreationTool() {
		NodeToolEntry entry = new NodeToolEntry(
				Messages.Sampling4CreationTool_title,
				Messages.Sampling4CreationTool_desc,
				Collections.singletonList(OmtgElementTypes.Sampling_2025));
		entry.setId("createSampling4CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(OmtgElementTypes
				.getImageDescriptor(OmtgElementTypes.Sampling_2025));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	 * @generated
	 */
	private ToolEntry createIsoline5CreationTool() {
		NodeToolEntry entry = new NodeToolEntry(
				Messages.Isoline5CreationTool_title,
				Messages.Isoline5CreationTool_desc,
				Collections.singletonList(OmtgElementTypes.Isoline_2018));
		entry.setId("createIsoline5CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(OmtgElementTypes
				.getImageDescriptor(OmtgElementTypes.Isoline_2018));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	 * @generated
	 */
	private ToolEntry createPolygon1CreationTool() {
		NodeToolEntry entry = new NodeToolEntry(
				Messages.Polygon1CreationTool_title,
				Messages.Polygon1CreationTool_desc,
				Collections.singletonList(OmtgElementTypes.Polygon_2013));
		entry.setId("createPolygon1CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(OmtgElementTypes
				.getImageDescriptor(OmtgElementTypes.Polygon_2013));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	 * @generated
	 */
	private ToolEntry createPoint2CreationTool() {
		NodeToolEntry entry = new NodeToolEntry(
				Messages.Point2CreationTool_title,
				Messages.Point2CreationTool_desc,
				Collections.singletonList(OmtgElementTypes.Point_2014));
		entry.setId("createPoint2CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(OmtgElementTypes
				.getImageDescriptor(OmtgElementTypes.Point_2014));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	 * @generated
	 */
	private ToolEntry createLine3CreationTool() {
		NodeToolEntry entry = new NodeToolEntry(
				Messages.Line3CreationTool_title,
				Messages.Line3CreationTool_desc,
				Collections.singletonList(OmtgElementTypes.Line_2015));
		entry.setId("createLine3CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(OmtgElementTypes
				.getImageDescriptor(OmtgElementTypes.Line_2015));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	 * @generated
	 */
	private ToolEntry createNode1CreationTool() {
		NodeToolEntry entry = new NodeToolEntry(
				Messages.Node1CreationTool_title,
				Messages.Node1CreationTool_desc,
				Collections.singletonList(OmtgElementTypes.Node_2019));
		entry.setId("createNode1CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(OmtgElementTypes
				.getImageDescriptor(OmtgElementTypes.Node_2019));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	 * @generated
	 */
	private ToolEntry createBidirectionalLine2CreationTool() {
		NodeToolEntry entry = new NodeToolEntry(
				Messages.BidirectionalLine2CreationTool_title,
				Messages.BidirectionalLine2CreationTool_desc,
				Collections
						.singletonList(OmtgElementTypes.BidirectionalLine_2021));
		entry.setId("createBidirectionalLine2CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(OmtgElementTypes
				.getImageDescriptor(OmtgElementTypes.BidirectionalLine_2021));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	 * @generated
	 */
	private ToolEntry createUnidirectionalLine3CreationTool() {
		NodeToolEntry entry = new NodeToolEntry(
				Messages.UnidirectionalLine3CreationTool_title,
				Messages.UnidirectionalLine3CreationTool_desc,
				Collections
						.singletonList(OmtgElementTypes.UnidirectionalLine_2023));
		entry.setId("createUnidirectionalLine3CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(OmtgElementTypes
				.getImageDescriptor(OmtgElementTypes.UnidirectionalLine_2023));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	 * @generated
	 */
	private ToolEntry createSimple1CreationTool() {
		LinkToolEntry entry = new LinkToolEntry(
				Messages.Simple1CreationTool_title,
				Messages.Simple1CreationTool_desc,
				Collections.singletonList(OmtgElementTypes.Simple_4004));
		entry.setId("createSimple1CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(OmtgElementTypes
				.getImageDescriptor(OmtgElementTypes.Simple_4004));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	 * @generated
	 */
	private ToolEntry createSpatial2CreationTool() {
		LinkToolEntry entry = new LinkToolEntry(
				Messages.Spatial2CreationTool_title,
				Messages.Spatial2CreationTool_desc,
				Collections.singletonList(OmtgElementTypes.Spatial_4008));
		entry.setId("createSpatial2CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(OmtgElementTypes
				.getImageDescriptor(OmtgElementTypes.Spatial_4008));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	 * @generated
	 */
	private ToolEntry createNetworkAssociation3CreationTool() {
		LinkToolEntry entry = new LinkToolEntry(
				Messages.NetworkAssociation3CreationTool_title,
				Messages.NetworkAssociation3CreationTool_desc,
				Collections
						.singletonList(OmtgElementTypes.NetworkAssociation_4009));
		entry.setId("createNetworkAssociation3CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(OmtgElementTypes
				.getImageDescriptor(OmtgElementTypes.NetworkAssociation_4009));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	 * @generated
	 */
	private ToolEntry createAgregation1CreationTool() {
		LinkToolEntry entry = new LinkToolEntry(
				Messages.Agregation1CreationTool_title,
				Messages.Agregation1CreationTool_desc,
				Collections.singletonList(OmtgElementTypes.Agregation_4007));
		entry.setId("createAgregation1CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(OmtgElementTypes
				.getImageDescriptor(OmtgElementTypes.Agregation_4007));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	 * @generated
	 */
	private ToolEntry createSpatialAgregation2CreationTool() {
		LinkToolEntry entry = new LinkToolEntry(
				Messages.SpatialAgregation2CreationTool_title,
				Messages.SpatialAgregation2CreationTool_desc,
				Collections
						.singletonList(OmtgElementTypes.SpatialAgregation_4001));
		entry.setId("createSpatialAgregation2CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(OmtgElementTypes
				.getImageDescriptor(OmtgElementTypes.SpatialAgregation_4001));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	 * @generated
	 */
	private ToolEntry createDisjointPartial1CreationTool() {
		LinkToolEntry entry = new LinkToolEntry(
				Messages.DisjointPartial1CreationTool_title,
				Messages.DisjointPartial1CreationTool_desc,
				Collections
						.singletonList(OmtgElementTypes.DisjointPartial_4003));
		entry.setId("createDisjointPartial1CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(OmtgElementTypes
				.getImageDescriptor(OmtgElementTypes.DisjointPartial_4003));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	 * @generated
	 */
	private ToolEntry createDisjointTotal2CreationTool() {
		LinkToolEntry entry = new LinkToolEntry(
				Messages.DisjointTotal2CreationTool_title,
				Messages.DisjointTotal2CreationTool_desc,
				Collections.singletonList(OmtgElementTypes.DisjointTotal_4010));
		entry.setId("createDisjointTotal2CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(OmtgElementTypes
				.getImageDescriptor(OmtgElementTypes.DisjointTotal_4010));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	 * @generated
	 */
	private ToolEntry createOverlappingPartial3CreationTool() {
		LinkToolEntry entry = new LinkToolEntry(
				Messages.OverlappingPartial3CreationTool_title,
				Messages.OverlappingPartial3CreationTool_desc,
				Collections
						.singletonList(OmtgElementTypes.OverlappingPartial_4011));
		entry.setId("createOverlappingPartial3CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(OmtgElementTypes
				.getImageDescriptor(OmtgElementTypes.OverlappingPartial_4011));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	 * @generated
	 */
	private ToolEntry createOverlappingTotal4CreationTool() {
		LinkToolEntry entry = new LinkToolEntry(
				Messages.OverlappingTotal4CreationTool_title,
				Messages.OverlappingTotal4CreationTool_desc,
				Collections
						.singletonList(OmtgElementTypes.OverlappingTotal_4002));
		entry.setId("createOverlappingTotal4CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(OmtgElementTypes
				.getImageDescriptor(OmtgElementTypes.OverlappingTotal_4002));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	 * @generated
	 */
	private ToolEntry createShape1CreationTool() {
		LinkToolEntry entry = new LinkToolEntry(
				Messages.Shape1CreationTool_title,
				Messages.Shape1CreationTool_desc,
				Collections.singletonList(OmtgElementTypes.Shape_4006));
		entry.setId("createShape1CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(OmtgElementTypes
				.getImageDescriptor(OmtgElementTypes.Shape_4006));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	 * @generated
	 */
	private ToolEntry createScale2CreationTool() {
		LinkToolEntry entry = new LinkToolEntry(
				Messages.Scale2CreationTool_title,
				Messages.Scale2CreationTool_desc,
				Collections.singletonList(OmtgElementTypes.Scale_4005));
		entry.setId("createScale2CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(OmtgElementTypes
				.getImageDescriptor(OmtgElementTypes.Scale_4005));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	 * @generated
	 */
	private static class NodeToolEntry extends ToolEntry {

		/**
		 * @generated
		 */
		private final List<IElementType> elementTypes;

		/**
		 * @generated
		 */
		private NodeToolEntry(String title, String description,
				List<IElementType> elementTypes) {
			super(title, description, null, null);
			this.elementTypes = elementTypes;
		}

		/**
		 * @generated
		 */
		public Tool createTool() {
			Tool tool = new UnspecifiedTypeCreationTool(elementTypes);
			tool.setProperties(getToolProperties());
			return tool;
		}
	}

	/**
	 * @generated
	 */
	private static class LinkToolEntry extends ToolEntry {

		/**
		 * @generated
		 */
		private final List<IElementType> relationshipTypes;

		/**
		 * @generated
		 */
		private LinkToolEntry(String title, String description,
				List<IElementType> relationshipTypes) {
			super(title, description, null, null);
			this.relationshipTypes = relationshipTypes;
		}

		/**
		 * @generated
		 */
		public Tool createTool() {
			Tool tool = new UnspecifiedTypeConnectionTool(relationshipTypes);
			tool.setProperties(getToolProperties());
			return tool;
		}
	}
}
