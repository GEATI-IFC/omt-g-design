package omtg.diagram.part;

import org.eclipse.osgi.util.NLS;

/**
 * @generated
 */
public class Messages extends NLS {

	/**
	 * @generated
	 */
	static {
		NLS.initializeMessages("messages", Messages.class); //$NON-NLS-1$
	}

	/**
	 * @generated
	 */
	private Messages() {
	}

	/**
	 * @generated
	 */
	public static String OmtgCreationWizardTitle;

	/**
	 * @generated
	 */
	public static String OmtgCreationWizard_DiagramModelFilePageTitle;

	/**
	 * @generated
	 */
	public static String OmtgCreationWizard_DiagramModelFilePageDescription;

	/**
	 * @generated
	 */
	public static String OmtgCreationWizardOpenEditorError;

	/**
	 * @generated
	 */
	public static String OmtgCreationWizardCreationError;

	/**
	 * @generated
	 */
	public static String OmtgCreationWizardPageExtensionError;

	/**
	 * @generated
	 */
	public static String OmtgDiagramEditorUtil_OpenModelResourceErrorDialogTitle;

	/**
	 * @generated
	 */
	public static String OmtgDiagramEditorUtil_OpenModelResourceErrorDialogMessage;

	/**
	 * @generated
	 */
	public static String OmtgDiagramEditorUtil_CreateDiagramProgressTask;

	/**
	 * @generated
	 */
	public static String OmtgDiagramEditorUtil_CreateDiagramCommandLabel;

	/**
	 * @generated
	 */
	public static String OmtgDocumentProvider_isModifiable;

	/**
	 * @generated
	 */
	public static String OmtgDocumentProvider_handleElementContentChanged;

	/**
	 * @generated
	 */
	public static String OmtgDocumentProvider_IncorrectInputError;

	/**
	 * @generated
	 */
	public static String OmtgDocumentProvider_NoDiagramInResourceError;

	/**
	 * @generated
	 */
	public static String OmtgDocumentProvider_DiagramLoadingError;

	/**
	 * @generated
	 */
	public static String OmtgDocumentProvider_UnsynchronizedFileSaveError;

	/**
	 * @generated
	 */
	public static String OmtgDocumentProvider_SaveDiagramTask;

	/**
	 * @generated
	 */
	public static String OmtgDocumentProvider_SaveNextResourceTask;

	/**
	 * @generated
	 */
	public static String OmtgDocumentProvider_SaveAsOperation;

	/**
	 * @generated
	 */
	public static String InitDiagramFile_ResourceErrorDialogTitle;

	/**
	 * @generated
	 */
	public static String InitDiagramFile_ResourceErrorDialogMessage;

	/**
	 * @generated
	 */
	public static String InitDiagramFile_WizardTitle;

	/**
	 * @generated
	 */
	public static String InitDiagramFile_OpenModelFileDialogTitle;

	/**
	 * @generated
	 */
	public static String OmtgNewDiagramFileWizard_CreationPageName;

	/**
	 * @generated
	 */
	public static String OmtgNewDiagramFileWizard_CreationPageTitle;

	/**
	 * @generated
	 */
	public static String OmtgNewDiagramFileWizard_CreationPageDescription;

	/**
	 * @generated
	 */
	public static String OmtgNewDiagramFileWizard_RootSelectionPageName;

	/**
	 * @generated
	 */
	public static String OmtgNewDiagramFileWizard_RootSelectionPageTitle;

	/**
	 * @generated
	 */
	public static String OmtgNewDiagramFileWizard_RootSelectionPageDescription;

	/**
	 * @generated
	 */
	public static String OmtgNewDiagramFileWizard_RootSelectionPageSelectionTitle;

	/**
	 * @generated
	 */
	public static String OmtgNewDiagramFileWizard_RootSelectionPageNoSelectionMessage;

	/**
	 * @generated
	 */
	public static String OmtgNewDiagramFileWizard_RootSelectionPageInvalidSelectionMessage;

	/**
	 * @generated
	 */
	public static String OmtgNewDiagramFileWizard_InitDiagramCommand;

	/**
	 * @generated
	 */
	public static String OmtgNewDiagramFileWizard_IncorrectRootError;

	/**
	 * @generated
	 */
	public static String OmtgDiagramEditor_SavingDeletedFile;

	/**
	 * @generated
	 */
	public static String OmtgDiagramEditor_SaveAsErrorTitle;

	/**
	 * @generated
	 */
	public static String OmtgDiagramEditor_SaveAsErrorMessage;

	/**
	 * @generated
	 */
	public static String OmtgDiagramEditor_SaveErrorTitle;

	/**
	 * @generated
	 */
	public static String OmtgDiagramEditor_SaveErrorMessage;

	/**
	 * @generated
	 */
	public static String OmtgElementChooserDialog_SelectModelElementTitle;

	/**
	 * @generated
	 */
	public static String ModelElementSelectionPageMessage;

	/**
	 * @generated
	 */
	public static String ValidateActionMessage;

	/**
	 * @generated
	 */
	public static String OMTG1Group_title;

	/**
	 * @generated
	 */
	public static String Field2Group_title;

	/**
	 * @generated
	 */
	public static String Field2Group_desc;

	/**
	 * @generated
	 */
	public static String Geometry3Group_title;

	/**
	 * @generated
	 */
	public static String Geometry3Group_desc;

	/**
	 * @generated
	 */
	public static String Topology4Group_title;

	/**
	 * @generated
	 */
	public static String Topology4Group_desc;

	/**
	 * @generated
	 */
	public static String Relationship5Group_title;

	/**
	 * @generated
	 */
	public static String Aggregation6Group_title;

	/**
	 * @generated
	 */
	public static String Generalization7Group_title;

	/**
	 * @generated
	 */
	public static String Cartographicgeneralization8Group_title;

	/**
	 * @generated
	 */
	public static String Conventional1CreationTool_title;

	/**
	 * @generated
	 */
	public static String Conventional1CreationTool_desc;

	/**
	 * @generated
	 */
	public static String Attribute2CreationTool_title;

	/**
	 * @generated
	 */
	public static String Attribute2CreationTool_desc;

	/**
	 * @generated
	 */
	public static String Method3CreationTool_title;

	/**
	 * @generated
	 */
	public static String Method3CreationTool_desc;

	/**
	 * @generated
	 */
	public static String NetworkClass1CreationTool_title;

	/**
	 * @generated
	 */
	public static String NetworkClass1CreationTool_desc;

	/**
	 * @generated
	 */
	public static String AdjacentPolygons2CreationTool_title;

	/**
	 * @generated
	 */
	public static String AdjacentPolygons2CreationTool_desc;

	/**
	 * @generated
	 */
	public static String Tesselation3CreationTool_title;

	/**
	 * @generated
	 */
	public static String Tesselation3CreationTool_desc;

	/**
	 * @generated
	 */
	public static String Sampling4CreationTool_title;

	/**
	 * @generated
	 */
	public static String Sampling4CreationTool_desc;

	/**
	 * @generated
	 */
	public static String Isoline5CreationTool_title;

	/**
	 * @generated
	 */
	public static String Isoline5CreationTool_desc;

	/**
	 * @generated
	 */
	public static String Polygon1CreationTool_title;

	/**
	 * @generated
	 */
	public static String Polygon1CreationTool_desc;

	/**
	 * @generated
	 */
	public static String Point2CreationTool_title;

	/**
	 * @generated
	 */
	public static String Point2CreationTool_desc;

	/**
	 * @generated
	 */
	public static String Line3CreationTool_title;

	/**
	 * @generated
	 */
	public static String Line3CreationTool_desc;

	/**
	 * @generated
	 */
	public static String Node1CreationTool_title;

	/**
	 * @generated
	 */
	public static String Node1CreationTool_desc;

	/**
	 * @generated
	 */
	public static String BidirectionalLine2CreationTool_title;

	/**
	 * @generated
	 */
	public static String BidirectionalLine2CreationTool_desc;

	/**
	 * @generated
	 */
	public static String UnidirectionalLine3CreationTool_title;

	/**
	 * @generated
	 */
	public static String UnidirectionalLine3CreationTool_desc;

	/**
	 * @generated
	 */
	public static String Simple1CreationTool_title;

	/**
	 * @generated
	 */
	public static String Simple1CreationTool_desc;

	/**
	 * @generated
	 */
	public static String Spatial2CreationTool_title;

	/**
	 * @generated
	 */
	public static String Spatial2CreationTool_desc;

	/**
	 * @generated
	 */
	public static String NetworkAssociation3CreationTool_title;

	/**
	 * @generated
	 */
	public static String NetworkAssociation3CreationTool_desc;

	/**
	 * @generated
	 */
	public static String Agregation1CreationTool_title;

	/**
	 * @generated
	 */
	public static String Agregation1CreationTool_desc;

	/**
	 * @generated
	 */
	public static String SpatialAgregation2CreationTool_title;

	/**
	 * @generated
	 */
	public static String SpatialAgregation2CreationTool_desc;

	/**
	 * @generated
	 */
	public static String DisjointPartial1CreationTool_title;

	/**
	 * @generated
	 */
	public static String DisjointPartial1CreationTool_desc;

	/**
	 * @generated
	 */
	public static String DisjointTotal2CreationTool_title;

	/**
	 * @generated
	 */
	public static String DisjointTotal2CreationTool_desc;

	/**
	 * @generated
	 */
	public static String OverlappingPartial3CreationTool_title;

	/**
	 * @generated
	 */
	public static String OverlappingPartial3CreationTool_desc;

	/**
	 * @generated
	 */
	public static String OverlappingTotal4CreationTool_title;

	/**
	 * @generated
	 */
	public static String OverlappingTotal4CreationTool_desc;

	/**
	 * @generated
	 */
	public static String Shape1CreationTool_title;

	/**
	 * @generated
	 */
	public static String Shape1CreationTool_desc;

	/**
	 * @generated
	 */
	public static String Scale2CreationTool_title;

	/**
	 * @generated
	 */
	public static String Scale2CreationTool_desc;

	/**
	 * @generated
	 */
	public static String PolygonBaseClassCompartmentGraphicalEditPart_title;

	/**
	 * @generated
	 */
	public static String PolygonBaseClassCompartmentGraphical2EditPart_title;

	/**
	 * @generated
	 */
	public static String PointBaseClassCompartmentGraphicalEditPart_title;

	/**
	 * @generated
	 */
	public static String PointBaseClassCompartmentGraphical2EditPart_title;

	/**
	 * @generated
	 */
	public static String LineBaseClassCompartmentGraphicalEditPart_title;

	/**
	 * @generated
	 */
	public static String LineBaseClassCompartmentGraphical2EditPart_title;

	/**
	 * @generated
	 */
	public static String NetworkClassBaseClassCompartmentGraphicalEditPart_title;

	/**
	 * @generated
	 */
	public static String NetworkClassBaseClassCompartmentGraphical2EditPart_title;

	/**
	 * @generated
	 */
	public static String SamplingBaseClassCompartmentGraphicalEditPart_title;

	/**
	 * @generated
	 */
	public static String SamplingBaseClassCompartmentGraphical2EditPart_title;

	/**
	 * @generated
	 */
	public static String IsolineBaseClassCompartmentGraphicalEditPart_title;

	/**
	 * @generated
	 */
	public static String IsolineBaseClassCompartmentGraphical2EditPart_title;

	/**
	 * @generated
	 */
	public static String NodeBaseClassCompartmentGraphicalEditPart_title;

	/**
	 * @generated
	 */
	public static String NodeBaseClassCompartmentGraphical2EditPart_title;

	/**
	 * @generated
	 */
	public static String AdjacentPolygonsBaseClassCompartmentGraphicalEditPart_title;

	/**
	 * @generated
	 */
	public static String AdjacentPolygonsBaseClassCompartmentGraphical2EditPart_title;

	/**
	 * @generated
	 */
	public static String BidirectionalLineBaseClassCompartmentGraphicalEditPart_title;

	/**
	 * @generated
	 */
	public static String BidirectionalLineBaseClassCompartmentGraphical2EditPart_title;

	/**
	 * @generated
	 */
	public static String TesselationBaseClassCompartmentGraphicalEditPart_title;

	/**
	 * @generated
	 */
	public static String TesselationBaseClassCompartmentGraphical2EditPart_title;

	/**
	 * @generated
	 */
	public static String UnidirectionalLineBaseClassCompartmentGraphicalEditPart_title;

	/**
	 * @generated
	 */
	public static String UnidirectionalLineBaseClassCompartmentGraphical2EditPart_title;

	/**
	 * @generated
	 */
	public static String ConventionalBaseClassCompartmentGraphicalEditPart_title;

	/**
	 * @generated
	 */
	public static String ConventionalBaseClassCompartmentGraphical2EditPart_title;

	/**
	 * @generated
	 */
	public static String CommandName_OpenDiagram;

	/**
	 * @generated
	 */
	public static String NavigatorGroupName_Shape_4006_target;

	/**
	 * @generated
	 */
	public static String NavigatorGroupName_Shape_4006_source;

	/**
	 * @generated
	 */
	public static String NavigatorGroupName_Conventional_2024_incominglinks;

	/**
	 * @generated
	 */
	public static String NavigatorGroupName_Conventional_2024_outgoinglinks;

	/**
	 * @generated
	 */
	public static String NavigatorGroupName_Isoline_2018_incominglinks;

	/**
	 * @generated
	 */
	public static String NavigatorGroupName_Isoline_2018_outgoinglinks;

	/**
	 * @generated
	 */
	public static String NavigatorGroupName_AdjacentPolygons_2020_incominglinks;

	/**
	 * @generated
	 */
	public static String NavigatorGroupName_AdjacentPolygons_2020_outgoinglinks;

	/**
	 * @generated
	 */
	public static String NavigatorGroupName_SpatialAgregation_4001_target;

	/**
	 * @generated
	 */
	public static String NavigatorGroupName_SpatialAgregation_4001_source;

	/**
	 * @generated
	 */
	public static String NavigatorGroupName_Polygon_2013_incominglinks;

	/**
	 * @generated
	 */
	public static String NavigatorGroupName_Polygon_2013_outgoinglinks;

	/**
	 * @generated
	 */
	public static String NavigatorGroupName_Node_2019_incominglinks;

	/**
	 * @generated
	 */
	public static String NavigatorGroupName_Node_2019_outgoinglinks;

	/**
	 * @generated
	 */
	public static String NavigatorGroupName_Tesselation_2022_incominglinks;

	/**
	 * @generated
	 */
	public static String NavigatorGroupName_Tesselation_2022_outgoinglinks;

	/**
	 * @generated
	 */
	public static String NavigatorGroupName_Sampling_2025_incominglinks;

	/**
	 * @generated
	 */
	public static String NavigatorGroupName_Sampling_2025_outgoinglinks;

	/**
	 * @generated
	 */
	public static String NavigatorGroupName_OverlappingTotal_4002_target;

	/**
	 * @generated
	 */
	public static String NavigatorGroupName_OverlappingTotal_4002_source;

	/**
	 * @generated
	 */
	public static String NavigatorGroupName_Line_2015_incominglinks;

	/**
	 * @generated
	 */
	public static String NavigatorGroupName_Line_2015_outgoinglinks;

	/**
	 * @generated
	 */
	public static String NavigatorGroupName_Simple_4004_target;

	/**
	 * @generated
	 */
	public static String NavigatorGroupName_Simple_4004_source;

	/**
	 * @generated
	 */
	public static String NavigatorGroupName_Schema_1000_links;

	/**
	 * @generated
	 */
	public static String NavigatorGroupName_OverlappingPartial_4011_target;

	/**
	 * @generated
	 */
	public static String NavigatorGroupName_OverlappingPartial_4011_source;

	/**
	 * @generated
	 */
	public static String NavigatorGroupName_NetworkAssociation_4009_target;

	/**
	 * @generated
	 */
	public static String NavigatorGroupName_NetworkAssociation_4009_source;

	/**
	 * @generated
	 */
	public static String NavigatorGroupName_Agregation_4007_target;

	/**
	 * @generated
	 */
	public static String NavigatorGroupName_Agregation_4007_source;

	/**
	 * @generated
	 */
	public static String NavigatorGroupName_DisjointTotal_4010_target;

	/**
	 * @generated
	 */
	public static String NavigatorGroupName_DisjointTotal_4010_source;

	/**
	 * @generated
	 */
	public static String NavigatorGroupName_UnidirectionalLine_2023_incominglinks;

	/**
	 * @generated
	 */
	public static String NavigatorGroupName_UnidirectionalLine_2023_outgoinglinks;

	/**
	 * @generated
	 */
	public static String NavigatorGroupName_DisjointPartial_4003_target;

	/**
	 * @generated
	 */
	public static String NavigatorGroupName_DisjointPartial_4003_source;

	/**
	 * @generated
	 */
	public static String NavigatorGroupName_BidirectionalLine_2021_incominglinks;

	/**
	 * @generated
	 */
	public static String NavigatorGroupName_BidirectionalLine_2021_outgoinglinks;

	/**
	 * @generated
	 */
	public static String NavigatorGroupName_Point_2014_incominglinks;

	/**
	 * @generated
	 */
	public static String NavigatorGroupName_Point_2014_outgoinglinks;

	/**
	 * @generated
	 */
	public static String NavigatorGroupName_Scale_4005_target;

	/**
	 * @generated
	 */
	public static String NavigatorGroupName_Scale_4005_source;

	/**
	 * @generated
	 */
	public static String NavigatorGroupName_Spatial_4008_target;

	/**
	 * @generated
	 */
	public static String NavigatorGroupName_Spatial_4008_source;

	/**
	 * @generated
	 */
	public static String NavigatorGroupName_NetworkClass_2016_incominglinks;

	/**
	 * @generated
	 */
	public static String NavigatorGroupName_NetworkClass_2016_outgoinglinks;

	/**
	 * @generated
	 */
	public static String NavigatorActionProvider_OpenDiagramActionName;

	/**
	 * @generated
	 */
	public static String AbstractParser_UnexpectedValueType;

	/**
	 * @generated
	 */
	public static String AbstractParser_WrongStringConversion;

	/**
	 * @generated
	 */
	public static String AbstractParser_UnknownLiteral;

	/**
	 * @generated
	 */
	public static String MessageFormatParser_InvalidInputError;

	/**
	 * @generated
	 */
	public static String OmtgModelingAssistantProviderTitle;

	/**
	 * @generated
	 */
	public static String OmtgModelingAssistantProviderMessage;

	//TODO: put accessor fields manually	
}
