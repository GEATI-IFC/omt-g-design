package omtg.diagram.part;

import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import omtg.AdjacentPolygons;
import omtg.Agregation;
import omtg.Attribute;
import omtg.BidirectionalLine;
import omtg.Conventional;
import omtg.DisjointPartial;
import omtg.DisjointTotal;
import omtg.Isoline;
import omtg.Line;
import omtg.Method;
import omtg.NetworkAssociation;
import omtg.NetworkClass;
import omtg.Node;
import omtg.OmtgPackage;
import omtg.OverlappingPartial;
import omtg.OverlappingTotal;
import omtg.Point;
import omtg.Polygon;
import omtg.Sampling;
import omtg.Scale;
import omtg.Schema;
import omtg.Shape;
import omtg.Simple;
import omtg.Spatial;
import omtg.SpatialAgregation;
import omtg.Tesselation;
import omtg.UnidirectionalLine;
import omtg.diagram.edit.parts.AdjacentPolygonsBaseClassCompartmentGraphical2EditPart;
import omtg.diagram.edit.parts.AdjacentPolygonsBaseClassCompartmentGraphicalEditPart;
import omtg.diagram.edit.parts.AdjacentPolygonsEditPart;
import omtg.diagram.edit.parts.AgregationEditPart;
import omtg.diagram.edit.parts.Attribute10EditPart;
import omtg.diagram.edit.parts.Attribute11EditPart;
import omtg.diagram.edit.parts.Attribute12EditPart;
import omtg.diagram.edit.parts.Attribute2EditPart;
import omtg.diagram.edit.parts.Attribute3EditPart;
import omtg.diagram.edit.parts.Attribute4EditPart;
import omtg.diagram.edit.parts.Attribute5EditPart;
import omtg.diagram.edit.parts.Attribute6EditPart;
import omtg.diagram.edit.parts.Attribute7EditPart;
import omtg.diagram.edit.parts.Attribute8EditPart;
import omtg.diagram.edit.parts.Attribute9EditPart;
import omtg.diagram.edit.parts.AttributeEditPart;
import omtg.diagram.edit.parts.BidirectionalLineBaseClassCompartmentGraphical2EditPart;
import omtg.diagram.edit.parts.BidirectionalLineBaseClassCompartmentGraphicalEditPart;
import omtg.diagram.edit.parts.BidirectionalLineEditPart;
import omtg.diagram.edit.parts.ConventionalBaseClassCompartmentGraphical2EditPart;
import omtg.diagram.edit.parts.ConventionalBaseClassCompartmentGraphicalEditPart;
import omtg.diagram.edit.parts.ConventionalEditPart;
import omtg.diagram.edit.parts.DisjointPartialEditPart;
import omtg.diagram.edit.parts.DisjointTotalEditPart;
import omtg.diagram.edit.parts.IsolineBaseClassCompartmentGraphical2EditPart;
import omtg.diagram.edit.parts.IsolineBaseClassCompartmentGraphicalEditPart;
import omtg.diagram.edit.parts.IsolineEditPart;
import omtg.diagram.edit.parts.LineBaseClassCompartmentGraphical2EditPart;
import omtg.diagram.edit.parts.LineBaseClassCompartmentGraphicalEditPart;
import omtg.diagram.edit.parts.LineEditPart;
import omtg.diagram.edit.parts.Method10EditPart;
import omtg.diagram.edit.parts.Method11EditPart;
import omtg.diagram.edit.parts.Method12EditPart;
import omtg.diagram.edit.parts.Method2EditPart;
import omtg.diagram.edit.parts.Method3EditPart;
import omtg.diagram.edit.parts.Method4EditPart;
import omtg.diagram.edit.parts.Method5EditPart;
import omtg.diagram.edit.parts.Method6EditPart;
import omtg.diagram.edit.parts.Method7EditPart;
import omtg.diagram.edit.parts.Method8EditPart;
import omtg.diagram.edit.parts.Method9EditPart;
import omtg.diagram.edit.parts.MethodEditPart;
import omtg.diagram.edit.parts.NetworkAssociationEditPart;
import omtg.diagram.edit.parts.NetworkClassBaseClassCompartmentGraphical2EditPart;
import omtg.diagram.edit.parts.NetworkClassBaseClassCompartmentGraphicalEditPart;
import omtg.diagram.edit.parts.NetworkClassEditPart;
import omtg.diagram.edit.parts.NodeBaseClassCompartmentGraphical2EditPart;
import omtg.diagram.edit.parts.NodeBaseClassCompartmentGraphicalEditPart;
import omtg.diagram.edit.parts.NodeEditPart;
import omtg.diagram.edit.parts.OverlappingPartialEditPart;
import omtg.diagram.edit.parts.OverlappingTotalEditPart;
import omtg.diagram.edit.parts.PointBaseClassCompartmentGraphical2EditPart;
import omtg.diagram.edit.parts.PointBaseClassCompartmentGraphicalEditPart;
import omtg.diagram.edit.parts.PointEditPart;
import omtg.diagram.edit.parts.PolygonBaseClassCompartmentGraphical2EditPart;
import omtg.diagram.edit.parts.PolygonBaseClassCompartmentGraphicalEditPart;
import omtg.diagram.edit.parts.PolygonEditPart;
import omtg.diagram.edit.parts.SamplingBaseClassCompartmentGraphical2EditPart;
import omtg.diagram.edit.parts.SamplingBaseClassCompartmentGraphicalEditPart;
import omtg.diagram.edit.parts.SamplingEditPart;
import omtg.diagram.edit.parts.ScaleEditPart;
import omtg.diagram.edit.parts.SchemaEditPart;
import omtg.diagram.edit.parts.ShapeEditPart;
import omtg.diagram.edit.parts.SimpleEditPart;
import omtg.diagram.edit.parts.SpatialAgregationEditPart;
import omtg.diagram.edit.parts.SpatialEditPart;
import omtg.diagram.edit.parts.TesselationBaseClassCompartmentGraphical2EditPart;
import omtg.diagram.edit.parts.TesselationBaseClassCompartmentGraphicalEditPart;
import omtg.diagram.edit.parts.TesselationEditPart;
import omtg.diagram.edit.parts.UnidirectionalLineBaseClassCompartmentGraphical2EditPart;
import omtg.diagram.edit.parts.UnidirectionalLineBaseClassCompartmentGraphicalEditPart;
import omtg.diagram.edit.parts.UnidirectionalLineEditPart;
import omtg.diagram.providers.OmtgElementTypes;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.gmf.runtime.notation.View;
import org.eclipse.gmf.tooling.runtime.update.DiagramUpdater;

/**
 * @generated
 */
public class OmtgDiagramUpdater {

	/**
	 * @generated
	 */
	public static List<OmtgNodeDescriptor> getSemanticChildren(View view) {
		switch (OmtgVisualIDRegistry.getVisualID(view)) {
		case SchemaEditPart.VISUAL_ID:
			return getSchema_1000SemanticChildren(view);
		case PolygonBaseClassCompartmentGraphicalEditPart.VISUAL_ID:
			return getPolygonBaseClassCompartmentGraphical_7025SemanticChildren(view);
		case PolygonBaseClassCompartmentGraphical2EditPart.VISUAL_ID:
			return getPolygonBaseClassCompartmentGraphical_7026SemanticChildren(view);
		case PointBaseClassCompartmentGraphicalEditPart.VISUAL_ID:
			return getPointBaseClassCompartmentGraphical_7027SemanticChildren(view);
		case PointBaseClassCompartmentGraphical2EditPart.VISUAL_ID:
			return getPointBaseClassCompartmentGraphical_7028SemanticChildren(view);
		case LineBaseClassCompartmentGraphicalEditPart.VISUAL_ID:
			return getLineBaseClassCompartmentGraphical_7029SemanticChildren(view);
		case LineBaseClassCompartmentGraphical2EditPart.VISUAL_ID:
			return getLineBaseClassCompartmentGraphical_7030SemanticChildren(view);
		case NetworkClassBaseClassCompartmentGraphicalEditPart.VISUAL_ID:
			return getNetworkClassBaseClassCompartmentGraphical_7031SemanticChildren(view);
		case NetworkClassBaseClassCompartmentGraphical2EditPart.VISUAL_ID:
			return getNetworkClassBaseClassCompartmentGraphical_7032SemanticChildren(view);
		case SamplingBaseClassCompartmentGraphicalEditPart.VISUAL_ID:
			return getSamplingBaseClassCompartmentGraphical_7049SemanticChildren(view);
		case SamplingBaseClassCompartmentGraphical2EditPart.VISUAL_ID:
			return getSamplingBaseClassCompartmentGraphical_7050SemanticChildren(view);
		case IsolineBaseClassCompartmentGraphicalEditPart.VISUAL_ID:
			return getIsolineBaseClassCompartmentGraphical_7035SemanticChildren(view);
		case IsolineBaseClassCompartmentGraphical2EditPart.VISUAL_ID:
			return getIsolineBaseClassCompartmentGraphical_7036SemanticChildren(view);
		case NodeBaseClassCompartmentGraphicalEditPart.VISUAL_ID:
			return getNodeBaseClassCompartmentGraphical_7037SemanticChildren(view);
		case NodeBaseClassCompartmentGraphical2EditPart.VISUAL_ID:
			return getNodeBaseClassCompartmentGraphical_7038SemanticChildren(view);
		case AdjacentPolygonsBaseClassCompartmentGraphicalEditPart.VISUAL_ID:
			return getAdjacentPolygonsBaseClassCompartmentGraphical_7039SemanticChildren(view);
		case AdjacentPolygonsBaseClassCompartmentGraphical2EditPart.VISUAL_ID:
			return getAdjacentPolygonsBaseClassCompartmentGraphical_7040SemanticChildren(view);
		case BidirectionalLineBaseClassCompartmentGraphicalEditPart.VISUAL_ID:
			return getBidirectionalLineBaseClassCompartmentGraphical_7041SemanticChildren(view);
		case BidirectionalLineBaseClassCompartmentGraphical2EditPart.VISUAL_ID:
			return getBidirectionalLineBaseClassCompartmentGraphical_7042SemanticChildren(view);
		case TesselationBaseClassCompartmentGraphicalEditPart.VISUAL_ID:
			return getTesselationBaseClassCompartmentGraphical_7043SemanticChildren(view);
		case TesselationBaseClassCompartmentGraphical2EditPart.VISUAL_ID:
			return getTesselationBaseClassCompartmentGraphical_7044SemanticChildren(view);
		case UnidirectionalLineBaseClassCompartmentGraphicalEditPart.VISUAL_ID:
			return getUnidirectionalLineBaseClassCompartmentGraphical_7045SemanticChildren(view);
		case UnidirectionalLineBaseClassCompartmentGraphical2EditPart.VISUAL_ID:
			return getUnidirectionalLineBaseClassCompartmentGraphical_7046SemanticChildren(view);
		case ConventionalBaseClassCompartmentGraphicalEditPart.VISUAL_ID:
			return getConventionalBaseClassCompartmentGraphical_7047SemanticChildren(view);
		case ConventionalBaseClassCompartmentGraphical2EditPart.VISUAL_ID:
			return getConventionalBaseClassCompartmentGraphical_7048SemanticChildren(view);
		}
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<OmtgNodeDescriptor> getSchema_1000SemanticChildren(
			View view) {
		if (!view.isSetElement()) {
			return Collections.emptyList();
		}
		Schema modelElement = (Schema) view.getElement();
		LinkedList<OmtgNodeDescriptor> result = new LinkedList<OmtgNodeDescriptor>();
		for (Iterator<?> it = modelElement.getClass_().iterator(); it.hasNext();) {
			omtg.element childElement = (omtg.element) it.next();
			int visualID = OmtgVisualIDRegistry.getNodeVisualID(view,
					childElement);
			if (visualID == PolygonEditPart.VISUAL_ID) {
				result.add(new OmtgNodeDescriptor(childElement, visualID));
				continue;
			}
			if (visualID == PointEditPart.VISUAL_ID) {
				result.add(new OmtgNodeDescriptor(childElement, visualID));
				continue;
			}
			if (visualID == LineEditPart.VISUAL_ID) {
				result.add(new OmtgNodeDescriptor(childElement, visualID));
				continue;
			}
			if (visualID == NetworkClassEditPart.VISUAL_ID) {
				result.add(new OmtgNodeDescriptor(childElement, visualID));
				continue;
			}
			if (visualID == SamplingEditPart.VISUAL_ID) {
				result.add(new OmtgNodeDescriptor(childElement, visualID));
				continue;
			}
			if (visualID == IsolineEditPart.VISUAL_ID) {
				result.add(new OmtgNodeDescriptor(childElement, visualID));
				continue;
			}
			if (visualID == NodeEditPart.VISUAL_ID) {
				result.add(new OmtgNodeDescriptor(childElement, visualID));
				continue;
			}
			if (visualID == AdjacentPolygonsEditPart.VISUAL_ID) {
				result.add(new OmtgNodeDescriptor(childElement, visualID));
				continue;
			}
			if (visualID == BidirectionalLineEditPart.VISUAL_ID) {
				result.add(new OmtgNodeDescriptor(childElement, visualID));
				continue;
			}
			if (visualID == TesselationEditPart.VISUAL_ID) {
				result.add(new OmtgNodeDescriptor(childElement, visualID));
				continue;
			}
			if (visualID == UnidirectionalLineEditPart.VISUAL_ID) {
				result.add(new OmtgNodeDescriptor(childElement, visualID));
				continue;
			}
			if (visualID == ConventionalEditPart.VISUAL_ID) {
				result.add(new OmtgNodeDescriptor(childElement, visualID));
				continue;
			}
		}
		return result;
	}

	/**
	 * @generated
	 */
	public static List<OmtgNodeDescriptor> getPolygonBaseClassCompartmentGraphical_7025SemanticChildren(
			View view) {
		if (false == view.eContainer() instanceof View) {
			return Collections.emptyList();
		}
		View containerView = (View) view.eContainer();
		if (!containerView.isSetElement()) {
			return Collections.emptyList();
		}
		Polygon modelElement = (Polygon) containerView.getElement();
		LinkedList<OmtgNodeDescriptor> result = new LinkedList<OmtgNodeDescriptor>();
		for (Iterator<?> it = modelElement.getAttribute().iterator(); it
				.hasNext();) {
			Attribute childElement = (Attribute) it.next();
			int visualID = OmtgVisualIDRegistry.getNodeVisualID(view,
					childElement);
			if (visualID == AttributeEditPart.VISUAL_ID) {
				result.add(new OmtgNodeDescriptor(childElement, visualID));
				continue;
			}
		}
		return result;
	}

	/**
	 * @generated
	 */
	public static List<OmtgNodeDescriptor> getPolygonBaseClassCompartmentGraphical_7026SemanticChildren(
			View view) {
		if (false == view.eContainer() instanceof View) {
			return Collections.emptyList();
		}
		View containerView = (View) view.eContainer();
		if (!containerView.isSetElement()) {
			return Collections.emptyList();
		}
		Polygon modelElement = (Polygon) containerView.getElement();
		LinkedList<OmtgNodeDescriptor> result = new LinkedList<OmtgNodeDescriptor>();
		for (Iterator<?> it = modelElement.getMethod().iterator(); it.hasNext();) {
			Method childElement = (Method) it.next();
			int visualID = OmtgVisualIDRegistry.getNodeVisualID(view,
					childElement);
			if (visualID == MethodEditPart.VISUAL_ID) {
				result.add(new OmtgNodeDescriptor(childElement, visualID));
				continue;
			}
		}
		return result;
	}

	/**
	 * @generated
	 */
	public static List<OmtgNodeDescriptor> getPointBaseClassCompartmentGraphical_7027SemanticChildren(
			View view) {
		if (false == view.eContainer() instanceof View) {
			return Collections.emptyList();
		}
		View containerView = (View) view.eContainer();
		if (!containerView.isSetElement()) {
			return Collections.emptyList();
		}
		Point modelElement = (Point) containerView.getElement();
		LinkedList<OmtgNodeDescriptor> result = new LinkedList<OmtgNodeDescriptor>();
		for (Iterator<?> it = modelElement.getAttribute().iterator(); it
				.hasNext();) {
			Attribute childElement = (Attribute) it.next();
			int visualID = OmtgVisualIDRegistry.getNodeVisualID(view,
					childElement);
			if (visualID == Attribute2EditPart.VISUAL_ID) {
				result.add(new OmtgNodeDescriptor(childElement, visualID));
				continue;
			}
		}
		return result;
	}

	/**
	 * @generated
	 */
	public static List<OmtgNodeDescriptor> getPointBaseClassCompartmentGraphical_7028SemanticChildren(
			View view) {
		if (false == view.eContainer() instanceof View) {
			return Collections.emptyList();
		}
		View containerView = (View) view.eContainer();
		if (!containerView.isSetElement()) {
			return Collections.emptyList();
		}
		Point modelElement = (Point) containerView.getElement();
		LinkedList<OmtgNodeDescriptor> result = new LinkedList<OmtgNodeDescriptor>();
		for (Iterator<?> it = modelElement.getMethod().iterator(); it.hasNext();) {
			Method childElement = (Method) it.next();
			int visualID = OmtgVisualIDRegistry.getNodeVisualID(view,
					childElement);
			if (visualID == Method2EditPart.VISUAL_ID) {
				result.add(new OmtgNodeDescriptor(childElement, visualID));
				continue;
			}
		}
		return result;
	}

	/**
	 * @generated
	 */
	public static List<OmtgNodeDescriptor> getLineBaseClassCompartmentGraphical_7029SemanticChildren(
			View view) {
		if (false == view.eContainer() instanceof View) {
			return Collections.emptyList();
		}
		View containerView = (View) view.eContainer();
		if (!containerView.isSetElement()) {
			return Collections.emptyList();
		}
		Line modelElement = (Line) containerView.getElement();
		LinkedList<OmtgNodeDescriptor> result = new LinkedList<OmtgNodeDescriptor>();
		for (Iterator<?> it = modelElement.getAttribute().iterator(); it
				.hasNext();) {
			Attribute childElement = (Attribute) it.next();
			int visualID = OmtgVisualIDRegistry.getNodeVisualID(view,
					childElement);
			if (visualID == Attribute3EditPart.VISUAL_ID) {
				result.add(new OmtgNodeDescriptor(childElement, visualID));
				continue;
			}
		}
		return result;
	}

	/**
	 * @generated
	 */
	public static List<OmtgNodeDescriptor> getLineBaseClassCompartmentGraphical_7030SemanticChildren(
			View view) {
		if (false == view.eContainer() instanceof View) {
			return Collections.emptyList();
		}
		View containerView = (View) view.eContainer();
		if (!containerView.isSetElement()) {
			return Collections.emptyList();
		}
		Line modelElement = (Line) containerView.getElement();
		LinkedList<OmtgNodeDescriptor> result = new LinkedList<OmtgNodeDescriptor>();
		for (Iterator<?> it = modelElement.getMethod().iterator(); it.hasNext();) {
			Method childElement = (Method) it.next();
			int visualID = OmtgVisualIDRegistry.getNodeVisualID(view,
					childElement);
			if (visualID == Method3EditPart.VISUAL_ID) {
				result.add(new OmtgNodeDescriptor(childElement, visualID));
				continue;
			}
		}
		return result;
	}

	/**
	 * @generated
	 */
	public static List<OmtgNodeDescriptor> getNetworkClassBaseClassCompartmentGraphical_7031SemanticChildren(
			View view) {
		if (false == view.eContainer() instanceof View) {
			return Collections.emptyList();
		}
		View containerView = (View) view.eContainer();
		if (!containerView.isSetElement()) {
			return Collections.emptyList();
		}
		NetworkClass modelElement = (NetworkClass) containerView.getElement();
		LinkedList<OmtgNodeDescriptor> result = new LinkedList<OmtgNodeDescriptor>();
		for (Iterator<?> it = modelElement.getAttribute().iterator(); it
				.hasNext();) {
			Attribute childElement = (Attribute) it.next();
			int visualID = OmtgVisualIDRegistry.getNodeVisualID(view,
					childElement);
			if (visualID == Attribute4EditPart.VISUAL_ID) {
				result.add(new OmtgNodeDescriptor(childElement, visualID));
				continue;
			}
		}
		return result;
	}

	/**
	 * @generated
	 */
	public static List<OmtgNodeDescriptor> getNetworkClassBaseClassCompartmentGraphical_7032SemanticChildren(
			View view) {
		if (false == view.eContainer() instanceof View) {
			return Collections.emptyList();
		}
		View containerView = (View) view.eContainer();
		if (!containerView.isSetElement()) {
			return Collections.emptyList();
		}
		NetworkClass modelElement = (NetworkClass) containerView.getElement();
		LinkedList<OmtgNodeDescriptor> result = new LinkedList<OmtgNodeDescriptor>();
		for (Iterator<?> it = modelElement.getMethod().iterator(); it.hasNext();) {
			Method childElement = (Method) it.next();
			int visualID = OmtgVisualIDRegistry.getNodeVisualID(view,
					childElement);
			if (visualID == Method4EditPart.VISUAL_ID) {
				result.add(new OmtgNodeDescriptor(childElement, visualID));
				continue;
			}
		}
		return result;
	}

	/**
	 * @generated
	 */
	public static List<OmtgNodeDescriptor> getSamplingBaseClassCompartmentGraphical_7049SemanticChildren(
			View view) {
		if (false == view.eContainer() instanceof View) {
			return Collections.emptyList();
		}
		View containerView = (View) view.eContainer();
		if (!containerView.isSetElement()) {
			return Collections.emptyList();
		}
		Sampling modelElement = (Sampling) containerView.getElement();
		LinkedList<OmtgNodeDescriptor> result = new LinkedList<OmtgNodeDescriptor>();
		for (Iterator<?> it = modelElement.getAttribute().iterator(); it
				.hasNext();) {
			Attribute childElement = (Attribute) it.next();
			int visualID = OmtgVisualIDRegistry.getNodeVisualID(view,
					childElement);
			if (visualID == Attribute5EditPart.VISUAL_ID) {
				result.add(new OmtgNodeDescriptor(childElement, visualID));
				continue;
			}
		}
		return result;
	}

	/**
	 * @generated
	 */
	public static List<OmtgNodeDescriptor> getSamplingBaseClassCompartmentGraphical_7050SemanticChildren(
			View view) {
		if (false == view.eContainer() instanceof View) {
			return Collections.emptyList();
		}
		View containerView = (View) view.eContainer();
		if (!containerView.isSetElement()) {
			return Collections.emptyList();
		}
		Sampling modelElement = (Sampling) containerView.getElement();
		LinkedList<OmtgNodeDescriptor> result = new LinkedList<OmtgNodeDescriptor>();
		for (Iterator<?> it = modelElement.getMethod().iterator(); it.hasNext();) {
			Method childElement = (Method) it.next();
			int visualID = OmtgVisualIDRegistry.getNodeVisualID(view,
					childElement);
			if (visualID == Method5EditPart.VISUAL_ID) {
				result.add(new OmtgNodeDescriptor(childElement, visualID));
				continue;
			}
		}
		return result;
	}

	/**
	 * @generated
	 */
	public static List<OmtgNodeDescriptor> getIsolineBaseClassCompartmentGraphical_7035SemanticChildren(
			View view) {
		if (false == view.eContainer() instanceof View) {
			return Collections.emptyList();
		}
		View containerView = (View) view.eContainer();
		if (!containerView.isSetElement()) {
			return Collections.emptyList();
		}
		Isoline modelElement = (Isoline) containerView.getElement();
		LinkedList<OmtgNodeDescriptor> result = new LinkedList<OmtgNodeDescriptor>();
		for (Iterator<?> it = modelElement.getAttribute().iterator(); it
				.hasNext();) {
			Attribute childElement = (Attribute) it.next();
			int visualID = OmtgVisualIDRegistry.getNodeVisualID(view,
					childElement);
			if (visualID == Attribute6EditPart.VISUAL_ID) {
				result.add(new OmtgNodeDescriptor(childElement, visualID));
				continue;
			}
		}
		return result;
	}

	/**
	 * @generated
	 */
	public static List<OmtgNodeDescriptor> getIsolineBaseClassCompartmentGraphical_7036SemanticChildren(
			View view) {
		if (false == view.eContainer() instanceof View) {
			return Collections.emptyList();
		}
		View containerView = (View) view.eContainer();
		if (!containerView.isSetElement()) {
			return Collections.emptyList();
		}
		Isoline modelElement = (Isoline) containerView.getElement();
		LinkedList<OmtgNodeDescriptor> result = new LinkedList<OmtgNodeDescriptor>();
		for (Iterator<?> it = modelElement.getMethod().iterator(); it.hasNext();) {
			Method childElement = (Method) it.next();
			int visualID = OmtgVisualIDRegistry.getNodeVisualID(view,
					childElement);
			if (visualID == Method6EditPart.VISUAL_ID) {
				result.add(new OmtgNodeDescriptor(childElement, visualID));
				continue;
			}
		}
		return result;
	}

	/**
	 * @generated
	 */
	public static List<OmtgNodeDescriptor> getNodeBaseClassCompartmentGraphical_7037SemanticChildren(
			View view) {
		if (false == view.eContainer() instanceof View) {
			return Collections.emptyList();
		}
		View containerView = (View) view.eContainer();
		if (!containerView.isSetElement()) {
			return Collections.emptyList();
		}
		Node modelElement = (Node) containerView.getElement();
		LinkedList<OmtgNodeDescriptor> result = new LinkedList<OmtgNodeDescriptor>();
		for (Iterator<?> it = modelElement.getAttribute().iterator(); it
				.hasNext();) {
			Attribute childElement = (Attribute) it.next();
			int visualID = OmtgVisualIDRegistry.getNodeVisualID(view,
					childElement);
			if (visualID == Attribute7EditPart.VISUAL_ID) {
				result.add(new OmtgNodeDescriptor(childElement, visualID));
				continue;
			}
		}
		return result;
	}

	/**
	 * @generated
	 */
	public static List<OmtgNodeDescriptor> getNodeBaseClassCompartmentGraphical_7038SemanticChildren(
			View view) {
		if (false == view.eContainer() instanceof View) {
			return Collections.emptyList();
		}
		View containerView = (View) view.eContainer();
		if (!containerView.isSetElement()) {
			return Collections.emptyList();
		}
		Node modelElement = (Node) containerView.getElement();
		LinkedList<OmtgNodeDescriptor> result = new LinkedList<OmtgNodeDescriptor>();
		for (Iterator<?> it = modelElement.getMethod().iterator(); it.hasNext();) {
			Method childElement = (Method) it.next();
			int visualID = OmtgVisualIDRegistry.getNodeVisualID(view,
					childElement);
			if (visualID == Method7EditPart.VISUAL_ID) {
				result.add(new OmtgNodeDescriptor(childElement, visualID));
				continue;
			}
		}
		return result;
	}

	/**
	 * @generated
	 */
	public static List<OmtgNodeDescriptor> getAdjacentPolygonsBaseClassCompartmentGraphical_7039SemanticChildren(
			View view) {
		if (false == view.eContainer() instanceof View) {
			return Collections.emptyList();
		}
		View containerView = (View) view.eContainer();
		if (!containerView.isSetElement()) {
			return Collections.emptyList();
		}
		AdjacentPolygons modelElement = (AdjacentPolygons) containerView
				.getElement();
		LinkedList<OmtgNodeDescriptor> result = new LinkedList<OmtgNodeDescriptor>();
		for (Iterator<?> it = modelElement.getAttribute().iterator(); it
				.hasNext();) {
			Attribute childElement = (Attribute) it.next();
			int visualID = OmtgVisualIDRegistry.getNodeVisualID(view,
					childElement);
			if (visualID == Attribute8EditPart.VISUAL_ID) {
				result.add(new OmtgNodeDescriptor(childElement, visualID));
				continue;
			}
		}
		return result;
	}

	/**
	 * @generated
	 */
	public static List<OmtgNodeDescriptor> getAdjacentPolygonsBaseClassCompartmentGraphical_7040SemanticChildren(
			View view) {
		if (false == view.eContainer() instanceof View) {
			return Collections.emptyList();
		}
		View containerView = (View) view.eContainer();
		if (!containerView.isSetElement()) {
			return Collections.emptyList();
		}
		AdjacentPolygons modelElement = (AdjacentPolygons) containerView
				.getElement();
		LinkedList<OmtgNodeDescriptor> result = new LinkedList<OmtgNodeDescriptor>();
		for (Iterator<?> it = modelElement.getMethod().iterator(); it.hasNext();) {
			Method childElement = (Method) it.next();
			int visualID = OmtgVisualIDRegistry.getNodeVisualID(view,
					childElement);
			if (visualID == Method8EditPart.VISUAL_ID) {
				result.add(new OmtgNodeDescriptor(childElement, visualID));
				continue;
			}
		}
		return result;
	}

	/**
	 * @generated
	 */
	public static List<OmtgNodeDescriptor> getBidirectionalLineBaseClassCompartmentGraphical_7041SemanticChildren(
			View view) {
		if (false == view.eContainer() instanceof View) {
			return Collections.emptyList();
		}
		View containerView = (View) view.eContainer();
		if (!containerView.isSetElement()) {
			return Collections.emptyList();
		}
		BidirectionalLine modelElement = (BidirectionalLine) containerView
				.getElement();
		LinkedList<OmtgNodeDescriptor> result = new LinkedList<OmtgNodeDescriptor>();
		for (Iterator<?> it = modelElement.getAttribute().iterator(); it
				.hasNext();) {
			Attribute childElement = (Attribute) it.next();
			int visualID = OmtgVisualIDRegistry.getNodeVisualID(view,
					childElement);
			if (visualID == Attribute9EditPart.VISUAL_ID) {
				result.add(new OmtgNodeDescriptor(childElement, visualID));
				continue;
			}
		}
		return result;
	}

	/**
	 * @generated
	 */
	public static List<OmtgNodeDescriptor> getBidirectionalLineBaseClassCompartmentGraphical_7042SemanticChildren(
			View view) {
		if (false == view.eContainer() instanceof View) {
			return Collections.emptyList();
		}
		View containerView = (View) view.eContainer();
		if (!containerView.isSetElement()) {
			return Collections.emptyList();
		}
		BidirectionalLine modelElement = (BidirectionalLine) containerView
				.getElement();
		LinkedList<OmtgNodeDescriptor> result = new LinkedList<OmtgNodeDescriptor>();
		for (Iterator<?> it = modelElement.getMethod().iterator(); it.hasNext();) {
			Method childElement = (Method) it.next();
			int visualID = OmtgVisualIDRegistry.getNodeVisualID(view,
					childElement);
			if (visualID == Method9EditPart.VISUAL_ID) {
				result.add(new OmtgNodeDescriptor(childElement, visualID));
				continue;
			}
		}
		return result;
	}

	/**
	 * @generated
	 */
	public static List<OmtgNodeDescriptor> getTesselationBaseClassCompartmentGraphical_7043SemanticChildren(
			View view) {
		if (false == view.eContainer() instanceof View) {
			return Collections.emptyList();
		}
		View containerView = (View) view.eContainer();
		if (!containerView.isSetElement()) {
			return Collections.emptyList();
		}
		Tesselation modelElement = (Tesselation) containerView.getElement();
		LinkedList<OmtgNodeDescriptor> result = new LinkedList<OmtgNodeDescriptor>();
		for (Iterator<?> it = modelElement.getAttribute().iterator(); it
				.hasNext();) {
			Attribute childElement = (Attribute) it.next();
			int visualID = OmtgVisualIDRegistry.getNodeVisualID(view,
					childElement);
			if (visualID == Attribute10EditPart.VISUAL_ID) {
				result.add(new OmtgNodeDescriptor(childElement, visualID));
				continue;
			}
		}
		return result;
	}

	/**
	 * @generated
	 */
	public static List<OmtgNodeDescriptor> getTesselationBaseClassCompartmentGraphical_7044SemanticChildren(
			View view) {
		if (false == view.eContainer() instanceof View) {
			return Collections.emptyList();
		}
		View containerView = (View) view.eContainer();
		if (!containerView.isSetElement()) {
			return Collections.emptyList();
		}
		Tesselation modelElement = (Tesselation) containerView.getElement();
		LinkedList<OmtgNodeDescriptor> result = new LinkedList<OmtgNodeDescriptor>();
		for (Iterator<?> it = modelElement.getMethod().iterator(); it.hasNext();) {
			Method childElement = (Method) it.next();
			int visualID = OmtgVisualIDRegistry.getNodeVisualID(view,
					childElement);
			if (visualID == Method10EditPart.VISUAL_ID) {
				result.add(new OmtgNodeDescriptor(childElement, visualID));
				continue;
			}
		}
		return result;
	}

	/**
	 * @generated
	 */
	public static List<OmtgNodeDescriptor> getUnidirectionalLineBaseClassCompartmentGraphical_7045SemanticChildren(
			View view) {
		if (false == view.eContainer() instanceof View) {
			return Collections.emptyList();
		}
		View containerView = (View) view.eContainer();
		if (!containerView.isSetElement()) {
			return Collections.emptyList();
		}
		UnidirectionalLine modelElement = (UnidirectionalLine) containerView
				.getElement();
		LinkedList<OmtgNodeDescriptor> result = new LinkedList<OmtgNodeDescriptor>();
		for (Iterator<?> it = modelElement.getAttribute().iterator(); it
				.hasNext();) {
			Attribute childElement = (Attribute) it.next();
			int visualID = OmtgVisualIDRegistry.getNodeVisualID(view,
					childElement);
			if (visualID == Attribute11EditPart.VISUAL_ID) {
				result.add(new OmtgNodeDescriptor(childElement, visualID));
				continue;
			}
		}
		return result;
	}

	/**
	 * @generated
	 */
	public static List<OmtgNodeDescriptor> getUnidirectionalLineBaseClassCompartmentGraphical_7046SemanticChildren(
			View view) {
		if (false == view.eContainer() instanceof View) {
			return Collections.emptyList();
		}
		View containerView = (View) view.eContainer();
		if (!containerView.isSetElement()) {
			return Collections.emptyList();
		}
		UnidirectionalLine modelElement = (UnidirectionalLine) containerView
				.getElement();
		LinkedList<OmtgNodeDescriptor> result = new LinkedList<OmtgNodeDescriptor>();
		for (Iterator<?> it = modelElement.getMethod().iterator(); it.hasNext();) {
			Method childElement = (Method) it.next();
			int visualID = OmtgVisualIDRegistry.getNodeVisualID(view,
					childElement);
			if (visualID == Method11EditPart.VISUAL_ID) {
				result.add(new OmtgNodeDescriptor(childElement, visualID));
				continue;
			}
		}
		return result;
	}

	/**
	 * @generated
	 */
	public static List<OmtgNodeDescriptor> getConventionalBaseClassCompartmentGraphical_7047SemanticChildren(
			View view) {
		if (false == view.eContainer() instanceof View) {
			return Collections.emptyList();
		}
		View containerView = (View) view.eContainer();
		if (!containerView.isSetElement()) {
			return Collections.emptyList();
		}
		Conventional modelElement = (Conventional) containerView.getElement();
		LinkedList<OmtgNodeDescriptor> result = new LinkedList<OmtgNodeDescriptor>();
		for (Iterator<?> it = modelElement.getAttribute().iterator(); it
				.hasNext();) {
			Attribute childElement = (Attribute) it.next();
			int visualID = OmtgVisualIDRegistry.getNodeVisualID(view,
					childElement);
			if (visualID == Attribute12EditPart.VISUAL_ID) {
				result.add(new OmtgNodeDescriptor(childElement, visualID));
				continue;
			}
		}
		return result;
	}

	/**
	 * @generated
	 */
	public static List<OmtgNodeDescriptor> getConventionalBaseClassCompartmentGraphical_7048SemanticChildren(
			View view) {
		if (false == view.eContainer() instanceof View) {
			return Collections.emptyList();
		}
		View containerView = (View) view.eContainer();
		if (!containerView.isSetElement()) {
			return Collections.emptyList();
		}
		Conventional modelElement = (Conventional) containerView.getElement();
		LinkedList<OmtgNodeDescriptor> result = new LinkedList<OmtgNodeDescriptor>();
		for (Iterator<?> it = modelElement.getMethod().iterator(); it.hasNext();) {
			Method childElement = (Method) it.next();
			int visualID = OmtgVisualIDRegistry.getNodeVisualID(view,
					childElement);
			if (visualID == Method12EditPart.VISUAL_ID) {
				result.add(new OmtgNodeDescriptor(childElement, visualID));
				continue;
			}
		}
		return result;
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getContainedLinks(View view) {
		switch (OmtgVisualIDRegistry.getVisualID(view)) {
		case SchemaEditPart.VISUAL_ID:
			return getSchema_1000ContainedLinks(view);
		case PolygonEditPart.VISUAL_ID:
			return getPolygon_2013ContainedLinks(view);
		case PointEditPart.VISUAL_ID:
			return getPoint_2014ContainedLinks(view);
		case LineEditPart.VISUAL_ID:
			return getLine_2015ContainedLinks(view);
		case NetworkClassEditPart.VISUAL_ID:
			return getNetworkClass_2016ContainedLinks(view);
		case SamplingEditPart.VISUAL_ID:
			return getSampling_2025ContainedLinks(view);
		case IsolineEditPart.VISUAL_ID:
			return getIsoline_2018ContainedLinks(view);
		case NodeEditPart.VISUAL_ID:
			return getNode_2019ContainedLinks(view);
		case AdjacentPolygonsEditPart.VISUAL_ID:
			return getAdjacentPolygons_2020ContainedLinks(view);
		case BidirectionalLineEditPart.VISUAL_ID:
			return getBidirectionalLine_2021ContainedLinks(view);
		case TesselationEditPart.VISUAL_ID:
			return getTesselation_2022ContainedLinks(view);
		case UnidirectionalLineEditPart.VISUAL_ID:
			return getUnidirectionalLine_2023ContainedLinks(view);
		case ConventionalEditPart.VISUAL_ID:
			return getConventional_2024ContainedLinks(view);
		case AttributeEditPart.VISUAL_ID:
			return getAttribute_3001ContainedLinks(view);
		case MethodEditPart.VISUAL_ID:
			return getMethod_3012ContainedLinks(view);
		case Attribute2EditPart.VISUAL_ID:
			return getAttribute_3002ContainedLinks(view);
		case Method2EditPart.VISUAL_ID:
			return getMethod_3013ContainedLinks(view);
		case Attribute3EditPart.VISUAL_ID:
			return getAttribute_3003ContainedLinks(view);
		case Method3EditPart.VISUAL_ID:
			return getMethod_3014ContainedLinks(view);
		case Attribute4EditPart.VISUAL_ID:
			return getAttribute_3004ContainedLinks(view);
		case Method4EditPart.VISUAL_ID:
			return getMethod_3015ContainedLinks(view);
		case Attribute5EditPart.VISUAL_ID:
			return getAttribute_3005ContainedLinks(view);
		case Method5EditPart.VISUAL_ID:
			return getMethod_3016ContainedLinks(view);
		case Attribute6EditPart.VISUAL_ID:
			return getAttribute_3006ContainedLinks(view);
		case Method6EditPart.VISUAL_ID:
			return getMethod_3017ContainedLinks(view);
		case Attribute7EditPart.VISUAL_ID:
			return getAttribute_3007ContainedLinks(view);
		case Method7EditPart.VISUAL_ID:
			return getMethod_3018ContainedLinks(view);
		case Attribute8EditPart.VISUAL_ID:
			return getAttribute_3008ContainedLinks(view);
		case Method8EditPart.VISUAL_ID:
			return getMethod_3019ContainedLinks(view);
		case Attribute9EditPart.VISUAL_ID:
			return getAttribute_3009ContainedLinks(view);
		case Method9EditPart.VISUAL_ID:
			return getMethod_3020ContainedLinks(view);
		case Attribute10EditPart.VISUAL_ID:
			return getAttribute_3010ContainedLinks(view);
		case Method10EditPart.VISUAL_ID:
			return getMethod_3021ContainedLinks(view);
		case Attribute11EditPart.VISUAL_ID:
			return getAttribute_3011ContainedLinks(view);
		case Method11EditPart.VISUAL_ID:
			return getMethod_3023ContainedLinks(view);
		case Attribute12EditPart.VISUAL_ID:
			return getAttribute_3022ContainedLinks(view);
		case Method12EditPart.VISUAL_ID:
			return getMethod_3024ContainedLinks(view);
		case SpatialAgregationEditPart.VISUAL_ID:
			return getSpatialAgregation_4001ContainedLinks(view);
		case OverlappingTotalEditPart.VISUAL_ID:
			return getOverlappingTotal_4002ContainedLinks(view);
		case DisjointPartialEditPart.VISUAL_ID:
			return getDisjointPartial_4003ContainedLinks(view);
		case SimpleEditPart.VISUAL_ID:
			return getSimple_4004ContainedLinks(view);
		case ScaleEditPart.VISUAL_ID:
			return getScale_4005ContainedLinks(view);
		case ShapeEditPart.VISUAL_ID:
			return getShape_4006ContainedLinks(view);
		case AgregationEditPart.VISUAL_ID:
			return getAgregation_4007ContainedLinks(view);
		case SpatialEditPart.VISUAL_ID:
			return getSpatial_4008ContainedLinks(view);
		case NetworkAssociationEditPart.VISUAL_ID:
			return getNetworkAssociation_4009ContainedLinks(view);
		case DisjointTotalEditPart.VISUAL_ID:
			return getDisjointTotal_4010ContainedLinks(view);
		case OverlappingPartialEditPart.VISUAL_ID:
			return getOverlappingPartial_4011ContainedLinks(view);
		}
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getIncomingLinks(View view) {
		switch (OmtgVisualIDRegistry.getVisualID(view)) {
		case PolygonEditPart.VISUAL_ID:
			return getPolygon_2013IncomingLinks(view);
		case PointEditPart.VISUAL_ID:
			return getPoint_2014IncomingLinks(view);
		case LineEditPart.VISUAL_ID:
			return getLine_2015IncomingLinks(view);
		case NetworkClassEditPart.VISUAL_ID:
			return getNetworkClass_2016IncomingLinks(view);
		case SamplingEditPart.VISUAL_ID:
			return getSampling_2025IncomingLinks(view);
		case IsolineEditPart.VISUAL_ID:
			return getIsoline_2018IncomingLinks(view);
		case NodeEditPart.VISUAL_ID:
			return getNode_2019IncomingLinks(view);
		case AdjacentPolygonsEditPart.VISUAL_ID:
			return getAdjacentPolygons_2020IncomingLinks(view);
		case BidirectionalLineEditPart.VISUAL_ID:
			return getBidirectionalLine_2021IncomingLinks(view);
		case TesselationEditPart.VISUAL_ID:
			return getTesselation_2022IncomingLinks(view);
		case UnidirectionalLineEditPart.VISUAL_ID:
			return getUnidirectionalLine_2023IncomingLinks(view);
		case ConventionalEditPart.VISUAL_ID:
			return getConventional_2024IncomingLinks(view);
		case AttributeEditPart.VISUAL_ID:
			return getAttribute_3001IncomingLinks(view);
		case MethodEditPart.VISUAL_ID:
			return getMethod_3012IncomingLinks(view);
		case Attribute2EditPart.VISUAL_ID:
			return getAttribute_3002IncomingLinks(view);
		case Method2EditPart.VISUAL_ID:
			return getMethod_3013IncomingLinks(view);
		case Attribute3EditPart.VISUAL_ID:
			return getAttribute_3003IncomingLinks(view);
		case Method3EditPart.VISUAL_ID:
			return getMethod_3014IncomingLinks(view);
		case Attribute4EditPart.VISUAL_ID:
			return getAttribute_3004IncomingLinks(view);
		case Method4EditPart.VISUAL_ID:
			return getMethod_3015IncomingLinks(view);
		case Attribute5EditPart.VISUAL_ID:
			return getAttribute_3005IncomingLinks(view);
		case Method5EditPart.VISUAL_ID:
			return getMethod_3016IncomingLinks(view);
		case Attribute6EditPart.VISUAL_ID:
			return getAttribute_3006IncomingLinks(view);
		case Method6EditPart.VISUAL_ID:
			return getMethod_3017IncomingLinks(view);
		case Attribute7EditPart.VISUAL_ID:
			return getAttribute_3007IncomingLinks(view);
		case Method7EditPart.VISUAL_ID:
			return getMethod_3018IncomingLinks(view);
		case Attribute8EditPart.VISUAL_ID:
			return getAttribute_3008IncomingLinks(view);
		case Method8EditPart.VISUAL_ID:
			return getMethod_3019IncomingLinks(view);
		case Attribute9EditPart.VISUAL_ID:
			return getAttribute_3009IncomingLinks(view);
		case Method9EditPart.VISUAL_ID:
			return getMethod_3020IncomingLinks(view);
		case Attribute10EditPart.VISUAL_ID:
			return getAttribute_3010IncomingLinks(view);
		case Method10EditPart.VISUAL_ID:
			return getMethod_3021IncomingLinks(view);
		case Attribute11EditPart.VISUAL_ID:
			return getAttribute_3011IncomingLinks(view);
		case Method11EditPart.VISUAL_ID:
			return getMethod_3023IncomingLinks(view);
		case Attribute12EditPart.VISUAL_ID:
			return getAttribute_3022IncomingLinks(view);
		case Method12EditPart.VISUAL_ID:
			return getMethod_3024IncomingLinks(view);
		case SpatialAgregationEditPart.VISUAL_ID:
			return getSpatialAgregation_4001IncomingLinks(view);
		case OverlappingTotalEditPart.VISUAL_ID:
			return getOverlappingTotal_4002IncomingLinks(view);
		case DisjointPartialEditPart.VISUAL_ID:
			return getDisjointPartial_4003IncomingLinks(view);
		case SimpleEditPart.VISUAL_ID:
			return getSimple_4004IncomingLinks(view);
		case ScaleEditPart.VISUAL_ID:
			return getScale_4005IncomingLinks(view);
		case ShapeEditPart.VISUAL_ID:
			return getShape_4006IncomingLinks(view);
		case AgregationEditPart.VISUAL_ID:
			return getAgregation_4007IncomingLinks(view);
		case SpatialEditPart.VISUAL_ID:
			return getSpatial_4008IncomingLinks(view);
		case NetworkAssociationEditPart.VISUAL_ID:
			return getNetworkAssociation_4009IncomingLinks(view);
		case DisjointTotalEditPart.VISUAL_ID:
			return getDisjointTotal_4010IncomingLinks(view);
		case OverlappingPartialEditPart.VISUAL_ID:
			return getOverlappingPartial_4011IncomingLinks(view);
		}
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getOutgoingLinks(View view) {
		switch (OmtgVisualIDRegistry.getVisualID(view)) {
		case PolygonEditPart.VISUAL_ID:
			return getPolygon_2013OutgoingLinks(view);
		case PointEditPart.VISUAL_ID:
			return getPoint_2014OutgoingLinks(view);
		case LineEditPart.VISUAL_ID:
			return getLine_2015OutgoingLinks(view);
		case NetworkClassEditPart.VISUAL_ID:
			return getNetworkClass_2016OutgoingLinks(view);
		case SamplingEditPart.VISUAL_ID:
			return getSampling_2025OutgoingLinks(view);
		case IsolineEditPart.VISUAL_ID:
			return getIsoline_2018OutgoingLinks(view);
		case NodeEditPart.VISUAL_ID:
			return getNode_2019OutgoingLinks(view);
		case AdjacentPolygonsEditPart.VISUAL_ID:
			return getAdjacentPolygons_2020OutgoingLinks(view);
		case BidirectionalLineEditPart.VISUAL_ID:
			return getBidirectionalLine_2021OutgoingLinks(view);
		case TesselationEditPart.VISUAL_ID:
			return getTesselation_2022OutgoingLinks(view);
		case UnidirectionalLineEditPart.VISUAL_ID:
			return getUnidirectionalLine_2023OutgoingLinks(view);
		case ConventionalEditPart.VISUAL_ID:
			return getConventional_2024OutgoingLinks(view);
		case AttributeEditPart.VISUAL_ID:
			return getAttribute_3001OutgoingLinks(view);
		case MethodEditPart.VISUAL_ID:
			return getMethod_3012OutgoingLinks(view);
		case Attribute2EditPart.VISUAL_ID:
			return getAttribute_3002OutgoingLinks(view);
		case Method2EditPart.VISUAL_ID:
			return getMethod_3013OutgoingLinks(view);
		case Attribute3EditPart.VISUAL_ID:
			return getAttribute_3003OutgoingLinks(view);
		case Method3EditPart.VISUAL_ID:
			return getMethod_3014OutgoingLinks(view);
		case Attribute4EditPart.VISUAL_ID:
			return getAttribute_3004OutgoingLinks(view);
		case Method4EditPart.VISUAL_ID:
			return getMethod_3015OutgoingLinks(view);
		case Attribute5EditPart.VISUAL_ID:
			return getAttribute_3005OutgoingLinks(view);
		case Method5EditPart.VISUAL_ID:
			return getMethod_3016OutgoingLinks(view);
		case Attribute6EditPart.VISUAL_ID:
			return getAttribute_3006OutgoingLinks(view);
		case Method6EditPart.VISUAL_ID:
			return getMethod_3017OutgoingLinks(view);
		case Attribute7EditPart.VISUAL_ID:
			return getAttribute_3007OutgoingLinks(view);
		case Method7EditPart.VISUAL_ID:
			return getMethod_3018OutgoingLinks(view);
		case Attribute8EditPart.VISUAL_ID:
			return getAttribute_3008OutgoingLinks(view);
		case Method8EditPart.VISUAL_ID:
			return getMethod_3019OutgoingLinks(view);
		case Attribute9EditPart.VISUAL_ID:
			return getAttribute_3009OutgoingLinks(view);
		case Method9EditPart.VISUAL_ID:
			return getMethod_3020OutgoingLinks(view);
		case Attribute10EditPart.VISUAL_ID:
			return getAttribute_3010OutgoingLinks(view);
		case Method10EditPart.VISUAL_ID:
			return getMethod_3021OutgoingLinks(view);
		case Attribute11EditPart.VISUAL_ID:
			return getAttribute_3011OutgoingLinks(view);
		case Method11EditPart.VISUAL_ID:
			return getMethod_3023OutgoingLinks(view);
		case Attribute12EditPart.VISUAL_ID:
			return getAttribute_3022OutgoingLinks(view);
		case Method12EditPart.VISUAL_ID:
			return getMethod_3024OutgoingLinks(view);
		case SpatialAgregationEditPart.VISUAL_ID:
			return getSpatialAgregation_4001OutgoingLinks(view);
		case OverlappingTotalEditPart.VISUAL_ID:
			return getOverlappingTotal_4002OutgoingLinks(view);
		case DisjointPartialEditPart.VISUAL_ID:
			return getDisjointPartial_4003OutgoingLinks(view);
		case SimpleEditPart.VISUAL_ID:
			return getSimple_4004OutgoingLinks(view);
		case ScaleEditPart.VISUAL_ID:
			return getScale_4005OutgoingLinks(view);
		case ShapeEditPart.VISUAL_ID:
			return getShape_4006OutgoingLinks(view);
		case AgregationEditPart.VISUAL_ID:
			return getAgregation_4007OutgoingLinks(view);
		case SpatialEditPart.VISUAL_ID:
			return getSpatial_4008OutgoingLinks(view);
		case NetworkAssociationEditPart.VISUAL_ID:
			return getNetworkAssociation_4009OutgoingLinks(view);
		case DisjointTotalEditPart.VISUAL_ID:
			return getDisjointTotal_4010OutgoingLinks(view);
		case OverlappingPartialEditPart.VISUAL_ID:
			return getOverlappingPartial_4011OutgoingLinks(view);
		}
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getSchema_1000ContainedLinks(
			View view) {
		Schema modelElement = (Schema) view.getElement();
		LinkedList<OmtgLinkDescriptor> result = new LinkedList<OmtgLinkDescriptor>();
		result.addAll(getContainedTypeModelFacetLinks_SpatialAgregation_4001(modelElement));
		result.addAll(getContainedTypeModelFacetLinks_OverlappingTotal_4002(modelElement));
		result.addAll(getContainedTypeModelFacetLinks_DisjointPartial_4003(modelElement));
		result.addAll(getContainedTypeModelFacetLinks_Simple_4004(modelElement));
		result.addAll(getContainedTypeModelFacetLinks_Scale_4005(modelElement));
		result.addAll(getContainedTypeModelFacetLinks_Shape_4006(modelElement));
		result.addAll(getContainedTypeModelFacetLinks_Agregation_4007(modelElement));
		result.addAll(getContainedTypeModelFacetLinks_Spatial_4008(modelElement));
		result.addAll(getContainedTypeModelFacetLinks_NetworkAssociation_4009(modelElement));
		result.addAll(getContainedTypeModelFacetLinks_DisjointTotal_4010(modelElement));
		result.addAll(getContainedTypeModelFacetLinks_OverlappingPartial_4011(modelElement));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getPolygon_2013ContainedLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getPoint_2014ContainedLinks(View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getLine_2015ContainedLinks(View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getNetworkClass_2016ContainedLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getSampling_2025ContainedLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getIsoline_2018ContainedLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getNode_2019ContainedLinks(View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getAdjacentPolygons_2020ContainedLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getBidirectionalLine_2021ContainedLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getTesselation_2022ContainedLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getUnidirectionalLine_2023ContainedLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getConventional_2024ContainedLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getAttribute_3001ContainedLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getMethod_3012ContainedLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getAttribute_3002ContainedLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getMethod_3013ContainedLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getAttribute_3003ContainedLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getMethod_3014ContainedLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getAttribute_3004ContainedLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getMethod_3015ContainedLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getAttribute_3005ContainedLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getMethod_3016ContainedLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getAttribute_3006ContainedLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getMethod_3017ContainedLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getAttribute_3007ContainedLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getMethod_3018ContainedLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getAttribute_3008ContainedLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getMethod_3019ContainedLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getAttribute_3009ContainedLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getMethod_3020ContainedLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getAttribute_3010ContainedLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getMethod_3021ContainedLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getAttribute_3011ContainedLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getMethod_3023ContainedLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getAttribute_3022ContainedLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getMethod_3024ContainedLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getSpatialAgregation_4001ContainedLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getOverlappingTotal_4002ContainedLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getDisjointPartial_4003ContainedLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getSimple_4004ContainedLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getScale_4005ContainedLinks(View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getShape_4006ContainedLinks(View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getAgregation_4007ContainedLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getSpatial_4008ContainedLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getNetworkAssociation_4009ContainedLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getDisjointTotal_4010ContainedLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getOverlappingPartial_4011ContainedLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getPolygon_2013IncomingLinks(
			View view) {
		Polygon modelElement = (Polygon) view.getElement();
		Map<EObject, Collection<EStructuralFeature.Setting>> crossReferences = EcoreUtil.CrossReferencer
				.find(view.eResource().getResourceSet().getResources());
		LinkedList<OmtgLinkDescriptor> result = new LinkedList<OmtgLinkDescriptor>();
		result.addAll(getIncomingTypeModelFacetLinks_SpatialAgregation_4001(
				modelElement, crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_OverlappingTotal_4002(
				modelElement, crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_DisjointPartial_4003(
				modelElement, crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_Simple_4004(modelElement,
				crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_Scale_4005(modelElement,
				crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_Shape_4006(modelElement,
				crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_Agregation_4007(
				modelElement, crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_Spatial_4008(modelElement,
				crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_NetworkAssociation_4009(
				modelElement, crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_DisjointTotal_4010(
				modelElement, crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_OverlappingPartial_4011(
				modelElement, crossReferences));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getPoint_2014IncomingLinks(View view) {
		Point modelElement = (Point) view.getElement();
		Map<EObject, Collection<EStructuralFeature.Setting>> crossReferences = EcoreUtil.CrossReferencer
				.find(view.eResource().getResourceSet().getResources());
		LinkedList<OmtgLinkDescriptor> result = new LinkedList<OmtgLinkDescriptor>();
		result.addAll(getIncomingTypeModelFacetLinks_SpatialAgregation_4001(
				modelElement, crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_OverlappingTotal_4002(
				modelElement, crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_DisjointPartial_4003(
				modelElement, crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_Simple_4004(modelElement,
				crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_Scale_4005(modelElement,
				crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_Shape_4006(modelElement,
				crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_Agregation_4007(
				modelElement, crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_Spatial_4008(modelElement,
				crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_NetworkAssociation_4009(
				modelElement, crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_DisjointTotal_4010(
				modelElement, crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_OverlappingPartial_4011(
				modelElement, crossReferences));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getLine_2015IncomingLinks(View view) {
		Line modelElement = (Line) view.getElement();
		Map<EObject, Collection<EStructuralFeature.Setting>> crossReferences = EcoreUtil.CrossReferencer
				.find(view.eResource().getResourceSet().getResources());
		LinkedList<OmtgLinkDescriptor> result = new LinkedList<OmtgLinkDescriptor>();
		result.addAll(getIncomingTypeModelFacetLinks_SpatialAgregation_4001(
				modelElement, crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_OverlappingTotal_4002(
				modelElement, crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_DisjointPartial_4003(
				modelElement, crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_Simple_4004(modelElement,
				crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_Scale_4005(modelElement,
				crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_Shape_4006(modelElement,
				crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_Agregation_4007(
				modelElement, crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_Spatial_4008(modelElement,
				crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_NetworkAssociation_4009(
				modelElement, crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_DisjointTotal_4010(
				modelElement, crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_OverlappingPartial_4011(
				modelElement, crossReferences));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getNetworkClass_2016IncomingLinks(
			View view) {
		NetworkClass modelElement = (NetworkClass) view.getElement();
		Map<EObject, Collection<EStructuralFeature.Setting>> crossReferences = EcoreUtil.CrossReferencer
				.find(view.eResource().getResourceSet().getResources());
		LinkedList<OmtgLinkDescriptor> result = new LinkedList<OmtgLinkDescriptor>();
		result.addAll(getIncomingTypeModelFacetLinks_SpatialAgregation_4001(
				modelElement, crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_OverlappingTotal_4002(
				modelElement, crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_DisjointPartial_4003(
				modelElement, crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_Simple_4004(modelElement,
				crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_Scale_4005(modelElement,
				crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_Shape_4006(modelElement,
				crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_Agregation_4007(
				modelElement, crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_Spatial_4008(modelElement,
				crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_NetworkAssociation_4009(
				modelElement, crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_DisjointTotal_4010(
				modelElement, crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_OverlappingPartial_4011(
				modelElement, crossReferences));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getSampling_2025IncomingLinks(
			View view) {
		Sampling modelElement = (Sampling) view.getElement();
		Map<EObject, Collection<EStructuralFeature.Setting>> crossReferences = EcoreUtil.CrossReferencer
				.find(view.eResource().getResourceSet().getResources());
		LinkedList<OmtgLinkDescriptor> result = new LinkedList<OmtgLinkDescriptor>();
		result.addAll(getIncomingTypeModelFacetLinks_SpatialAgregation_4001(
				modelElement, crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_OverlappingTotal_4002(
				modelElement, crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_DisjointPartial_4003(
				modelElement, crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_Simple_4004(modelElement,
				crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_Scale_4005(modelElement,
				crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_Shape_4006(modelElement,
				crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_Agregation_4007(
				modelElement, crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_Spatial_4008(modelElement,
				crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_NetworkAssociation_4009(
				modelElement, crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_DisjointTotal_4010(
				modelElement, crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_OverlappingPartial_4011(
				modelElement, crossReferences));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getIsoline_2018IncomingLinks(
			View view) {
		Isoline modelElement = (Isoline) view.getElement();
		Map<EObject, Collection<EStructuralFeature.Setting>> crossReferences = EcoreUtil.CrossReferencer
				.find(view.eResource().getResourceSet().getResources());
		LinkedList<OmtgLinkDescriptor> result = new LinkedList<OmtgLinkDescriptor>();
		result.addAll(getIncomingTypeModelFacetLinks_SpatialAgregation_4001(
				modelElement, crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_OverlappingTotal_4002(
				modelElement, crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_DisjointPartial_4003(
				modelElement, crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_Simple_4004(modelElement,
				crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_Scale_4005(modelElement,
				crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_Shape_4006(modelElement,
				crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_Agregation_4007(
				modelElement, crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_Spatial_4008(modelElement,
				crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_NetworkAssociation_4009(
				modelElement, crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_DisjointTotal_4010(
				modelElement, crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_OverlappingPartial_4011(
				modelElement, crossReferences));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getNode_2019IncomingLinks(View view) {
		Node modelElement = (Node) view.getElement();
		Map<EObject, Collection<EStructuralFeature.Setting>> crossReferences = EcoreUtil.CrossReferencer
				.find(view.eResource().getResourceSet().getResources());
		LinkedList<OmtgLinkDescriptor> result = new LinkedList<OmtgLinkDescriptor>();
		result.addAll(getIncomingTypeModelFacetLinks_SpatialAgregation_4001(
				modelElement, crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_OverlappingTotal_4002(
				modelElement, crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_DisjointPartial_4003(
				modelElement, crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_Simple_4004(modelElement,
				crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_Scale_4005(modelElement,
				crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_Shape_4006(modelElement,
				crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_Agregation_4007(
				modelElement, crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_Spatial_4008(modelElement,
				crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_NetworkAssociation_4009(
				modelElement, crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_DisjointTotal_4010(
				modelElement, crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_OverlappingPartial_4011(
				modelElement, crossReferences));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getAdjacentPolygons_2020IncomingLinks(
			View view) {
		AdjacentPolygons modelElement = (AdjacentPolygons) view.getElement();
		Map<EObject, Collection<EStructuralFeature.Setting>> crossReferences = EcoreUtil.CrossReferencer
				.find(view.eResource().getResourceSet().getResources());
		LinkedList<OmtgLinkDescriptor> result = new LinkedList<OmtgLinkDescriptor>();
		result.addAll(getIncomingTypeModelFacetLinks_SpatialAgregation_4001(
				modelElement, crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_OverlappingTotal_4002(
				modelElement, crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_DisjointPartial_4003(
				modelElement, crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_Simple_4004(modelElement,
				crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_Scale_4005(modelElement,
				crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_Shape_4006(modelElement,
				crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_Agregation_4007(
				modelElement, crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_Spatial_4008(modelElement,
				crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_NetworkAssociation_4009(
				modelElement, crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_DisjointTotal_4010(
				modelElement, crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_OverlappingPartial_4011(
				modelElement, crossReferences));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getBidirectionalLine_2021IncomingLinks(
			View view) {
		BidirectionalLine modelElement = (BidirectionalLine) view.getElement();
		Map<EObject, Collection<EStructuralFeature.Setting>> crossReferences = EcoreUtil.CrossReferencer
				.find(view.eResource().getResourceSet().getResources());
		LinkedList<OmtgLinkDescriptor> result = new LinkedList<OmtgLinkDescriptor>();
		result.addAll(getIncomingTypeModelFacetLinks_SpatialAgregation_4001(
				modelElement, crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_OverlappingTotal_4002(
				modelElement, crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_DisjointPartial_4003(
				modelElement, crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_Simple_4004(modelElement,
				crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_Scale_4005(modelElement,
				crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_Shape_4006(modelElement,
				crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_Agregation_4007(
				modelElement, crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_Spatial_4008(modelElement,
				crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_NetworkAssociation_4009(
				modelElement, crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_DisjointTotal_4010(
				modelElement, crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_OverlappingPartial_4011(
				modelElement, crossReferences));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getTesselation_2022IncomingLinks(
			View view) {
		Tesselation modelElement = (Tesselation) view.getElement();
		Map<EObject, Collection<EStructuralFeature.Setting>> crossReferences = EcoreUtil.CrossReferencer
				.find(view.eResource().getResourceSet().getResources());
		LinkedList<OmtgLinkDescriptor> result = new LinkedList<OmtgLinkDescriptor>();
		result.addAll(getIncomingTypeModelFacetLinks_SpatialAgregation_4001(
				modelElement, crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_OverlappingTotal_4002(
				modelElement, crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_DisjointPartial_4003(
				modelElement, crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_Simple_4004(modelElement,
				crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_Scale_4005(modelElement,
				crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_Shape_4006(modelElement,
				crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_Agregation_4007(
				modelElement, crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_Spatial_4008(modelElement,
				crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_NetworkAssociation_4009(
				modelElement, crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_DisjointTotal_4010(
				modelElement, crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_OverlappingPartial_4011(
				modelElement, crossReferences));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getUnidirectionalLine_2023IncomingLinks(
			View view) {
		UnidirectionalLine modelElement = (UnidirectionalLine) view
				.getElement();
		Map<EObject, Collection<EStructuralFeature.Setting>> crossReferences = EcoreUtil.CrossReferencer
				.find(view.eResource().getResourceSet().getResources());
		LinkedList<OmtgLinkDescriptor> result = new LinkedList<OmtgLinkDescriptor>();
		result.addAll(getIncomingTypeModelFacetLinks_SpatialAgregation_4001(
				modelElement, crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_OverlappingTotal_4002(
				modelElement, crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_DisjointPartial_4003(
				modelElement, crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_Simple_4004(modelElement,
				crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_Scale_4005(modelElement,
				crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_Shape_4006(modelElement,
				crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_Agregation_4007(
				modelElement, crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_Spatial_4008(modelElement,
				crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_NetworkAssociation_4009(
				modelElement, crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_DisjointTotal_4010(
				modelElement, crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_OverlappingPartial_4011(
				modelElement, crossReferences));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getConventional_2024IncomingLinks(
			View view) {
		Conventional modelElement = (Conventional) view.getElement();
		Map<EObject, Collection<EStructuralFeature.Setting>> crossReferences = EcoreUtil.CrossReferencer
				.find(view.eResource().getResourceSet().getResources());
		LinkedList<OmtgLinkDescriptor> result = new LinkedList<OmtgLinkDescriptor>();
		result.addAll(getIncomingTypeModelFacetLinks_SpatialAgregation_4001(
				modelElement, crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_OverlappingTotal_4002(
				modelElement, crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_DisjointPartial_4003(
				modelElement, crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_Simple_4004(modelElement,
				crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_Scale_4005(modelElement,
				crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_Shape_4006(modelElement,
				crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_Agregation_4007(
				modelElement, crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_Spatial_4008(modelElement,
				crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_NetworkAssociation_4009(
				modelElement, crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_DisjointTotal_4010(
				modelElement, crossReferences));
		result.addAll(getIncomingTypeModelFacetLinks_OverlappingPartial_4011(
				modelElement, crossReferences));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getAttribute_3001IncomingLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getMethod_3012IncomingLinks(View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getAttribute_3002IncomingLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getMethod_3013IncomingLinks(View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getAttribute_3003IncomingLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getMethod_3014IncomingLinks(View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getAttribute_3004IncomingLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getMethod_3015IncomingLinks(View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getAttribute_3005IncomingLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getMethod_3016IncomingLinks(View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getAttribute_3006IncomingLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getMethod_3017IncomingLinks(View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getAttribute_3007IncomingLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getMethod_3018IncomingLinks(View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getAttribute_3008IncomingLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getMethod_3019IncomingLinks(View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getAttribute_3009IncomingLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getMethod_3020IncomingLinks(View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getAttribute_3010IncomingLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getMethod_3021IncomingLinks(View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getAttribute_3011IncomingLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getMethod_3023IncomingLinks(View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getAttribute_3022IncomingLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getMethod_3024IncomingLinks(View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getSpatialAgregation_4001IncomingLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getOverlappingTotal_4002IncomingLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getDisjointPartial_4003IncomingLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getSimple_4004IncomingLinks(View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getScale_4005IncomingLinks(View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getShape_4006IncomingLinks(View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getAgregation_4007IncomingLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getSpatial_4008IncomingLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getNetworkAssociation_4009IncomingLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getDisjointTotal_4010IncomingLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getOverlappingPartial_4011IncomingLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getPolygon_2013OutgoingLinks(
			View view) {
		Polygon modelElement = (Polygon) view.getElement();
		LinkedList<OmtgLinkDescriptor> result = new LinkedList<OmtgLinkDescriptor>();
		result.addAll(getOutgoingTypeModelFacetLinks_SpatialAgregation_4001(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_OverlappingTotal_4002(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_DisjointPartial_4003(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_Simple_4004(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_Scale_4005(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_Shape_4006(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_Agregation_4007(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_Spatial_4008(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_NetworkAssociation_4009(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_DisjointTotal_4010(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_OverlappingPartial_4011(modelElement));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getPoint_2014OutgoingLinks(View view) {
		Point modelElement = (Point) view.getElement();
		LinkedList<OmtgLinkDescriptor> result = new LinkedList<OmtgLinkDescriptor>();
		result.addAll(getOutgoingTypeModelFacetLinks_SpatialAgregation_4001(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_OverlappingTotal_4002(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_DisjointPartial_4003(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_Simple_4004(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_Scale_4005(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_Shape_4006(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_Agregation_4007(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_Spatial_4008(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_NetworkAssociation_4009(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_DisjointTotal_4010(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_OverlappingPartial_4011(modelElement));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getLine_2015OutgoingLinks(View view) {
		Line modelElement = (Line) view.getElement();
		LinkedList<OmtgLinkDescriptor> result = new LinkedList<OmtgLinkDescriptor>();
		result.addAll(getOutgoingTypeModelFacetLinks_SpatialAgregation_4001(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_OverlappingTotal_4002(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_DisjointPartial_4003(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_Simple_4004(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_Scale_4005(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_Shape_4006(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_Agregation_4007(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_Spatial_4008(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_NetworkAssociation_4009(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_DisjointTotal_4010(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_OverlappingPartial_4011(modelElement));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getNetworkClass_2016OutgoingLinks(
			View view) {
		NetworkClass modelElement = (NetworkClass) view.getElement();
		LinkedList<OmtgLinkDescriptor> result = new LinkedList<OmtgLinkDescriptor>();
		result.addAll(getOutgoingTypeModelFacetLinks_SpatialAgregation_4001(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_OverlappingTotal_4002(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_DisjointPartial_4003(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_Simple_4004(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_Scale_4005(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_Shape_4006(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_Agregation_4007(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_Spatial_4008(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_NetworkAssociation_4009(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_DisjointTotal_4010(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_OverlappingPartial_4011(modelElement));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getSampling_2025OutgoingLinks(
			View view) {
		Sampling modelElement = (Sampling) view.getElement();
		LinkedList<OmtgLinkDescriptor> result = new LinkedList<OmtgLinkDescriptor>();
		result.addAll(getOutgoingTypeModelFacetLinks_SpatialAgregation_4001(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_OverlappingTotal_4002(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_DisjointPartial_4003(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_Simple_4004(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_Scale_4005(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_Shape_4006(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_Agregation_4007(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_Spatial_4008(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_NetworkAssociation_4009(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_DisjointTotal_4010(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_OverlappingPartial_4011(modelElement));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getIsoline_2018OutgoingLinks(
			View view) {
		Isoline modelElement = (Isoline) view.getElement();
		LinkedList<OmtgLinkDescriptor> result = new LinkedList<OmtgLinkDescriptor>();
		result.addAll(getOutgoingTypeModelFacetLinks_SpatialAgregation_4001(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_OverlappingTotal_4002(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_DisjointPartial_4003(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_Simple_4004(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_Scale_4005(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_Shape_4006(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_Agregation_4007(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_Spatial_4008(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_NetworkAssociation_4009(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_DisjointTotal_4010(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_OverlappingPartial_4011(modelElement));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getNode_2019OutgoingLinks(View view) {
		Node modelElement = (Node) view.getElement();
		LinkedList<OmtgLinkDescriptor> result = new LinkedList<OmtgLinkDescriptor>();
		result.addAll(getOutgoingTypeModelFacetLinks_SpatialAgregation_4001(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_OverlappingTotal_4002(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_DisjointPartial_4003(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_Simple_4004(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_Scale_4005(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_Shape_4006(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_Agregation_4007(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_Spatial_4008(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_NetworkAssociation_4009(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_DisjointTotal_4010(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_OverlappingPartial_4011(modelElement));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getAdjacentPolygons_2020OutgoingLinks(
			View view) {
		AdjacentPolygons modelElement = (AdjacentPolygons) view.getElement();
		LinkedList<OmtgLinkDescriptor> result = new LinkedList<OmtgLinkDescriptor>();
		result.addAll(getOutgoingTypeModelFacetLinks_SpatialAgregation_4001(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_OverlappingTotal_4002(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_DisjointPartial_4003(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_Simple_4004(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_Scale_4005(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_Shape_4006(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_Agregation_4007(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_Spatial_4008(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_NetworkAssociation_4009(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_DisjointTotal_4010(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_OverlappingPartial_4011(modelElement));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getBidirectionalLine_2021OutgoingLinks(
			View view) {
		BidirectionalLine modelElement = (BidirectionalLine) view.getElement();
		LinkedList<OmtgLinkDescriptor> result = new LinkedList<OmtgLinkDescriptor>();
		result.addAll(getOutgoingTypeModelFacetLinks_SpatialAgregation_4001(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_OverlappingTotal_4002(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_DisjointPartial_4003(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_Simple_4004(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_Scale_4005(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_Shape_4006(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_Agregation_4007(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_Spatial_4008(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_NetworkAssociation_4009(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_DisjointTotal_4010(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_OverlappingPartial_4011(modelElement));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getTesselation_2022OutgoingLinks(
			View view) {
		Tesselation modelElement = (Tesselation) view.getElement();
		LinkedList<OmtgLinkDescriptor> result = new LinkedList<OmtgLinkDescriptor>();
		result.addAll(getOutgoingTypeModelFacetLinks_SpatialAgregation_4001(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_OverlappingTotal_4002(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_DisjointPartial_4003(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_Simple_4004(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_Scale_4005(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_Shape_4006(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_Agregation_4007(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_Spatial_4008(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_NetworkAssociation_4009(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_DisjointTotal_4010(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_OverlappingPartial_4011(modelElement));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getUnidirectionalLine_2023OutgoingLinks(
			View view) {
		UnidirectionalLine modelElement = (UnidirectionalLine) view
				.getElement();
		LinkedList<OmtgLinkDescriptor> result = new LinkedList<OmtgLinkDescriptor>();
		result.addAll(getOutgoingTypeModelFacetLinks_SpatialAgregation_4001(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_OverlappingTotal_4002(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_DisjointPartial_4003(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_Simple_4004(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_Scale_4005(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_Shape_4006(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_Agregation_4007(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_Spatial_4008(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_NetworkAssociation_4009(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_DisjointTotal_4010(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_OverlappingPartial_4011(modelElement));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getConventional_2024OutgoingLinks(
			View view) {
		Conventional modelElement = (Conventional) view.getElement();
		LinkedList<OmtgLinkDescriptor> result = new LinkedList<OmtgLinkDescriptor>();
		result.addAll(getOutgoingTypeModelFacetLinks_SpatialAgregation_4001(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_OverlappingTotal_4002(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_DisjointPartial_4003(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_Simple_4004(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_Scale_4005(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_Shape_4006(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_Agregation_4007(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_Spatial_4008(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_NetworkAssociation_4009(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_DisjointTotal_4010(modelElement));
		result.addAll(getOutgoingTypeModelFacetLinks_OverlappingPartial_4011(modelElement));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getAttribute_3001OutgoingLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getMethod_3012OutgoingLinks(View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getAttribute_3002OutgoingLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getMethod_3013OutgoingLinks(View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getAttribute_3003OutgoingLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getMethod_3014OutgoingLinks(View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getAttribute_3004OutgoingLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getMethod_3015OutgoingLinks(View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getAttribute_3005OutgoingLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getMethod_3016OutgoingLinks(View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getAttribute_3006OutgoingLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getMethod_3017OutgoingLinks(View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getAttribute_3007OutgoingLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getMethod_3018OutgoingLinks(View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getAttribute_3008OutgoingLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getMethod_3019OutgoingLinks(View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getAttribute_3009OutgoingLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getMethod_3020OutgoingLinks(View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getAttribute_3010OutgoingLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getMethod_3021OutgoingLinks(View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getAttribute_3011OutgoingLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getMethod_3023OutgoingLinks(View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getAttribute_3022OutgoingLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getMethod_3024OutgoingLinks(View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getSpatialAgregation_4001OutgoingLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getOverlappingTotal_4002OutgoingLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getDisjointPartial_4003OutgoingLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getSimple_4004OutgoingLinks(View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getScale_4005OutgoingLinks(View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getShape_4006OutgoingLinks(View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getAgregation_4007OutgoingLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getSpatial_4008OutgoingLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getNetworkAssociation_4009OutgoingLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getDisjointTotal_4010OutgoingLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<OmtgLinkDescriptor> getOverlappingPartial_4011OutgoingLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	private static Collection<OmtgLinkDescriptor> getContainedTypeModelFacetLinks_SpatialAgregation_4001(
			Schema container) {
		LinkedList<OmtgLinkDescriptor> result = new LinkedList<OmtgLinkDescriptor>();
		for (Iterator<?> links = container.getRelationship().iterator(); links
				.hasNext();) {
			EObject linkObject = (EObject) links.next();
			if (false == linkObject instanceof SpatialAgregation) {
				continue;
			}
			SpatialAgregation link = (SpatialAgregation) linkObject;
			if (SpatialAgregationEditPart.VISUAL_ID != OmtgVisualIDRegistry
					.getLinkWithClassVisualID(link)) {
				continue;
			}
			omtg.element dst = link.getTarget();
			omtg.element src = link.getSource();
			result.add(new OmtgLinkDescriptor(src, dst, link,
					OmtgElementTypes.SpatialAgregation_4001,
					SpatialAgregationEditPart.VISUAL_ID));
		}
		return result;
	}

	/**
	 * @generated
	 */
	private static Collection<OmtgLinkDescriptor> getContainedTypeModelFacetLinks_OverlappingTotal_4002(
			Schema container) {
		LinkedList<OmtgLinkDescriptor> result = new LinkedList<OmtgLinkDescriptor>();
		for (Iterator<?> links = container.getRelationship().iterator(); links
				.hasNext();) {
			EObject linkObject = (EObject) links.next();
			if (false == linkObject instanceof OverlappingTotal) {
				continue;
			}
			OverlappingTotal link = (OverlappingTotal) linkObject;
			if (OverlappingTotalEditPart.VISUAL_ID != OmtgVisualIDRegistry
					.getLinkWithClassVisualID(link)) {
				continue;
			}
			omtg.element dst = link.getTarget();
			omtg.element src = link.getSource();
			result.add(new OmtgLinkDescriptor(src, dst, link,
					OmtgElementTypes.OverlappingTotal_4002,
					OverlappingTotalEditPart.VISUAL_ID));
		}
		return result;
	}

	/**
	 * @generated
	 */
	private static Collection<OmtgLinkDescriptor> getContainedTypeModelFacetLinks_DisjointPartial_4003(
			Schema container) {
		LinkedList<OmtgLinkDescriptor> result = new LinkedList<OmtgLinkDescriptor>();
		for (Iterator<?> links = container.getRelationship().iterator(); links
				.hasNext();) {
			EObject linkObject = (EObject) links.next();
			if (false == linkObject instanceof DisjointPartial) {
				continue;
			}
			DisjointPartial link = (DisjointPartial) linkObject;
			if (DisjointPartialEditPart.VISUAL_ID != OmtgVisualIDRegistry
					.getLinkWithClassVisualID(link)) {
				continue;
			}
			omtg.element dst = link.getTarget();
			omtg.element src = link.getSource();
			result.add(new OmtgLinkDescriptor(src, dst, link,
					OmtgElementTypes.DisjointPartial_4003,
					DisjointPartialEditPart.VISUAL_ID));
		}
		return result;
	}

	/**
	 * @generated
	 */
	private static Collection<OmtgLinkDescriptor> getContainedTypeModelFacetLinks_Simple_4004(
			Schema container) {
		LinkedList<OmtgLinkDescriptor> result = new LinkedList<OmtgLinkDescriptor>();
		for (Iterator<?> links = container.getRelationship().iterator(); links
				.hasNext();) {
			EObject linkObject = (EObject) links.next();
			if (false == linkObject instanceof Simple) {
				continue;
			}
			Simple link = (Simple) linkObject;
			if (SimpleEditPart.VISUAL_ID != OmtgVisualIDRegistry
					.getLinkWithClassVisualID(link)) {
				continue;
			}
			omtg.element dst = link.getTarget();
			omtg.element src = link.getSource();
			result.add(new OmtgLinkDescriptor(src, dst, link,
					OmtgElementTypes.Simple_4004, SimpleEditPart.VISUAL_ID));
		}
		return result;
	}

	/**
	 * @generated
	 */
	private static Collection<OmtgLinkDescriptor> getContainedTypeModelFacetLinks_Scale_4005(
			Schema container) {
		LinkedList<OmtgLinkDescriptor> result = new LinkedList<OmtgLinkDescriptor>();
		for (Iterator<?> links = container.getRelationship().iterator(); links
				.hasNext();) {
			EObject linkObject = (EObject) links.next();
			if (false == linkObject instanceof Scale) {
				continue;
			}
			Scale link = (Scale) linkObject;
			if (ScaleEditPart.VISUAL_ID != OmtgVisualIDRegistry
					.getLinkWithClassVisualID(link)) {
				continue;
			}
			omtg.element dst = link.getTarget();
			omtg.element src = link.getSource();
			result.add(new OmtgLinkDescriptor(src, dst, link,
					OmtgElementTypes.Scale_4005, ScaleEditPart.VISUAL_ID));
		}
		return result;
	}

	/**
	 * @generated
	 */
	private static Collection<OmtgLinkDescriptor> getContainedTypeModelFacetLinks_Shape_4006(
			Schema container) {
		LinkedList<OmtgLinkDescriptor> result = new LinkedList<OmtgLinkDescriptor>();
		for (Iterator<?> links = container.getRelationship().iterator(); links
				.hasNext();) {
			EObject linkObject = (EObject) links.next();
			if (false == linkObject instanceof Shape) {
				continue;
			}
			Shape link = (Shape) linkObject;
			if (ShapeEditPart.VISUAL_ID != OmtgVisualIDRegistry
					.getLinkWithClassVisualID(link)) {
				continue;
			}
			omtg.element dst = link.getTarget();
			omtg.element src = link.getSource();
			result.add(new OmtgLinkDescriptor(src, dst, link,
					OmtgElementTypes.Shape_4006, ShapeEditPart.VISUAL_ID));
		}
		return result;
	}

	/**
	 * @generated
	 */
	private static Collection<OmtgLinkDescriptor> getContainedTypeModelFacetLinks_Agregation_4007(
			Schema container) {
		LinkedList<OmtgLinkDescriptor> result = new LinkedList<OmtgLinkDescriptor>();
		for (Iterator<?> links = container.getRelationship().iterator(); links
				.hasNext();) {
			EObject linkObject = (EObject) links.next();
			if (false == linkObject instanceof Agregation) {
				continue;
			}
			Agregation link = (Agregation) linkObject;
			if (AgregationEditPart.VISUAL_ID != OmtgVisualIDRegistry
					.getLinkWithClassVisualID(link)) {
				continue;
			}
			omtg.element dst = link.getTarget();
			omtg.element src = link.getSource();
			result.add(new OmtgLinkDescriptor(src, dst, link,
					OmtgElementTypes.Agregation_4007,
					AgregationEditPart.VISUAL_ID));
		}
		return result;
	}

	/**
	 * @generated
	 */
	private static Collection<OmtgLinkDescriptor> getContainedTypeModelFacetLinks_Spatial_4008(
			Schema container) {
		LinkedList<OmtgLinkDescriptor> result = new LinkedList<OmtgLinkDescriptor>();
		for (Iterator<?> links = container.getRelationship().iterator(); links
				.hasNext();) {
			EObject linkObject = (EObject) links.next();
			if (false == linkObject instanceof Spatial) {
				continue;
			}
			Spatial link = (Spatial) linkObject;
			if (SpatialEditPart.VISUAL_ID != OmtgVisualIDRegistry
					.getLinkWithClassVisualID(link)) {
				continue;
			}
			omtg.element dst = link.getTarget();
			omtg.element src = link.getSource();
			result.add(new OmtgLinkDescriptor(src, dst, link,
					OmtgElementTypes.Spatial_4008, SpatialEditPart.VISUAL_ID));
		}
		return result;
	}

	/**
	 * @generated
	 */
	private static Collection<OmtgLinkDescriptor> getContainedTypeModelFacetLinks_NetworkAssociation_4009(
			Schema container) {
		LinkedList<OmtgLinkDescriptor> result = new LinkedList<OmtgLinkDescriptor>();
		for (Iterator<?> links = container.getRelationship().iterator(); links
				.hasNext();) {
			EObject linkObject = (EObject) links.next();
			if (false == linkObject instanceof NetworkAssociation) {
				continue;
			}
			NetworkAssociation link = (NetworkAssociation) linkObject;
			if (NetworkAssociationEditPart.VISUAL_ID != OmtgVisualIDRegistry
					.getLinkWithClassVisualID(link)) {
				continue;
			}
			omtg.element dst = link.getTarget();
			omtg.element src = link.getSource();
			result.add(new OmtgLinkDescriptor(src, dst, link,
					OmtgElementTypes.NetworkAssociation_4009,
					NetworkAssociationEditPart.VISUAL_ID));
		}
		return result;
	}

	/**
	 * @generated
	 */
	private static Collection<OmtgLinkDescriptor> getContainedTypeModelFacetLinks_DisjointTotal_4010(
			Schema container) {
		LinkedList<OmtgLinkDescriptor> result = new LinkedList<OmtgLinkDescriptor>();
		for (Iterator<?> links = container.getRelationship().iterator(); links
				.hasNext();) {
			EObject linkObject = (EObject) links.next();
			if (false == linkObject instanceof DisjointTotal) {
				continue;
			}
			DisjointTotal link = (DisjointTotal) linkObject;
			if (DisjointTotalEditPart.VISUAL_ID != OmtgVisualIDRegistry
					.getLinkWithClassVisualID(link)) {
				continue;
			}
			omtg.element dst = link.getTarget();
			omtg.element src = link.getSource();
			result.add(new OmtgLinkDescriptor(src, dst, link,
					OmtgElementTypes.DisjointTotal_4010,
					DisjointTotalEditPart.VISUAL_ID));
		}
		return result;
	}

	/**
	 * @generated
	 */
	private static Collection<OmtgLinkDescriptor> getContainedTypeModelFacetLinks_OverlappingPartial_4011(
			Schema container) {
		LinkedList<OmtgLinkDescriptor> result = new LinkedList<OmtgLinkDescriptor>();
		for (Iterator<?> links = container.getRelationship().iterator(); links
				.hasNext();) {
			EObject linkObject = (EObject) links.next();
			if (false == linkObject instanceof OverlappingPartial) {
				continue;
			}
			OverlappingPartial link = (OverlappingPartial) linkObject;
			if (OverlappingPartialEditPart.VISUAL_ID != OmtgVisualIDRegistry
					.getLinkWithClassVisualID(link)) {
				continue;
			}
			omtg.element dst = link.getTarget();
			omtg.element src = link.getSource();
			result.add(new OmtgLinkDescriptor(src, dst, link,
					OmtgElementTypes.OverlappingPartial_4011,
					OverlappingPartialEditPart.VISUAL_ID));
		}
		return result;
	}

	/**
	 * @generated
	 */
	private static Collection<OmtgLinkDescriptor> getIncomingTypeModelFacetLinks_SpatialAgregation_4001(
			omtg.element target,
			Map<EObject, Collection<EStructuralFeature.Setting>> crossReferences) {
		LinkedList<OmtgLinkDescriptor> result = new LinkedList<OmtgLinkDescriptor>();
		Collection<EStructuralFeature.Setting> settings = crossReferences
				.get(target);
		for (EStructuralFeature.Setting setting : settings) {
			if (setting.getEStructuralFeature() != OmtgPackage.eINSTANCE
					.getbaseRelationship_Target()
					|| false == setting.getEObject() instanceof SpatialAgregation) {
				continue;
			}
			SpatialAgregation link = (SpatialAgregation) setting.getEObject();
			if (SpatialAgregationEditPart.VISUAL_ID != OmtgVisualIDRegistry
					.getLinkWithClassVisualID(link)) {
				continue;
			}
			omtg.element src = link.getSource();
			result.add(new OmtgLinkDescriptor(src, target, link,
					OmtgElementTypes.SpatialAgregation_4001,
					SpatialAgregationEditPart.VISUAL_ID));
		}
		return result;
	}

	/**
	 * @generated
	 */
	private static Collection<OmtgLinkDescriptor> getIncomingTypeModelFacetLinks_OverlappingTotal_4002(
			omtg.element target,
			Map<EObject, Collection<EStructuralFeature.Setting>> crossReferences) {
		LinkedList<OmtgLinkDescriptor> result = new LinkedList<OmtgLinkDescriptor>();
		Collection<EStructuralFeature.Setting> settings = crossReferences
				.get(target);
		for (EStructuralFeature.Setting setting : settings) {
			if (setting.getEStructuralFeature() != OmtgPackage.eINSTANCE
					.getbaseRelationship_Target()
					|| false == setting.getEObject() instanceof OverlappingTotal) {
				continue;
			}
			OverlappingTotal link = (OverlappingTotal) setting.getEObject();
			if (OverlappingTotalEditPart.VISUAL_ID != OmtgVisualIDRegistry
					.getLinkWithClassVisualID(link)) {
				continue;
			}
			omtg.element src = link.getSource();
			result.add(new OmtgLinkDescriptor(src, target, link,
					OmtgElementTypes.OverlappingTotal_4002,
					OverlappingTotalEditPart.VISUAL_ID));
		}
		return result;
	}

	/**
	 * @generated
	 */
	private static Collection<OmtgLinkDescriptor> getIncomingTypeModelFacetLinks_DisjointPartial_4003(
			omtg.element target,
			Map<EObject, Collection<EStructuralFeature.Setting>> crossReferences) {
		LinkedList<OmtgLinkDescriptor> result = new LinkedList<OmtgLinkDescriptor>();
		Collection<EStructuralFeature.Setting> settings = crossReferences
				.get(target);
		for (EStructuralFeature.Setting setting : settings) {
			if (setting.getEStructuralFeature() != OmtgPackage.eINSTANCE
					.getbaseRelationship_Target()
					|| false == setting.getEObject() instanceof DisjointPartial) {
				continue;
			}
			DisjointPartial link = (DisjointPartial) setting.getEObject();
			if (DisjointPartialEditPart.VISUAL_ID != OmtgVisualIDRegistry
					.getLinkWithClassVisualID(link)) {
				continue;
			}
			omtg.element src = link.getSource();
			result.add(new OmtgLinkDescriptor(src, target, link,
					OmtgElementTypes.DisjointPartial_4003,
					DisjointPartialEditPart.VISUAL_ID));
		}
		return result;
	}

	/**
	 * @generated
	 */
	private static Collection<OmtgLinkDescriptor> getIncomingTypeModelFacetLinks_Simple_4004(
			omtg.element target,
			Map<EObject, Collection<EStructuralFeature.Setting>> crossReferences) {
		LinkedList<OmtgLinkDescriptor> result = new LinkedList<OmtgLinkDescriptor>();
		Collection<EStructuralFeature.Setting> settings = crossReferences
				.get(target);
		for (EStructuralFeature.Setting setting : settings) {
			if (setting.getEStructuralFeature() != OmtgPackage.eINSTANCE
					.getbaseRelationship_Target()
					|| false == setting.getEObject() instanceof Simple) {
				continue;
			}
			Simple link = (Simple) setting.getEObject();
			if (SimpleEditPart.VISUAL_ID != OmtgVisualIDRegistry
					.getLinkWithClassVisualID(link)) {
				continue;
			}
			omtg.element src = link.getSource();
			result.add(new OmtgLinkDescriptor(src, target, link,
					OmtgElementTypes.Simple_4004, SimpleEditPart.VISUAL_ID));
		}
		return result;
	}

	/**
	 * @generated
	 */
	private static Collection<OmtgLinkDescriptor> getIncomingTypeModelFacetLinks_Scale_4005(
			omtg.element target,
			Map<EObject, Collection<EStructuralFeature.Setting>> crossReferences) {
		LinkedList<OmtgLinkDescriptor> result = new LinkedList<OmtgLinkDescriptor>();
		Collection<EStructuralFeature.Setting> settings = crossReferences
				.get(target);
		for (EStructuralFeature.Setting setting : settings) {
			if (setting.getEStructuralFeature() != OmtgPackage.eINSTANCE
					.getbaseRelationship_Target()
					|| false == setting.getEObject() instanceof Scale) {
				continue;
			}
			Scale link = (Scale) setting.getEObject();
			if (ScaleEditPart.VISUAL_ID != OmtgVisualIDRegistry
					.getLinkWithClassVisualID(link)) {
				continue;
			}
			omtg.element src = link.getSource();
			result.add(new OmtgLinkDescriptor(src, target, link,
					OmtgElementTypes.Scale_4005, ScaleEditPart.VISUAL_ID));
		}
		return result;
	}

	/**
	 * @generated
	 */
	private static Collection<OmtgLinkDescriptor> getIncomingTypeModelFacetLinks_Shape_4006(
			omtg.element target,
			Map<EObject, Collection<EStructuralFeature.Setting>> crossReferences) {
		LinkedList<OmtgLinkDescriptor> result = new LinkedList<OmtgLinkDescriptor>();
		Collection<EStructuralFeature.Setting> settings = crossReferences
				.get(target);
		for (EStructuralFeature.Setting setting : settings) {
			if (setting.getEStructuralFeature() != OmtgPackage.eINSTANCE
					.getbaseRelationship_Target()
					|| false == setting.getEObject() instanceof Shape) {
				continue;
			}
			Shape link = (Shape) setting.getEObject();
			if (ShapeEditPart.VISUAL_ID != OmtgVisualIDRegistry
					.getLinkWithClassVisualID(link)) {
				continue;
			}
			omtg.element src = link.getSource();
			result.add(new OmtgLinkDescriptor(src, target, link,
					OmtgElementTypes.Shape_4006, ShapeEditPart.VISUAL_ID));
		}
		return result;
	}

	/**
	 * @generated
	 */
	private static Collection<OmtgLinkDescriptor> getIncomingTypeModelFacetLinks_Agregation_4007(
			omtg.element target,
			Map<EObject, Collection<EStructuralFeature.Setting>> crossReferences) {
		LinkedList<OmtgLinkDescriptor> result = new LinkedList<OmtgLinkDescriptor>();
		Collection<EStructuralFeature.Setting> settings = crossReferences
				.get(target);
		for (EStructuralFeature.Setting setting : settings) {
			if (setting.getEStructuralFeature() != OmtgPackage.eINSTANCE
					.getbaseRelationship_Target()
					|| false == setting.getEObject() instanceof Agregation) {
				continue;
			}
			Agregation link = (Agregation) setting.getEObject();
			if (AgregationEditPart.VISUAL_ID != OmtgVisualIDRegistry
					.getLinkWithClassVisualID(link)) {
				continue;
			}
			omtg.element src = link.getSource();
			result.add(new OmtgLinkDescriptor(src, target, link,
					OmtgElementTypes.Agregation_4007,
					AgregationEditPart.VISUAL_ID));
		}
		return result;
	}

	/**
	 * @generated
	 */
	private static Collection<OmtgLinkDescriptor> getIncomingTypeModelFacetLinks_Spatial_4008(
			omtg.element target,
			Map<EObject, Collection<EStructuralFeature.Setting>> crossReferences) {
		LinkedList<OmtgLinkDescriptor> result = new LinkedList<OmtgLinkDescriptor>();
		Collection<EStructuralFeature.Setting> settings = crossReferences
				.get(target);
		for (EStructuralFeature.Setting setting : settings) {
			if (setting.getEStructuralFeature() != OmtgPackage.eINSTANCE
					.getbaseRelationship_Target()
					|| false == setting.getEObject() instanceof Spatial) {
				continue;
			}
			Spatial link = (Spatial) setting.getEObject();
			if (SpatialEditPart.VISUAL_ID != OmtgVisualIDRegistry
					.getLinkWithClassVisualID(link)) {
				continue;
			}
			omtg.element src = link.getSource();
			result.add(new OmtgLinkDescriptor(src, target, link,
					OmtgElementTypes.Spatial_4008, SpatialEditPart.VISUAL_ID));
		}
		return result;
	}

	/**
	 * @generated
	 */
	private static Collection<OmtgLinkDescriptor> getIncomingTypeModelFacetLinks_NetworkAssociation_4009(
			omtg.element target,
			Map<EObject, Collection<EStructuralFeature.Setting>> crossReferences) {
		LinkedList<OmtgLinkDescriptor> result = new LinkedList<OmtgLinkDescriptor>();
		Collection<EStructuralFeature.Setting> settings = crossReferences
				.get(target);
		for (EStructuralFeature.Setting setting : settings) {
			if (setting.getEStructuralFeature() != OmtgPackage.eINSTANCE
					.getbaseRelationship_Target()
					|| false == setting.getEObject() instanceof NetworkAssociation) {
				continue;
			}
			NetworkAssociation link = (NetworkAssociation) setting.getEObject();
			if (NetworkAssociationEditPart.VISUAL_ID != OmtgVisualIDRegistry
					.getLinkWithClassVisualID(link)) {
				continue;
			}
			omtg.element src = link.getSource();
			result.add(new OmtgLinkDescriptor(src, target, link,
					OmtgElementTypes.NetworkAssociation_4009,
					NetworkAssociationEditPart.VISUAL_ID));
		}
		return result;
	}

	/**
	 * @generated
	 */
	private static Collection<OmtgLinkDescriptor> getIncomingTypeModelFacetLinks_DisjointTotal_4010(
			omtg.element target,
			Map<EObject, Collection<EStructuralFeature.Setting>> crossReferences) {
		LinkedList<OmtgLinkDescriptor> result = new LinkedList<OmtgLinkDescriptor>();
		Collection<EStructuralFeature.Setting> settings = crossReferences
				.get(target);
		for (EStructuralFeature.Setting setting : settings) {
			if (setting.getEStructuralFeature() != OmtgPackage.eINSTANCE
					.getbaseRelationship_Target()
					|| false == setting.getEObject() instanceof DisjointTotal) {
				continue;
			}
			DisjointTotal link = (DisjointTotal) setting.getEObject();
			if (DisjointTotalEditPart.VISUAL_ID != OmtgVisualIDRegistry
					.getLinkWithClassVisualID(link)) {
				continue;
			}
			omtg.element src = link.getSource();
			result.add(new OmtgLinkDescriptor(src, target, link,
					OmtgElementTypes.DisjointTotal_4010,
					DisjointTotalEditPart.VISUAL_ID));
		}
		return result;
	}

	/**
	 * @generated
	 */
	private static Collection<OmtgLinkDescriptor> getIncomingTypeModelFacetLinks_OverlappingPartial_4011(
			omtg.element target,
			Map<EObject, Collection<EStructuralFeature.Setting>> crossReferences) {
		LinkedList<OmtgLinkDescriptor> result = new LinkedList<OmtgLinkDescriptor>();
		Collection<EStructuralFeature.Setting> settings = crossReferences
				.get(target);
		for (EStructuralFeature.Setting setting : settings) {
			if (setting.getEStructuralFeature() != OmtgPackage.eINSTANCE
					.getbaseRelationship_Target()
					|| false == setting.getEObject() instanceof OverlappingPartial) {
				continue;
			}
			OverlappingPartial link = (OverlappingPartial) setting.getEObject();
			if (OverlappingPartialEditPart.VISUAL_ID != OmtgVisualIDRegistry
					.getLinkWithClassVisualID(link)) {
				continue;
			}
			omtg.element src = link.getSource();
			result.add(new OmtgLinkDescriptor(src, target, link,
					OmtgElementTypes.OverlappingPartial_4011,
					OverlappingPartialEditPart.VISUAL_ID));
		}
		return result;
	}

	/**
	 * @generated
	 */
	private static Collection<OmtgLinkDescriptor> getOutgoingTypeModelFacetLinks_SpatialAgregation_4001(
			omtg.element source) {
		Schema container = null;
		// Find container element for the link.
		// Climb up by containment hierarchy starting from the source
		// and return the first element that is instance of the container class.
		for (EObject element = source; element != null && container == null; element = element
				.eContainer()) {
			if (element instanceof Schema) {
				container = (Schema) element;
			}
		}
		if (container == null) {
			return Collections.emptyList();
		}
		LinkedList<OmtgLinkDescriptor> result = new LinkedList<OmtgLinkDescriptor>();
		for (Iterator<?> links = container.getRelationship().iterator(); links
				.hasNext();) {
			EObject linkObject = (EObject) links.next();
			if (false == linkObject instanceof SpatialAgregation) {
				continue;
			}
			SpatialAgregation link = (SpatialAgregation) linkObject;
			if (SpatialAgregationEditPart.VISUAL_ID != OmtgVisualIDRegistry
					.getLinkWithClassVisualID(link)) {
				continue;
			}
			omtg.element dst = link.getTarget();
			omtg.element src = link.getSource();
			if (src != source) {
				continue;
			}
			result.add(new OmtgLinkDescriptor(src, dst, link,
					OmtgElementTypes.SpatialAgregation_4001,
					SpatialAgregationEditPart.VISUAL_ID));
		}
		return result;
	}

	/**
	 * @generated
	 */
	private static Collection<OmtgLinkDescriptor> getOutgoingTypeModelFacetLinks_OverlappingTotal_4002(
			omtg.element source) {
		Schema container = null;
		// Find container element for the link.
		// Climb up by containment hierarchy starting from the source
		// and return the first element that is instance of the container class.
		for (EObject element = source; element != null && container == null; element = element
				.eContainer()) {
			if (element instanceof Schema) {
				container = (Schema) element;
			}
		}
		if (container == null) {
			return Collections.emptyList();
		}
		LinkedList<OmtgLinkDescriptor> result = new LinkedList<OmtgLinkDescriptor>();
		for (Iterator<?> links = container.getRelationship().iterator(); links
				.hasNext();) {
			EObject linkObject = (EObject) links.next();
			if (false == linkObject instanceof OverlappingTotal) {
				continue;
			}
			OverlappingTotal link = (OverlappingTotal) linkObject;
			if (OverlappingTotalEditPart.VISUAL_ID != OmtgVisualIDRegistry
					.getLinkWithClassVisualID(link)) {
				continue;
			}
			omtg.element dst = link.getTarget();
			omtg.element src = link.getSource();
			if (src != source) {
				continue;
			}
			result.add(new OmtgLinkDescriptor(src, dst, link,
					OmtgElementTypes.OverlappingTotal_4002,
					OverlappingTotalEditPart.VISUAL_ID));
		}
		return result;
	}

	/**
	 * @generated
	 */
	private static Collection<OmtgLinkDescriptor> getOutgoingTypeModelFacetLinks_DisjointPartial_4003(
			omtg.element source) {
		Schema container = null;
		// Find container element for the link.
		// Climb up by containment hierarchy starting from the source
		// and return the first element that is instance of the container class.
		for (EObject element = source; element != null && container == null; element = element
				.eContainer()) {
			if (element instanceof Schema) {
				container = (Schema) element;
			}
		}
		if (container == null) {
			return Collections.emptyList();
		}
		LinkedList<OmtgLinkDescriptor> result = new LinkedList<OmtgLinkDescriptor>();
		for (Iterator<?> links = container.getRelationship().iterator(); links
				.hasNext();) {
			EObject linkObject = (EObject) links.next();
			if (false == linkObject instanceof DisjointPartial) {
				continue;
			}
			DisjointPartial link = (DisjointPartial) linkObject;
			if (DisjointPartialEditPart.VISUAL_ID != OmtgVisualIDRegistry
					.getLinkWithClassVisualID(link)) {
				continue;
			}
			omtg.element dst = link.getTarget();
			omtg.element src = link.getSource();
			if (src != source) {
				continue;
			}
			result.add(new OmtgLinkDescriptor(src, dst, link,
					OmtgElementTypes.DisjointPartial_4003,
					DisjointPartialEditPart.VISUAL_ID));
		}
		return result;
	}

	/**
	 * @generated
	 */
	private static Collection<OmtgLinkDescriptor> getOutgoingTypeModelFacetLinks_Simple_4004(
			omtg.element source) {
		Schema container = null;
		// Find container element for the link.
		// Climb up by containment hierarchy starting from the source
		// and return the first element that is instance of the container class.
		for (EObject element = source; element != null && container == null; element = element
				.eContainer()) {
			if (element instanceof Schema) {
				container = (Schema) element;
			}
		}
		if (container == null) {
			return Collections.emptyList();
		}
		LinkedList<OmtgLinkDescriptor> result = new LinkedList<OmtgLinkDescriptor>();
		for (Iterator<?> links = container.getRelationship().iterator(); links
				.hasNext();) {
			EObject linkObject = (EObject) links.next();
			if (false == linkObject instanceof Simple) {
				continue;
			}
			Simple link = (Simple) linkObject;
			if (SimpleEditPart.VISUAL_ID != OmtgVisualIDRegistry
					.getLinkWithClassVisualID(link)) {
				continue;
			}
			omtg.element dst = link.getTarget();
			omtg.element src = link.getSource();
			if (src != source) {
				continue;
			}
			result.add(new OmtgLinkDescriptor(src, dst, link,
					OmtgElementTypes.Simple_4004, SimpleEditPart.VISUAL_ID));
		}
		return result;
	}

	/**
	 * @generated
	 */
	private static Collection<OmtgLinkDescriptor> getOutgoingTypeModelFacetLinks_Scale_4005(
			omtg.element source) {
		Schema container = null;
		// Find container element for the link.
		// Climb up by containment hierarchy starting from the source
		// and return the first element that is instance of the container class.
		for (EObject element = source; element != null && container == null; element = element
				.eContainer()) {
			if (element instanceof Schema) {
				container = (Schema) element;
			}
		}
		if (container == null) {
			return Collections.emptyList();
		}
		LinkedList<OmtgLinkDescriptor> result = new LinkedList<OmtgLinkDescriptor>();
		for (Iterator<?> links = container.getRelationship().iterator(); links
				.hasNext();) {
			EObject linkObject = (EObject) links.next();
			if (false == linkObject instanceof Scale) {
				continue;
			}
			Scale link = (Scale) linkObject;
			if (ScaleEditPart.VISUAL_ID != OmtgVisualIDRegistry
					.getLinkWithClassVisualID(link)) {
				continue;
			}
			omtg.element dst = link.getTarget();
			omtg.element src = link.getSource();
			if (src != source) {
				continue;
			}
			result.add(new OmtgLinkDescriptor(src, dst, link,
					OmtgElementTypes.Scale_4005, ScaleEditPart.VISUAL_ID));
		}
		return result;
	}

	/**
	 * @generated
	 */
	private static Collection<OmtgLinkDescriptor> getOutgoingTypeModelFacetLinks_Shape_4006(
			omtg.element source) {
		Schema container = null;
		// Find container element for the link.
		// Climb up by containment hierarchy starting from the source
		// and return the first element that is instance of the container class.
		for (EObject element = source; element != null && container == null; element = element
				.eContainer()) {
			if (element instanceof Schema) {
				container = (Schema) element;
			}
		}
		if (container == null) {
			return Collections.emptyList();
		}
		LinkedList<OmtgLinkDescriptor> result = new LinkedList<OmtgLinkDescriptor>();
		for (Iterator<?> links = container.getRelationship().iterator(); links
				.hasNext();) {
			EObject linkObject = (EObject) links.next();
			if (false == linkObject instanceof Shape) {
				continue;
			}
			Shape link = (Shape) linkObject;
			if (ShapeEditPart.VISUAL_ID != OmtgVisualIDRegistry
					.getLinkWithClassVisualID(link)) {
				continue;
			}
			omtg.element dst = link.getTarget();
			omtg.element src = link.getSource();
			if (src != source) {
				continue;
			}
			result.add(new OmtgLinkDescriptor(src, dst, link,
					OmtgElementTypes.Shape_4006, ShapeEditPart.VISUAL_ID));
		}
		return result;
	}

	/**
	 * @generated
	 */
	private static Collection<OmtgLinkDescriptor> getOutgoingTypeModelFacetLinks_Agregation_4007(
			omtg.element source) {
		Schema container = null;
		// Find container element for the link.
		// Climb up by containment hierarchy starting from the source
		// and return the first element that is instance of the container class.
		for (EObject element = source; element != null && container == null; element = element
				.eContainer()) {
			if (element instanceof Schema) {
				container = (Schema) element;
			}
		}
		if (container == null) {
			return Collections.emptyList();
		}
		LinkedList<OmtgLinkDescriptor> result = new LinkedList<OmtgLinkDescriptor>();
		for (Iterator<?> links = container.getRelationship().iterator(); links
				.hasNext();) {
			EObject linkObject = (EObject) links.next();
			if (false == linkObject instanceof Agregation) {
				continue;
			}
			Agregation link = (Agregation) linkObject;
			if (AgregationEditPart.VISUAL_ID != OmtgVisualIDRegistry
					.getLinkWithClassVisualID(link)) {
				continue;
			}
			omtg.element dst = link.getTarget();
			omtg.element src = link.getSource();
			if (src != source) {
				continue;
			}
			result.add(new OmtgLinkDescriptor(src, dst, link,
					OmtgElementTypes.Agregation_4007,
					AgregationEditPart.VISUAL_ID));
		}
		return result;
	}

	/**
	 * @generated
	 */
	private static Collection<OmtgLinkDescriptor> getOutgoingTypeModelFacetLinks_Spatial_4008(
			omtg.element source) {
		Schema container = null;
		// Find container element for the link.
		// Climb up by containment hierarchy starting from the source
		// and return the first element that is instance of the container class.
		for (EObject element = source; element != null && container == null; element = element
				.eContainer()) {
			if (element instanceof Schema) {
				container = (Schema) element;
			}
		}
		if (container == null) {
			return Collections.emptyList();
		}
		LinkedList<OmtgLinkDescriptor> result = new LinkedList<OmtgLinkDescriptor>();
		for (Iterator<?> links = container.getRelationship().iterator(); links
				.hasNext();) {
			EObject linkObject = (EObject) links.next();
			if (false == linkObject instanceof Spatial) {
				continue;
			}
			Spatial link = (Spatial) linkObject;
			if (SpatialEditPart.VISUAL_ID != OmtgVisualIDRegistry
					.getLinkWithClassVisualID(link)) {
				continue;
			}
			omtg.element dst = link.getTarget();
			omtg.element src = link.getSource();
			if (src != source) {
				continue;
			}
			result.add(new OmtgLinkDescriptor(src, dst, link,
					OmtgElementTypes.Spatial_4008, SpatialEditPart.VISUAL_ID));
		}
		return result;
	}

	/**
	 * @generated
	 */
	private static Collection<OmtgLinkDescriptor> getOutgoingTypeModelFacetLinks_NetworkAssociation_4009(
			omtg.element source) {
		Schema container = null;
		// Find container element for the link.
		// Climb up by containment hierarchy starting from the source
		// and return the first element that is instance of the container class.
		for (EObject element = source; element != null && container == null; element = element
				.eContainer()) {
			if (element instanceof Schema) {
				container = (Schema) element;
			}
		}
		if (container == null) {
			return Collections.emptyList();
		}
		LinkedList<OmtgLinkDescriptor> result = new LinkedList<OmtgLinkDescriptor>();
		for (Iterator<?> links = container.getRelationship().iterator(); links
				.hasNext();) {
			EObject linkObject = (EObject) links.next();
			if (false == linkObject instanceof NetworkAssociation) {
				continue;
			}
			NetworkAssociation link = (NetworkAssociation) linkObject;
			if (NetworkAssociationEditPart.VISUAL_ID != OmtgVisualIDRegistry
					.getLinkWithClassVisualID(link)) {
				continue;
			}
			omtg.element dst = link.getTarget();
			omtg.element src = link.getSource();
			if (src != source) {
				continue;
			}
			result.add(new OmtgLinkDescriptor(src, dst, link,
					OmtgElementTypes.NetworkAssociation_4009,
					NetworkAssociationEditPart.VISUAL_ID));
		}
		return result;
	}

	/**
	 * @generated
	 */
	private static Collection<OmtgLinkDescriptor> getOutgoingTypeModelFacetLinks_DisjointTotal_4010(
			omtg.element source) {
		Schema container = null;
		// Find container element for the link.
		// Climb up by containment hierarchy starting from the source
		// and return the first element that is instance of the container class.
		for (EObject element = source; element != null && container == null; element = element
				.eContainer()) {
			if (element instanceof Schema) {
				container = (Schema) element;
			}
		}
		if (container == null) {
			return Collections.emptyList();
		}
		LinkedList<OmtgLinkDescriptor> result = new LinkedList<OmtgLinkDescriptor>();
		for (Iterator<?> links = container.getRelationship().iterator(); links
				.hasNext();) {
			EObject linkObject = (EObject) links.next();
			if (false == linkObject instanceof DisjointTotal) {
				continue;
			}
			DisjointTotal link = (DisjointTotal) linkObject;
			if (DisjointTotalEditPart.VISUAL_ID != OmtgVisualIDRegistry
					.getLinkWithClassVisualID(link)) {
				continue;
			}
			omtg.element dst = link.getTarget();
			omtg.element src = link.getSource();
			if (src != source) {
				continue;
			}
			result.add(new OmtgLinkDescriptor(src, dst, link,
					OmtgElementTypes.DisjointTotal_4010,
					DisjointTotalEditPart.VISUAL_ID));
		}
		return result;
	}

	/**
	 * @generated
	 */
	private static Collection<OmtgLinkDescriptor> getOutgoingTypeModelFacetLinks_OverlappingPartial_4011(
			omtg.element source) {
		Schema container = null;
		// Find container element for the link.
		// Climb up by containment hierarchy starting from the source
		// and return the first element that is instance of the container class.
		for (EObject element = source; element != null && container == null; element = element
				.eContainer()) {
			if (element instanceof Schema) {
				container = (Schema) element;
			}
		}
		if (container == null) {
			return Collections.emptyList();
		}
		LinkedList<OmtgLinkDescriptor> result = new LinkedList<OmtgLinkDescriptor>();
		for (Iterator<?> links = container.getRelationship().iterator(); links
				.hasNext();) {
			EObject linkObject = (EObject) links.next();
			if (false == linkObject instanceof OverlappingPartial) {
				continue;
			}
			OverlappingPartial link = (OverlappingPartial) linkObject;
			if (OverlappingPartialEditPart.VISUAL_ID != OmtgVisualIDRegistry
					.getLinkWithClassVisualID(link)) {
				continue;
			}
			omtg.element dst = link.getTarget();
			omtg.element src = link.getSource();
			if (src != source) {
				continue;
			}
			result.add(new OmtgLinkDescriptor(src, dst, link,
					OmtgElementTypes.OverlappingPartial_4011,
					OverlappingPartialEditPart.VISUAL_ID));
		}
		return result;
	}

	/**
	 * @generated
	 */
	public static final DiagramUpdater TYPED_INSTANCE = new DiagramUpdater() {
		/**
		 * @generated
		 */
		@Override
		public List<OmtgNodeDescriptor> getSemanticChildren(View view) {
			return OmtgDiagramUpdater.getSemanticChildren(view);
		}

		/**
		 * @generated
		 */
		@Override
		public List<OmtgLinkDescriptor> getContainedLinks(View view) {
			return OmtgDiagramUpdater.getContainedLinks(view);
		}

		/**
		 * @generated
		 */
		@Override
		public List<OmtgLinkDescriptor> getIncomingLinks(View view) {
			return OmtgDiagramUpdater.getIncomingLinks(view);
		}

		/**
		 * @generated
		 */
		@Override
		public List<OmtgLinkDescriptor> getOutgoingLinks(View view) {
			return OmtgDiagramUpdater.getOutgoingLinks(view);
		}
	};

}
