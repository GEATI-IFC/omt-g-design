package omtg.diagram.edit.parts;

import omtg.diagram.part.OmtgVisualIDRegistry;

import org.eclipse.gef.EditPart;
import org.eclipse.gef.EditPartFactory;
import org.eclipse.gef.tools.CellEditorLocator;
import org.eclipse.gmf.runtime.diagram.ui.editparts.ITextAwareEditPart;
import org.eclipse.gmf.runtime.notation.View;
import org.eclipse.gmf.tooling.runtime.directedit.locator.CellEditorLocatorAccess;

/**
 * @generated
 */
public class OmtgEditPartFactory implements EditPartFactory {

	/**
	 * @generated
	 */
	public EditPart createEditPart(EditPart context, Object model) {
		if (model instanceof View) {
			View view = (View) model;
			switch (OmtgVisualIDRegistry.getVisualID(view)) {

			case SchemaEditPart.VISUAL_ID:
				return new SchemaEditPart(view);

			case PolygonEditPart.VISUAL_ID:
				return new PolygonEditPart(view);

			case PolygonNameEditPart.VISUAL_ID:
				return new PolygonNameEditPart(view);

			case PointEditPart.VISUAL_ID:
				return new PointEditPart(view);

			case PointNameEditPart.VISUAL_ID:
				return new PointNameEditPart(view);

			case LineEditPart.VISUAL_ID:
				return new LineEditPart(view);

			case LineNameEditPart.VISUAL_ID:
				return new LineNameEditPart(view);

			case NetworkClassEditPart.VISUAL_ID:
				return new NetworkClassEditPart(view);

			case NetworkClassNameEditPart.VISUAL_ID:
				return new NetworkClassNameEditPart(view);

			case SamplingEditPart.VISUAL_ID:
				return new SamplingEditPart(view);

			case SamplingNameEditPart.VISUAL_ID:
				return new SamplingNameEditPart(view);

			case IsolineEditPart.VISUAL_ID:
				return new IsolineEditPart(view);

			case IsolineNameEditPart.VISUAL_ID:
				return new IsolineNameEditPart(view);

			case NodeEditPart.VISUAL_ID:
				return new NodeEditPart(view);

			case NodeNameEditPart.VISUAL_ID:
				return new NodeNameEditPart(view);

			case AdjacentPolygonsEditPart.VISUAL_ID:
				return new AdjacentPolygonsEditPart(view);

			case AdjacentPolygonsNameEditPart.VISUAL_ID:
				return new AdjacentPolygonsNameEditPart(view);

			case BidirectionalLineEditPart.VISUAL_ID:
				return new BidirectionalLineEditPart(view);

			case BidirectionalLineNameEditPart.VISUAL_ID:
				return new BidirectionalLineNameEditPart(view);

			case TesselationEditPart.VISUAL_ID:
				return new TesselationEditPart(view);

			case TesselationNameEditPart.VISUAL_ID:
				return new TesselationNameEditPart(view);

			case UnidirectionalLineEditPart.VISUAL_ID:
				return new UnidirectionalLineEditPart(view);

			case UnidirectionalLineNameEditPart.VISUAL_ID:
				return new UnidirectionalLineNameEditPart(view);

			case ConventionalEditPart.VISUAL_ID:
				return new ConventionalEditPart(view);

			case ConventionalNameEditPart.VISUAL_ID:
				return new ConventionalNameEditPart(view);

			case AttributeEditPart.VISUAL_ID:
				return new AttributeEditPart(view);

			case AttributeNameTypeEditPart.VISUAL_ID:
				return new AttributeNameTypeEditPart(view);

			case MethodEditPart.VISUAL_ID:
				return new MethodEditPart(view);

			case MethodNameAttibutesReturnEditPart.VISUAL_ID:
				return new MethodNameAttibutesReturnEditPart(view);

			case Attribute2EditPart.VISUAL_ID:
				return new Attribute2EditPart(view);

			case AttributeNameType2EditPart.VISUAL_ID:
				return new AttributeNameType2EditPart(view);

			case Method2EditPart.VISUAL_ID:
				return new Method2EditPart(view);

			case MethodNameAttibutesReturn2EditPart.VISUAL_ID:
				return new MethodNameAttibutesReturn2EditPart(view);

			case Attribute3EditPart.VISUAL_ID:
				return new Attribute3EditPart(view);

			case AttributeNameType3EditPart.VISUAL_ID:
				return new AttributeNameType3EditPart(view);

			case Method3EditPart.VISUAL_ID:
				return new Method3EditPart(view);

			case MethodNameAttibutesReturn3EditPart.VISUAL_ID:
				return new MethodNameAttibutesReturn3EditPart(view);

			case Attribute4EditPart.VISUAL_ID:
				return new Attribute4EditPart(view);

			case AttributeNameType4EditPart.VISUAL_ID:
				return new AttributeNameType4EditPart(view);

			case Method4EditPart.VISUAL_ID:
				return new Method4EditPart(view);

			case MethodNameAttibutesReturn4EditPart.VISUAL_ID:
				return new MethodNameAttibutesReturn4EditPart(view);

			case Attribute5EditPart.VISUAL_ID:
				return new Attribute5EditPart(view);

			case AttributeNameType5EditPart.VISUAL_ID:
				return new AttributeNameType5EditPart(view);

			case Method5EditPart.VISUAL_ID:
				return new Method5EditPart(view);

			case MethodNameAttibutesReturn5EditPart.VISUAL_ID:
				return new MethodNameAttibutesReturn5EditPart(view);

			case Attribute6EditPart.VISUAL_ID:
				return new Attribute6EditPart(view);

			case AttributeNameType6EditPart.VISUAL_ID:
				return new AttributeNameType6EditPart(view);

			case Method6EditPart.VISUAL_ID:
				return new Method6EditPart(view);

			case MethodNameAttibutesReturn6EditPart.VISUAL_ID:
				return new MethodNameAttibutesReturn6EditPart(view);

			case Attribute7EditPart.VISUAL_ID:
				return new Attribute7EditPart(view);

			case AttributeNameType7EditPart.VISUAL_ID:
				return new AttributeNameType7EditPart(view);

			case Method7EditPart.VISUAL_ID:
				return new Method7EditPart(view);

			case MethodNameAttibutesReturn7EditPart.VISUAL_ID:
				return new MethodNameAttibutesReturn7EditPart(view);

			case Attribute8EditPart.VISUAL_ID:
				return new Attribute8EditPart(view);

			case AttributeNameType8EditPart.VISUAL_ID:
				return new AttributeNameType8EditPart(view);

			case Method8EditPart.VISUAL_ID:
				return new Method8EditPart(view);

			case MethodNameAttibutesReturn8EditPart.VISUAL_ID:
				return new MethodNameAttibutesReturn8EditPart(view);

			case Attribute9EditPart.VISUAL_ID:
				return new Attribute9EditPart(view);

			case AttributeNameType9EditPart.VISUAL_ID:
				return new AttributeNameType9EditPart(view);

			case Method9EditPart.VISUAL_ID:
				return new Method9EditPart(view);

			case MethodNameAttibutesReturn9EditPart.VISUAL_ID:
				return new MethodNameAttibutesReturn9EditPart(view);

			case Attribute10EditPart.VISUAL_ID:
				return new Attribute10EditPart(view);

			case AttributeNameType10EditPart.VISUAL_ID:
				return new AttributeNameType10EditPart(view);

			case Method10EditPart.VISUAL_ID:
				return new Method10EditPart(view);

			case MethodNameAttibutesReturn10EditPart.VISUAL_ID:
				return new MethodNameAttibutesReturn10EditPart(view);

			case Attribute11EditPart.VISUAL_ID:
				return new Attribute11EditPart(view);

			case AttributeNameType11EditPart.VISUAL_ID:
				return new AttributeNameType11EditPart(view);

			case Method11EditPart.VISUAL_ID:
				return new Method11EditPart(view);

			case MethodNameAttibutesReturn11EditPart.VISUAL_ID:
				return new MethodNameAttibutesReturn11EditPart(view);

			case Attribute12EditPart.VISUAL_ID:
				return new Attribute12EditPart(view);

			case AttributeNameType12EditPart.VISUAL_ID:
				return new AttributeNameType12EditPart(view);

			case Method12EditPart.VISUAL_ID:
				return new Method12EditPart(view);

			case MethodNameAttibutesReturn12EditPart.VISUAL_ID:
				return new MethodNameAttibutesReturn12EditPart(view);

			case PolygonBaseClassCompartmentGraphicalEditPart.VISUAL_ID:
				return new PolygonBaseClassCompartmentGraphicalEditPart(view);

			case PolygonBaseClassCompartmentGraphical2EditPart.VISUAL_ID:
				return new PolygonBaseClassCompartmentGraphical2EditPart(view);

			case PointBaseClassCompartmentGraphicalEditPart.VISUAL_ID:
				return new PointBaseClassCompartmentGraphicalEditPart(view);

			case PointBaseClassCompartmentGraphical2EditPart.VISUAL_ID:
				return new PointBaseClassCompartmentGraphical2EditPart(view);

			case LineBaseClassCompartmentGraphicalEditPart.VISUAL_ID:
				return new LineBaseClassCompartmentGraphicalEditPart(view);

			case LineBaseClassCompartmentGraphical2EditPart.VISUAL_ID:
				return new LineBaseClassCompartmentGraphical2EditPart(view);

			case NetworkClassBaseClassCompartmentGraphicalEditPart.VISUAL_ID:
				return new NetworkClassBaseClassCompartmentGraphicalEditPart(
						view);

			case NetworkClassBaseClassCompartmentGraphical2EditPart.VISUAL_ID:
				return new NetworkClassBaseClassCompartmentGraphical2EditPart(
						view);

			case SamplingBaseClassCompartmentGraphicalEditPart.VISUAL_ID:
				return new SamplingBaseClassCompartmentGraphicalEditPart(view);

			case SamplingBaseClassCompartmentGraphical2EditPart.VISUAL_ID:
				return new SamplingBaseClassCompartmentGraphical2EditPart(view);

			case IsolineBaseClassCompartmentGraphicalEditPart.VISUAL_ID:
				return new IsolineBaseClassCompartmentGraphicalEditPart(view);

			case IsolineBaseClassCompartmentGraphical2EditPart.VISUAL_ID:
				return new IsolineBaseClassCompartmentGraphical2EditPart(view);

			case NodeBaseClassCompartmentGraphicalEditPart.VISUAL_ID:
				return new NodeBaseClassCompartmentGraphicalEditPart(view);

			case NodeBaseClassCompartmentGraphical2EditPart.VISUAL_ID:
				return new NodeBaseClassCompartmentGraphical2EditPart(view);

			case AdjacentPolygonsBaseClassCompartmentGraphicalEditPart.VISUAL_ID:
				return new AdjacentPolygonsBaseClassCompartmentGraphicalEditPart(
						view);

			case AdjacentPolygonsBaseClassCompartmentGraphical2EditPart.VISUAL_ID:
				return new AdjacentPolygonsBaseClassCompartmentGraphical2EditPart(
						view);

			case BidirectionalLineBaseClassCompartmentGraphicalEditPart.VISUAL_ID:
				return new BidirectionalLineBaseClassCompartmentGraphicalEditPart(
						view);

			case BidirectionalLineBaseClassCompartmentGraphical2EditPart.VISUAL_ID:
				return new BidirectionalLineBaseClassCompartmentGraphical2EditPart(
						view);

			case TesselationBaseClassCompartmentGraphicalEditPart.VISUAL_ID:
				return new TesselationBaseClassCompartmentGraphicalEditPart(
						view);

			case TesselationBaseClassCompartmentGraphical2EditPart.VISUAL_ID:
				return new TesselationBaseClassCompartmentGraphical2EditPart(
						view);

			case UnidirectionalLineBaseClassCompartmentGraphicalEditPart.VISUAL_ID:
				return new UnidirectionalLineBaseClassCompartmentGraphicalEditPart(
						view);

			case UnidirectionalLineBaseClassCompartmentGraphical2EditPart.VISUAL_ID:
				return new UnidirectionalLineBaseClassCompartmentGraphical2EditPart(
						view);

			case ConventionalBaseClassCompartmentGraphicalEditPart.VISUAL_ID:
				return new ConventionalBaseClassCompartmentGraphicalEditPart(
						view);

			case ConventionalBaseClassCompartmentGraphical2EditPart.VISUAL_ID:
				return new ConventionalBaseClassCompartmentGraphical2EditPart(
						view);

			case SpatialAgregationEditPart.VISUAL_ID:
				return new SpatialAgregationEditPart(view);

			case OverlappingTotalEditPart.VISUAL_ID:
				return new OverlappingTotalEditPart(view);

			case DisjointPartialEditPart.VISUAL_ID:
				return new DisjointPartialEditPart(view);

			case SimpleEditPart.VISUAL_ID:
				return new SimpleEditPart(view);

			case ScaleEditPart.VISUAL_ID:
				return new ScaleEditPart(view);

			case ShapeEditPart.VISUAL_ID:
				return new ShapeEditPart(view);

			case AgregationEditPart.VISUAL_ID:
				return new AgregationEditPart(view);

			case SpatialEditPart.VISUAL_ID:
				return new SpatialEditPart(view);

			case NetworkAssociationEditPart.VISUAL_ID:
				return new NetworkAssociationEditPart(view);

			case DisjointTotalEditPart.VISUAL_ID:
				return new DisjointTotalEditPart(view);

			case OverlappingPartialEditPart.VISUAL_ID:
				return new OverlappingPartialEditPart(view);

			}
		}
		return createUnrecognizedEditPart(context, model);
	}

	/**
	 * @generated
	 */
	private EditPart createUnrecognizedEditPart(EditPart context, Object model) {
		// Handle creation of unrecognized child node EditParts here
		return null;
	}

	/**
	 * @generated
	 */
	public static CellEditorLocator getTextCellEditorLocator(
			ITextAwareEditPart source) {
		return CellEditorLocatorAccess.INSTANCE
				.getTextCellEditorLocator(source);
	}

}
