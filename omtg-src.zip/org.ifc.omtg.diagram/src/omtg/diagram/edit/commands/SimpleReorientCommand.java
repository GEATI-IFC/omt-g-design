package omtg.diagram.edit.commands;

import omtg.Schema;
import omtg.Simple;
import omtg.diagram.edit.policies.OmtgBaseItemSemanticEditPolicy;

import org.eclipse.core.commands.ExecutionException;
import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.gmf.runtime.common.core.command.CommandResult;
import org.eclipse.gmf.runtime.emf.type.core.commands.EditElementCommand;
import org.eclipse.gmf.runtime.emf.type.core.requests.ReorientRelationshipRequest;

/**
 * @generated
 */
public class SimpleReorientCommand extends EditElementCommand {

	/**
	 * @generated
	 */
	private final int reorientDirection;

	/**
	 * @generated
	 */
	private final EObject oldEnd;

	/**
	 * @generated
	 */
	private final EObject newEnd;

	/**
	 * @generated
	 */
	public SimpleReorientCommand(ReorientRelationshipRequest request) {
		super(request.getLabel(), request.getRelationship(), request);
		reorientDirection = request.getDirection();
		oldEnd = request.getOldRelationshipEnd();
		newEnd = request.getNewRelationshipEnd();
	}

	/**
	 * @generated
	 */
	public boolean canExecute() {
		if (false == getElementToEdit() instanceof Simple) {
			return false;
		}
		if (reorientDirection == ReorientRelationshipRequest.REORIENT_SOURCE) {
			return canReorientSource();
		}
		if (reorientDirection == ReorientRelationshipRequest.REORIENT_TARGET) {
			return canReorientTarget();
		}
		return false;
	}

	/**
	 * @generated
	 */
	protected boolean canReorientSource() {
		if (!(oldEnd instanceof omtg.element && newEnd instanceof omtg.element)) {
			return false;
		}
		omtg.element target = getLink().getTarget();
		if (!(getLink().eContainer() instanceof Schema)) {
			return false;
		}
		Schema container = (Schema) getLink().eContainer();
		return OmtgBaseItemSemanticEditPolicy.getLinkConstraints()
				.canExistSimple_4004(container, getLink(), getNewSource(),
						target);
	}

	/**
	 * @generated
	 */
	protected boolean canReorientTarget() {
		if (!(oldEnd instanceof omtg.element && newEnd instanceof omtg.element)) {
			return false;
		}
		omtg.element source = getLink().getSource();
		if (!(getLink().eContainer() instanceof Schema)) {
			return false;
		}
		Schema container = (Schema) getLink().eContainer();
		return OmtgBaseItemSemanticEditPolicy.getLinkConstraints()
				.canExistSimple_4004(container, getLink(), source,
						getNewTarget());
	}

	/**
	 * @generated
	 */
	protected CommandResult doExecuteWithResult(IProgressMonitor monitor,
			IAdaptable info) throws ExecutionException {
		if (!canExecute()) {
			throw new ExecutionException(
					"Invalid arguments in reorient link command"); //$NON-NLS-1$
		}
		if (reorientDirection == ReorientRelationshipRequest.REORIENT_SOURCE) {
			return reorientSource();
		}
		if (reorientDirection == ReorientRelationshipRequest.REORIENT_TARGET) {
			return reorientTarget();
		}
		throw new IllegalStateException();
	}

	/**
	 * @generated
	 */
	protected CommandResult reorientSource() throws ExecutionException {
		getLink().setSource(getNewSource());
		return CommandResult.newOKCommandResult(getLink());
	}

	/**
	 * @generated
	 */
	protected CommandResult reorientTarget() throws ExecutionException {
		getLink().setTarget(getNewTarget());
		return CommandResult.newOKCommandResult(getLink());
	}

	/**
	 * @generated
	 */
	protected Simple getLink() {
		return (Simple) getElementToEdit();
	}

	/**
	 * @generated
	 */
	protected omtg.element getOldSource() {
		return (omtg.element) oldEnd;
	}

	/**
	 * @generated
	 */
	protected omtg.element getNewSource() {
		return (omtg.element) newEnd;
	}

	/**
	 * @generated
	 */
	protected omtg.element getOldTarget() {
		return (omtg.element) oldEnd;
	}

	/**
	 * @generated
	 */
	protected omtg.element getNewTarget() {
		return (omtg.element) newEnd;
	}
}
