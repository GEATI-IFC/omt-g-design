package omtg.diagram.edit.policies;

import omtg.diagram.edit.commands.Method5CreateCommand;
import omtg.diagram.providers.OmtgElementTypes;

import org.eclipse.gef.commands.Command;
import org.eclipse.gmf.runtime.emf.type.core.requests.CreateElementRequest;

/**
 * @generated
 */
public class SamplingBaseClassCompartmentGraphical2ItemSemanticEditPolicy
		extends OmtgBaseItemSemanticEditPolicy {

	/**
	 * @generated
	 */
	public SamplingBaseClassCompartmentGraphical2ItemSemanticEditPolicy() {
		super(OmtgElementTypes.Sampling_2025);
	}

	/**
	 * @generated
	 */
	protected Command getCreateCommand(CreateElementRequest req) {
		if (OmtgElementTypes.Method_3016 == req.getElementType()) {
			return getGEFWrapper(new Method5CreateCommand(req));
		}
		return super.getCreateCommand(req);
	}

}
