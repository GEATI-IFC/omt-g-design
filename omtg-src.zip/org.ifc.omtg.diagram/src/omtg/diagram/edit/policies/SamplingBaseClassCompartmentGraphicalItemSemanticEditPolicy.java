package omtg.diagram.edit.policies;

import omtg.diagram.edit.commands.Attribute5CreateCommand;
import omtg.diagram.providers.OmtgElementTypes;

import org.eclipse.gef.commands.Command;
import org.eclipse.gmf.runtime.emf.type.core.requests.CreateElementRequest;

/**
 * @generated
 */
public class SamplingBaseClassCompartmentGraphicalItemSemanticEditPolicy extends
		OmtgBaseItemSemanticEditPolicy {

	/**
	 * @generated
	 */
	public SamplingBaseClassCompartmentGraphicalItemSemanticEditPolicy() {
		super(OmtgElementTypes.Sampling_2025);
	}

	/**
	 * @generated
	 */
	protected Command getCreateCommand(CreateElementRequest req) {
		if (OmtgElementTypes.Attribute_3005 == req.getElementType()) {
			return getGEFWrapper(new Attribute5CreateCommand(req));
		}
		return super.getCreateCommand(req);
	}

}
