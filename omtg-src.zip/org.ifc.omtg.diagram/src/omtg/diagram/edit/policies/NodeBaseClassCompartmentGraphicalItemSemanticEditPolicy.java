package omtg.diagram.edit.policies;

import omtg.diagram.edit.commands.Attribute7CreateCommand;
import omtg.diagram.providers.OmtgElementTypes;

import org.eclipse.gef.commands.Command;
import org.eclipse.gmf.runtime.emf.type.core.requests.CreateElementRequest;

/**
 * @generated
 */
public class NodeBaseClassCompartmentGraphicalItemSemanticEditPolicy extends
		OmtgBaseItemSemanticEditPolicy {

	/**
	 * @generated
	 */
	public NodeBaseClassCompartmentGraphicalItemSemanticEditPolicy() {
		super(OmtgElementTypes.Node_2019);
	}

	/**
	 * @generated
	 */
	protected Command getCreateCommand(CreateElementRequest req) {
		if (OmtgElementTypes.Attribute_3007 == req.getElementType()) {
			return getGEFWrapper(new Attribute7CreateCommand(req));
		}
		return super.getCreateCommand(req);
	}

}
