package omtg.diagram.edit.policies;

import java.util.Iterator;

import omtg.diagram.edit.commands.AgregationCreateCommand;
import omtg.diagram.edit.commands.AgregationReorientCommand;
import omtg.diagram.edit.commands.DisjointPartialCreateCommand;
import omtg.diagram.edit.commands.DisjointPartialReorientCommand;
import omtg.diagram.edit.commands.DisjointTotalCreateCommand;
import omtg.diagram.edit.commands.DisjointTotalReorientCommand;
import omtg.diagram.edit.commands.NetworkAssociationCreateCommand;
import omtg.diagram.edit.commands.NetworkAssociationReorientCommand;
import omtg.diagram.edit.commands.OverlappingPartialCreateCommand;
import omtg.diagram.edit.commands.OverlappingPartialReorientCommand;
import omtg.diagram.edit.commands.OverlappingTotalCreateCommand;
import omtg.diagram.edit.commands.OverlappingTotalReorientCommand;
import omtg.diagram.edit.commands.ScaleCreateCommand;
import omtg.diagram.edit.commands.ScaleReorientCommand;
import omtg.diagram.edit.commands.ShapeCreateCommand;
import omtg.diagram.edit.commands.ShapeReorientCommand;
import omtg.diagram.edit.commands.SimpleCreateCommand;
import omtg.diagram.edit.commands.SimpleReorientCommand;
import omtg.diagram.edit.commands.SpatialAgregationCreateCommand;
import omtg.diagram.edit.commands.SpatialAgregationReorientCommand;
import omtg.diagram.edit.commands.SpatialCreateCommand;
import omtg.diagram.edit.commands.SpatialReorientCommand;
import omtg.diagram.edit.parts.AgregationEditPart;
import omtg.diagram.edit.parts.AttributeEditPart;
import omtg.diagram.edit.parts.DisjointPartialEditPart;
import omtg.diagram.edit.parts.DisjointTotalEditPart;
import omtg.diagram.edit.parts.MethodEditPart;
import omtg.diagram.edit.parts.NetworkAssociationEditPart;
import omtg.diagram.edit.parts.OverlappingPartialEditPart;
import omtg.diagram.edit.parts.OverlappingTotalEditPart;
import omtg.diagram.edit.parts.PolygonBaseClassCompartmentGraphical2EditPart;
import omtg.diagram.edit.parts.PolygonBaseClassCompartmentGraphicalEditPart;
import omtg.diagram.edit.parts.ScaleEditPart;
import omtg.diagram.edit.parts.ShapeEditPart;
import omtg.diagram.edit.parts.SimpleEditPart;
import omtg.diagram.edit.parts.SpatialAgregationEditPart;
import omtg.diagram.edit.parts.SpatialEditPart;
import omtg.diagram.part.OmtgVisualIDRegistry;
import omtg.diagram.providers.OmtgElementTypes;

import org.eclipse.emf.ecore.EAnnotation;
import org.eclipse.gef.commands.Command;
import org.eclipse.gmf.runtime.common.core.command.ICompositeCommand;
import org.eclipse.gmf.runtime.diagram.core.commands.DeleteCommand;
import org.eclipse.gmf.runtime.emf.commands.core.command.CompositeTransactionalCommand;
import org.eclipse.gmf.runtime.emf.type.core.commands.DestroyElementCommand;
import org.eclipse.gmf.runtime.emf.type.core.requests.CreateRelationshipRequest;
import org.eclipse.gmf.runtime.emf.type.core.requests.DestroyElementRequest;
import org.eclipse.gmf.runtime.emf.type.core.requests.ReorientRelationshipRequest;
import org.eclipse.gmf.runtime.notation.Edge;
import org.eclipse.gmf.runtime.notation.Node;
import org.eclipse.gmf.runtime.notation.View;

/**
 * @generated
 */
public class PolygonItemSemanticEditPolicy extends
		OmtgBaseItemSemanticEditPolicy {

	/**
	 * @generated
	 */
	public PolygonItemSemanticEditPolicy() {
		super(OmtgElementTypes.Polygon_2013);
	}

	/**
	 * @generated
	 */
	protected Command getDestroyElementCommand(DestroyElementRequest req) {
		View view = (View) getHost().getModel();
		CompositeTransactionalCommand cmd = new CompositeTransactionalCommand(
				getEditingDomain(), null);
		cmd.setTransactionNestingEnabled(false);
		for (Iterator<?> it = view.getTargetEdges().iterator(); it.hasNext();) {
			Edge incomingLink = (Edge) it.next();
			if (OmtgVisualIDRegistry.getVisualID(incomingLink) == SpatialAgregationEditPart.VISUAL_ID) {
				DestroyElementRequest r = new DestroyElementRequest(
						incomingLink.getElement(), false);
				cmd.add(new DestroyElementCommand(r));
				cmd.add(new DeleteCommand(getEditingDomain(), incomingLink));
				continue;
			}
			if (OmtgVisualIDRegistry.getVisualID(incomingLink) == OverlappingTotalEditPart.VISUAL_ID) {
				DestroyElementRequest r = new DestroyElementRequest(
						incomingLink.getElement(), false);
				cmd.add(new DestroyElementCommand(r));
				cmd.add(new DeleteCommand(getEditingDomain(), incomingLink));
				continue;
			}
			if (OmtgVisualIDRegistry.getVisualID(incomingLink) == DisjointPartialEditPart.VISUAL_ID) {
				DestroyElementRequest r = new DestroyElementRequest(
						incomingLink.getElement(), false);
				cmd.add(new DestroyElementCommand(r));
				cmd.add(new DeleteCommand(getEditingDomain(), incomingLink));
				continue;
			}
			if (OmtgVisualIDRegistry.getVisualID(incomingLink) == SimpleEditPart.VISUAL_ID) {
				DestroyElementRequest r = new DestroyElementRequest(
						incomingLink.getElement(), false);
				cmd.add(new DestroyElementCommand(r));
				cmd.add(new DeleteCommand(getEditingDomain(), incomingLink));
				continue;
			}
			if (OmtgVisualIDRegistry.getVisualID(incomingLink) == ScaleEditPart.VISUAL_ID) {
				DestroyElementRequest r = new DestroyElementRequest(
						incomingLink.getElement(), false);
				cmd.add(new DestroyElementCommand(r));
				cmd.add(new DeleteCommand(getEditingDomain(), incomingLink));
				continue;
			}
			if (OmtgVisualIDRegistry.getVisualID(incomingLink) == ShapeEditPart.VISUAL_ID) {
				DestroyElementRequest r = new DestroyElementRequest(
						incomingLink.getElement(), false);
				cmd.add(new DestroyElementCommand(r));
				cmd.add(new DeleteCommand(getEditingDomain(), incomingLink));
				continue;
			}
			if (OmtgVisualIDRegistry.getVisualID(incomingLink) == AgregationEditPart.VISUAL_ID) {
				DestroyElementRequest r = new DestroyElementRequest(
						incomingLink.getElement(), false);
				cmd.add(new DestroyElementCommand(r));
				cmd.add(new DeleteCommand(getEditingDomain(), incomingLink));
				continue;
			}
			if (OmtgVisualIDRegistry.getVisualID(incomingLink) == SpatialEditPart.VISUAL_ID) {
				DestroyElementRequest r = new DestroyElementRequest(
						incomingLink.getElement(), false);
				cmd.add(new DestroyElementCommand(r));
				cmd.add(new DeleteCommand(getEditingDomain(), incomingLink));
				continue;
			}
			if (OmtgVisualIDRegistry.getVisualID(incomingLink) == NetworkAssociationEditPart.VISUAL_ID) {
				DestroyElementRequest r = new DestroyElementRequest(
						incomingLink.getElement(), false);
				cmd.add(new DestroyElementCommand(r));
				cmd.add(new DeleteCommand(getEditingDomain(), incomingLink));
				continue;
			}
			if (OmtgVisualIDRegistry.getVisualID(incomingLink) == DisjointTotalEditPart.VISUAL_ID) {
				DestroyElementRequest r = new DestroyElementRequest(
						incomingLink.getElement(), false);
				cmd.add(new DestroyElementCommand(r));
				cmd.add(new DeleteCommand(getEditingDomain(), incomingLink));
				continue;
			}
			if (OmtgVisualIDRegistry.getVisualID(incomingLink) == OverlappingPartialEditPart.VISUAL_ID) {
				DestroyElementRequest r = new DestroyElementRequest(
						incomingLink.getElement(), false);
				cmd.add(new DestroyElementCommand(r));
				cmd.add(new DeleteCommand(getEditingDomain(), incomingLink));
				continue;
			}
		}
		for (Iterator<?> it = view.getSourceEdges().iterator(); it.hasNext();) {
			Edge outgoingLink = (Edge) it.next();
			if (OmtgVisualIDRegistry.getVisualID(outgoingLink) == SpatialAgregationEditPart.VISUAL_ID) {
				DestroyElementRequest r = new DestroyElementRequest(
						outgoingLink.getElement(), false);
				cmd.add(new DestroyElementCommand(r));
				cmd.add(new DeleteCommand(getEditingDomain(), outgoingLink));
				continue;
			}
			if (OmtgVisualIDRegistry.getVisualID(outgoingLink) == OverlappingTotalEditPart.VISUAL_ID) {
				DestroyElementRequest r = new DestroyElementRequest(
						outgoingLink.getElement(), false);
				cmd.add(new DestroyElementCommand(r));
				cmd.add(new DeleteCommand(getEditingDomain(), outgoingLink));
				continue;
			}
			if (OmtgVisualIDRegistry.getVisualID(outgoingLink) == DisjointPartialEditPart.VISUAL_ID) {
				DestroyElementRequest r = new DestroyElementRequest(
						outgoingLink.getElement(), false);
				cmd.add(new DestroyElementCommand(r));
				cmd.add(new DeleteCommand(getEditingDomain(), outgoingLink));
				continue;
			}
			if (OmtgVisualIDRegistry.getVisualID(outgoingLink) == SimpleEditPart.VISUAL_ID) {
				DestroyElementRequest r = new DestroyElementRequest(
						outgoingLink.getElement(), false);
				cmd.add(new DestroyElementCommand(r));
				cmd.add(new DeleteCommand(getEditingDomain(), outgoingLink));
				continue;
			}
			if (OmtgVisualIDRegistry.getVisualID(outgoingLink) == ScaleEditPart.VISUAL_ID) {
				DestroyElementRequest r = new DestroyElementRequest(
						outgoingLink.getElement(), false);
				cmd.add(new DestroyElementCommand(r));
				cmd.add(new DeleteCommand(getEditingDomain(), outgoingLink));
				continue;
			}
			if (OmtgVisualIDRegistry.getVisualID(outgoingLink) == ShapeEditPart.VISUAL_ID) {
				DestroyElementRequest r = new DestroyElementRequest(
						outgoingLink.getElement(), false);
				cmd.add(new DestroyElementCommand(r));
				cmd.add(new DeleteCommand(getEditingDomain(), outgoingLink));
				continue;
			}
			if (OmtgVisualIDRegistry.getVisualID(outgoingLink) == AgregationEditPart.VISUAL_ID) {
				DestroyElementRequest r = new DestroyElementRequest(
						outgoingLink.getElement(), false);
				cmd.add(new DestroyElementCommand(r));
				cmd.add(new DeleteCommand(getEditingDomain(), outgoingLink));
				continue;
			}
			if (OmtgVisualIDRegistry.getVisualID(outgoingLink) == SpatialEditPart.VISUAL_ID) {
				DestroyElementRequest r = new DestroyElementRequest(
						outgoingLink.getElement(), false);
				cmd.add(new DestroyElementCommand(r));
				cmd.add(new DeleteCommand(getEditingDomain(), outgoingLink));
				continue;
			}
			if (OmtgVisualIDRegistry.getVisualID(outgoingLink) == NetworkAssociationEditPart.VISUAL_ID) {
				DestroyElementRequest r = new DestroyElementRequest(
						outgoingLink.getElement(), false);
				cmd.add(new DestroyElementCommand(r));
				cmd.add(new DeleteCommand(getEditingDomain(), outgoingLink));
				continue;
			}
			if (OmtgVisualIDRegistry.getVisualID(outgoingLink) == DisjointTotalEditPart.VISUAL_ID) {
				DestroyElementRequest r = new DestroyElementRequest(
						outgoingLink.getElement(), false);
				cmd.add(new DestroyElementCommand(r));
				cmd.add(new DeleteCommand(getEditingDomain(), outgoingLink));
				continue;
			}
			if (OmtgVisualIDRegistry.getVisualID(outgoingLink) == OverlappingPartialEditPart.VISUAL_ID) {
				DestroyElementRequest r = new DestroyElementRequest(
						outgoingLink.getElement(), false);
				cmd.add(new DestroyElementCommand(r));
				cmd.add(new DeleteCommand(getEditingDomain(), outgoingLink));
				continue;
			}
		}
		EAnnotation annotation = view.getEAnnotation("Shortcut"); //$NON-NLS-1$
		if (annotation == null) {
			// there are indirectly referenced children, need extra commands: false
			addDestroyChildNodesCommand(cmd);
			addDestroyShortcutsCommand(cmd, view);
			// delete host element
			cmd.add(new DestroyElementCommand(req));
		} else {
			cmd.add(new DeleteCommand(getEditingDomain(), view));
		}
		return getGEFWrapper(cmd.reduce());
	}

	/**
	 * @generated
	 */
	private void addDestroyChildNodesCommand(ICompositeCommand cmd) {
		View view = (View) getHost().getModel();
		for (Iterator<?> nit = view.getChildren().iterator(); nit.hasNext();) {
			Node node = (Node) nit.next();
			switch (OmtgVisualIDRegistry.getVisualID(node)) {
			case PolygonBaseClassCompartmentGraphicalEditPart.VISUAL_ID:
				for (Iterator<?> cit = node.getChildren().iterator(); cit
						.hasNext();) {
					Node cnode = (Node) cit.next();
					switch (OmtgVisualIDRegistry.getVisualID(cnode)) {
					case AttributeEditPart.VISUAL_ID:
						cmd.add(new DestroyElementCommand(
								new DestroyElementRequest(getEditingDomain(),
										cnode.getElement(), false))); // directlyOwned: true
						// don't need explicit deletion of cnode as parent's view deletion would clean child views as well 
						// cmd.add(new org.eclipse.gmf.runtime.diagram.core.commands.DeleteCommand(getEditingDomain(), cnode));
						break;
					}
				}
				break;
			case PolygonBaseClassCompartmentGraphical2EditPart.VISUAL_ID:
				for (Iterator<?> cit = node.getChildren().iterator(); cit
						.hasNext();) {
					Node cnode = (Node) cit.next();
					switch (OmtgVisualIDRegistry.getVisualID(cnode)) {
					case MethodEditPart.VISUAL_ID:
						cmd.add(new DestroyElementCommand(
								new DestroyElementRequest(getEditingDomain(),
										cnode.getElement(), false))); // directlyOwned: true
						// don't need explicit deletion of cnode as parent's view deletion would clean child views as well 
						// cmd.add(new org.eclipse.gmf.runtime.diagram.core.commands.DeleteCommand(getEditingDomain(), cnode));
						break;
					}
				}
				break;
			}
		}
	}

	/**
	 * @generated
	 */
	protected Command getCreateRelationshipCommand(CreateRelationshipRequest req) {
		Command command = req.getTarget() == null ? getStartCreateRelationshipCommand(req)
				: getCompleteCreateRelationshipCommand(req);
		return command != null ? command : super
				.getCreateRelationshipCommand(req);
	}

	/**
	 * @generated
	 */
	protected Command getStartCreateRelationshipCommand(
			CreateRelationshipRequest req) {
		if (OmtgElementTypes.SpatialAgregation_4001 == req.getElementType()) {
			return getGEFWrapper(new SpatialAgregationCreateCommand(req,
					req.getSource(), req.getTarget()));
		}
		if (OmtgElementTypes.OverlappingTotal_4002 == req.getElementType()) {
			return getGEFWrapper(new OverlappingTotalCreateCommand(req,
					req.getSource(), req.getTarget()));
		}
		if (OmtgElementTypes.DisjointPartial_4003 == req.getElementType()) {
			return getGEFWrapper(new DisjointPartialCreateCommand(req,
					req.getSource(), req.getTarget()));
		}
		if (OmtgElementTypes.Simple_4004 == req.getElementType()) {
			return getGEFWrapper(new SimpleCreateCommand(req, req.getSource(),
					req.getTarget()));
		}
		if (OmtgElementTypes.Scale_4005 == req.getElementType()) {
			return getGEFWrapper(new ScaleCreateCommand(req, req.getSource(),
					req.getTarget()));
		}
		if (OmtgElementTypes.Shape_4006 == req.getElementType()) {
			return getGEFWrapper(new ShapeCreateCommand(req, req.getSource(),
					req.getTarget()));
		}
		if (OmtgElementTypes.Agregation_4007 == req.getElementType()) {
			return getGEFWrapper(new AgregationCreateCommand(req,
					req.getSource(), req.getTarget()));
		}
		if (OmtgElementTypes.Spatial_4008 == req.getElementType()) {
			return getGEFWrapper(new SpatialCreateCommand(req, req.getSource(),
					req.getTarget()));
		}
		if (OmtgElementTypes.NetworkAssociation_4009 == req.getElementType()) {
			return getGEFWrapper(new NetworkAssociationCreateCommand(req,
					req.getSource(), req.getTarget()));
		}
		if (OmtgElementTypes.DisjointTotal_4010 == req.getElementType()) {
			return getGEFWrapper(new DisjointTotalCreateCommand(req,
					req.getSource(), req.getTarget()));
		}
		if (OmtgElementTypes.OverlappingPartial_4011 == req.getElementType()) {
			return getGEFWrapper(new OverlappingPartialCreateCommand(req,
					req.getSource(), req.getTarget()));
		}
		return null;
	}

	/**
	 * @generated
	 */
	protected Command getCompleteCreateRelationshipCommand(
			CreateRelationshipRequest req) {
		if (OmtgElementTypes.SpatialAgregation_4001 == req.getElementType()) {
			return getGEFWrapper(new SpatialAgregationCreateCommand(req,
					req.getSource(), req.getTarget()));
		}
		if (OmtgElementTypes.OverlappingTotal_4002 == req.getElementType()) {
			return getGEFWrapper(new OverlappingTotalCreateCommand(req,
					req.getSource(), req.getTarget()));
		}
		if (OmtgElementTypes.DisjointPartial_4003 == req.getElementType()) {
			return getGEFWrapper(new DisjointPartialCreateCommand(req,
					req.getSource(), req.getTarget()));
		}
		if (OmtgElementTypes.Simple_4004 == req.getElementType()) {
			return getGEFWrapper(new SimpleCreateCommand(req, req.getSource(),
					req.getTarget()));
		}
		if (OmtgElementTypes.Scale_4005 == req.getElementType()) {
			return getGEFWrapper(new ScaleCreateCommand(req, req.getSource(),
					req.getTarget()));
		}
		if (OmtgElementTypes.Shape_4006 == req.getElementType()) {
			return getGEFWrapper(new ShapeCreateCommand(req, req.getSource(),
					req.getTarget()));
		}
		if (OmtgElementTypes.Agregation_4007 == req.getElementType()) {
			return getGEFWrapper(new AgregationCreateCommand(req,
					req.getSource(), req.getTarget()));
		}
		if (OmtgElementTypes.Spatial_4008 == req.getElementType()) {
			return getGEFWrapper(new SpatialCreateCommand(req, req.getSource(),
					req.getTarget()));
		}
		if (OmtgElementTypes.NetworkAssociation_4009 == req.getElementType()) {
			return getGEFWrapper(new NetworkAssociationCreateCommand(req,
					req.getSource(), req.getTarget()));
		}
		if (OmtgElementTypes.DisjointTotal_4010 == req.getElementType()) {
			return getGEFWrapper(new DisjointTotalCreateCommand(req,
					req.getSource(), req.getTarget()));
		}
		if (OmtgElementTypes.OverlappingPartial_4011 == req.getElementType()) {
			return getGEFWrapper(new OverlappingPartialCreateCommand(req,
					req.getSource(), req.getTarget()));
		}
		return null;
	}

	/**
	 * Returns command to reorient EClass based link. New link target or source
	 * should be the domain model element associated with this node.
	 * 
	 * @generated
	 */
	protected Command getReorientRelationshipCommand(
			ReorientRelationshipRequest req) {
		switch (getVisualID(req)) {
		case SpatialAgregationEditPart.VISUAL_ID:
			return getGEFWrapper(new SpatialAgregationReorientCommand(req));
		case OverlappingTotalEditPart.VISUAL_ID:
			return getGEFWrapper(new OverlappingTotalReorientCommand(req));
		case DisjointPartialEditPart.VISUAL_ID:
			return getGEFWrapper(new DisjointPartialReorientCommand(req));
		case SimpleEditPart.VISUAL_ID:
			return getGEFWrapper(new SimpleReorientCommand(req));
		case ScaleEditPart.VISUAL_ID:
			return getGEFWrapper(new ScaleReorientCommand(req));
		case ShapeEditPart.VISUAL_ID:
			return getGEFWrapper(new ShapeReorientCommand(req));
		case AgregationEditPart.VISUAL_ID:
			return getGEFWrapper(new AgregationReorientCommand(req));
		case SpatialEditPart.VISUAL_ID:
			return getGEFWrapper(new SpatialReorientCommand(req));
		case NetworkAssociationEditPart.VISUAL_ID:
			return getGEFWrapper(new NetworkAssociationReorientCommand(req));
		case DisjointTotalEditPart.VISUAL_ID:
			return getGEFWrapper(new DisjointTotalReorientCommand(req));
		case OverlappingPartialEditPart.VISUAL_ID:
			return getGEFWrapper(new OverlappingPartialReorientCommand(req));
		}
		return super.getReorientRelationshipCommand(req);
	}

}
