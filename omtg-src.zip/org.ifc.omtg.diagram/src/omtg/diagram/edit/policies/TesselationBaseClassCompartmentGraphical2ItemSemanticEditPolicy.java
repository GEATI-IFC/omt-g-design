package omtg.diagram.edit.policies;

import omtg.diagram.edit.commands.Method10CreateCommand;
import omtg.diagram.providers.OmtgElementTypes;

import org.eclipse.gef.commands.Command;
import org.eclipse.gmf.runtime.emf.type.core.requests.CreateElementRequest;

/**
 * @generated
 */
public class TesselationBaseClassCompartmentGraphical2ItemSemanticEditPolicy
		extends OmtgBaseItemSemanticEditPolicy {

	/**
	 * @generated
	 */
	public TesselationBaseClassCompartmentGraphical2ItemSemanticEditPolicy() {
		super(OmtgElementTypes.Tesselation_2022);
	}

	/**
	 * @generated
	 */
	protected Command getCreateCommand(CreateElementRequest req) {
		if (OmtgElementTypes.Method_3021 == req.getElementType()) {
			return getGEFWrapper(new Method10CreateCommand(req));
		}
		return super.getCreateCommand(req);
	}

}
