package omtg.diagram.edit.policies;

import omtg.diagram.edit.commands.Attribute10CreateCommand;
import omtg.diagram.providers.OmtgElementTypes;

import org.eclipse.gef.commands.Command;
import org.eclipse.gmf.runtime.emf.type.core.requests.CreateElementRequest;

/**
 * @generated
 */
public class TesselationBaseClassCompartmentGraphicalItemSemanticEditPolicy
		extends OmtgBaseItemSemanticEditPolicy {

	/**
	 * @generated
	 */
	public TesselationBaseClassCompartmentGraphicalItemSemanticEditPolicy() {
		super(OmtgElementTypes.Tesselation_2022);
	}

	/**
	 * @generated
	 */
	protected Command getCreateCommand(CreateElementRequest req) {
		if (OmtgElementTypes.Attribute_3010 == req.getElementType()) {
			return getGEFWrapper(new Attribute10CreateCommand(req));
		}
		return super.getCreateCommand(req);
	}

}
