package omtg.diagram.edit.policies;

import omtg.diagram.edit.commands.Method7CreateCommand;
import omtg.diagram.providers.OmtgElementTypes;

import org.eclipse.gef.commands.Command;
import org.eclipse.gmf.runtime.emf.type.core.requests.CreateElementRequest;

/**
 * @generated
 */
public class NodeBaseClassCompartmentGraphical2ItemSemanticEditPolicy extends
		OmtgBaseItemSemanticEditPolicy {

	/**
	 * @generated
	 */
	public NodeBaseClassCompartmentGraphical2ItemSemanticEditPolicy() {
		super(OmtgElementTypes.Node_2019);
	}

	/**
	 * @generated
	 */
	protected Command getCreateCommand(CreateElementRequest req) {
		if (OmtgElementTypes.Method_3018 == req.getElementType()) {
			return getGEFWrapper(new Method7CreateCommand(req));
		}
		return super.getCreateCommand(req);
	}

}
