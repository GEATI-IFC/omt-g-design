package omtg.diagram.edit.policies;

import omtg.diagram.edit.commands.MethodCreateCommand;
import omtg.diagram.providers.OmtgElementTypes;

import org.eclipse.gef.commands.Command;
import org.eclipse.gmf.runtime.emf.type.core.requests.CreateElementRequest;

/**
 * @generated
 */
public class PolygonBaseClassCompartmentGraphical2ItemSemanticEditPolicy extends
		OmtgBaseItemSemanticEditPolicy {

	/**
	 * @generated
	 */
	public PolygonBaseClassCompartmentGraphical2ItemSemanticEditPolicy() {
		super(OmtgElementTypes.Polygon_2013);
	}

	/**
	 * @generated
	 */
	protected Command getCreateCommand(CreateElementRequest req) {
		if (OmtgElementTypes.Method_3012 == req.getElementType()) {
			return getGEFWrapper(new MethodCreateCommand(req));
		}
		return super.getCreateCommand(req);
	}

}
