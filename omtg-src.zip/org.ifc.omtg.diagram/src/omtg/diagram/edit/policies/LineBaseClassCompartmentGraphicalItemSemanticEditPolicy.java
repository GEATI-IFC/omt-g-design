package omtg.diagram.edit.policies;

import omtg.diagram.edit.commands.Attribute3CreateCommand;
import omtg.diagram.providers.OmtgElementTypes;

import org.eclipse.gef.commands.Command;
import org.eclipse.gmf.runtime.emf.type.core.requests.CreateElementRequest;

/**
 * @generated
 */
public class LineBaseClassCompartmentGraphicalItemSemanticEditPolicy extends
		OmtgBaseItemSemanticEditPolicy {

	/**
	 * @generated
	 */
	public LineBaseClassCompartmentGraphicalItemSemanticEditPolicy() {
		super(OmtgElementTypes.Line_2015);
	}

	/**
	 * @generated
	 */
	protected Command getCreateCommand(CreateElementRequest req) {
		if (OmtgElementTypes.Attribute_3003 == req.getElementType()) {
			return getGEFWrapper(new Attribute3CreateCommand(req));
		}
		return super.getCreateCommand(req);
	}

}
