package omtg.diagram.edit.policies;

import omtg.diagram.edit.commands.Method6CreateCommand;
import omtg.diagram.providers.OmtgElementTypes;

import org.eclipse.gef.commands.Command;
import org.eclipse.gmf.runtime.emf.type.core.requests.CreateElementRequest;

/**
 * @generated
 */
public class IsolineBaseClassCompartmentGraphical2ItemSemanticEditPolicy extends
		OmtgBaseItemSemanticEditPolicy {

	/**
	 * @generated
	 */
	public IsolineBaseClassCompartmentGraphical2ItemSemanticEditPolicy() {
		super(OmtgElementTypes.Isoline_2018);
	}

	/**
	 * @generated
	 */
	protected Command getCreateCommand(CreateElementRequest req) {
		if (OmtgElementTypes.Method_3017 == req.getElementType()) {
			return getGEFWrapper(new Method6CreateCommand(req));
		}
		return super.getCreateCommand(req);
	}

}
