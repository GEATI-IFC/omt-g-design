package omtg.diagram.edit.policies;

import omtg.diagram.edit.commands.Method2CreateCommand;
import omtg.diagram.providers.OmtgElementTypes;

import org.eclipse.gef.commands.Command;
import org.eclipse.gmf.runtime.emf.type.core.requests.CreateElementRequest;

/**
 * @generated
 */
public class PointBaseClassCompartmentGraphical2ItemSemanticEditPolicy extends
		OmtgBaseItemSemanticEditPolicy {

	/**
	 * @generated
	 */
	public PointBaseClassCompartmentGraphical2ItemSemanticEditPolicy() {
		super(OmtgElementTypes.Point_2014);
	}

	/**
	 * @generated
	 */
	protected Command getCreateCommand(CreateElementRequest req) {
		if (OmtgElementTypes.Method_3013 == req.getElementType()) {
			return getGEFWrapper(new Method2CreateCommand(req));
		}
		return super.getCreateCommand(req);
	}

}
