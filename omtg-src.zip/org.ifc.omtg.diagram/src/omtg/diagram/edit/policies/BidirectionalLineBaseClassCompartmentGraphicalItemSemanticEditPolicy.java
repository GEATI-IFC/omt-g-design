package omtg.diagram.edit.policies;

import omtg.diagram.edit.commands.Attribute9CreateCommand;
import omtg.diagram.providers.OmtgElementTypes;

import org.eclipse.gef.commands.Command;
import org.eclipse.gmf.runtime.emf.type.core.requests.CreateElementRequest;

/**
 * @generated
 */
public class BidirectionalLineBaseClassCompartmentGraphicalItemSemanticEditPolicy
		extends OmtgBaseItemSemanticEditPolicy {

	/**
	 * @generated
	 */
	public BidirectionalLineBaseClassCompartmentGraphicalItemSemanticEditPolicy() {
		super(OmtgElementTypes.BidirectionalLine_2021);
	}

	/**
	 * @generated
	 */
	protected Command getCreateCommand(CreateElementRequest req) {
		if (OmtgElementTypes.Attribute_3009 == req.getElementType()) {
			return getGEFWrapper(new Attribute9CreateCommand(req));
		}
		return super.getCreateCommand(req);
	}

}
