package omtg.diagram.edit.policies;

import omtg.diagram.edit.commands.Attribute11CreateCommand;
import omtg.diagram.providers.OmtgElementTypes;

import org.eclipse.gef.commands.Command;
import org.eclipse.gmf.runtime.emf.type.core.requests.CreateElementRequest;

/**
 * @generated
 */
public class UnidirectionalLineBaseClassCompartmentGraphicalItemSemanticEditPolicy
		extends OmtgBaseItemSemanticEditPolicy {

	/**
	 * @generated
	 */
	public UnidirectionalLineBaseClassCompartmentGraphicalItemSemanticEditPolicy() {
		super(OmtgElementTypes.UnidirectionalLine_2023);
	}

	/**
	 * @generated
	 */
	protected Command getCreateCommand(CreateElementRequest req) {
		if (OmtgElementTypes.Attribute_3011 == req.getElementType()) {
			return getGEFWrapper(new Attribute11CreateCommand(req));
		}
		return super.getCreateCommand(req);
	}

}
