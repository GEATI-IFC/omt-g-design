package omtg.diagram.edit.policies;

import omtg.diagram.edit.commands.Attribute12CreateCommand;
import omtg.diagram.providers.OmtgElementTypes;

import org.eclipse.gef.commands.Command;
import org.eclipse.gmf.runtime.emf.type.core.requests.CreateElementRequest;

/**
 * @generated
 */
public class ConventionalBaseClassCompartmentGraphicalItemSemanticEditPolicy
		extends OmtgBaseItemSemanticEditPolicy {

	/**
	 * @generated
	 */
	public ConventionalBaseClassCompartmentGraphicalItemSemanticEditPolicy() {
		super(OmtgElementTypes.Conventional_2024);
	}

	/**
	 * @generated
	 */
	protected Command getCreateCommand(CreateElementRequest req) {
		if (OmtgElementTypes.Attribute_3022 == req.getElementType()) {
			return getGEFWrapper(new Attribute12CreateCommand(req));
		}
		return super.getCreateCommand(req);
	}

}
