package omtg.diagram.edit.policies;

import omtg.diagram.edit.commands.Method11CreateCommand;
import omtg.diagram.providers.OmtgElementTypes;

import org.eclipse.gef.commands.Command;
import org.eclipse.gmf.runtime.emf.type.core.requests.CreateElementRequest;

/**
 * @generated
 */
public class UnidirectionalLineBaseClassCompartmentGraphical2ItemSemanticEditPolicy
		extends OmtgBaseItemSemanticEditPolicy {

	/**
	 * @generated
	 */
	public UnidirectionalLineBaseClassCompartmentGraphical2ItemSemanticEditPolicy() {
		super(OmtgElementTypes.UnidirectionalLine_2023);
	}

	/**
	 * @generated
	 */
	protected Command getCreateCommand(CreateElementRequest req) {
		if (OmtgElementTypes.Method_3023 == req.getElementType()) {
			return getGEFWrapper(new Method11CreateCommand(req));
		}
		return super.getCreateCommand(req);
	}

}
