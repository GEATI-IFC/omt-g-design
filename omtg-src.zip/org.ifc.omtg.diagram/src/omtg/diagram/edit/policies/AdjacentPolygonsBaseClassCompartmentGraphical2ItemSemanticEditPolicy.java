package omtg.diagram.edit.policies;

import omtg.diagram.edit.commands.Method8CreateCommand;
import omtg.diagram.providers.OmtgElementTypes;

import org.eclipse.gef.commands.Command;
import org.eclipse.gmf.runtime.emf.type.core.requests.CreateElementRequest;

/**
 * @generated
 */
public class AdjacentPolygonsBaseClassCompartmentGraphical2ItemSemanticEditPolicy
		extends OmtgBaseItemSemanticEditPolicy {

	/**
	 * @generated
	 */
	public AdjacentPolygonsBaseClassCompartmentGraphical2ItemSemanticEditPolicy() {
		super(OmtgElementTypes.AdjacentPolygons_2020);
	}

	/**
	 * @generated
	 */
	protected Command getCreateCommand(CreateElementRequest req) {
		if (OmtgElementTypes.Method_3019 == req.getElementType()) {
			return getGEFWrapper(new Method8CreateCommand(req));
		}
		return super.getCreateCommand(req);
	}

}
