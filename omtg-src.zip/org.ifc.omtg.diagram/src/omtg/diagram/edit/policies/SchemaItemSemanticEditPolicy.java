package omtg.diagram.edit.policies;

import omtg.diagram.edit.commands.AdjacentPolygonsCreateCommand;
import omtg.diagram.edit.commands.BidirectionalLineCreateCommand;
import omtg.diagram.edit.commands.ConventionalCreateCommand;
import omtg.diagram.edit.commands.IsolineCreateCommand;
import omtg.diagram.edit.commands.LineCreateCommand;
import omtg.diagram.edit.commands.NetworkClassCreateCommand;
import omtg.diagram.edit.commands.NodeCreateCommand;
import omtg.diagram.edit.commands.PointCreateCommand;
import omtg.diagram.edit.commands.PolygonCreateCommand;
import omtg.diagram.edit.commands.SamplingCreateCommand;
import omtg.diagram.edit.commands.TesselationCreateCommand;
import omtg.diagram.edit.commands.UnidirectionalLineCreateCommand;
import omtg.diagram.providers.OmtgElementTypes;

import org.eclipse.emf.transaction.TransactionalEditingDomain;
import org.eclipse.gef.commands.Command;
import org.eclipse.gmf.runtime.diagram.ui.editparts.IGraphicalEditPart;
import org.eclipse.gmf.runtime.emf.commands.core.commands.DuplicateEObjectsCommand;
import org.eclipse.gmf.runtime.emf.type.core.requests.CreateElementRequest;
import org.eclipse.gmf.runtime.emf.type.core.requests.DuplicateElementsRequest;

/**
 * @generated
 */
public class SchemaItemSemanticEditPolicy extends
		OmtgBaseItemSemanticEditPolicy {

	/**
	 * @generated
	 */
	public SchemaItemSemanticEditPolicy() {
		super(OmtgElementTypes.Schema_1000);
	}

	/**
	 * @generated
	 */
	protected Command getCreateCommand(CreateElementRequest req) {
		if (OmtgElementTypes.Polygon_2013 == req.getElementType()) {
			return getGEFWrapper(new PolygonCreateCommand(req));
		}
		if (OmtgElementTypes.Point_2014 == req.getElementType()) {
			return getGEFWrapper(new PointCreateCommand(req));
		}
		if (OmtgElementTypes.Line_2015 == req.getElementType()) {
			return getGEFWrapper(new LineCreateCommand(req));
		}
		if (OmtgElementTypes.NetworkClass_2016 == req.getElementType()) {
			return getGEFWrapper(new NetworkClassCreateCommand(req));
		}
		if (OmtgElementTypes.Sampling_2025 == req.getElementType()) {
			return getGEFWrapper(new SamplingCreateCommand(req));
		}
		if (OmtgElementTypes.Isoline_2018 == req.getElementType()) {
			return getGEFWrapper(new IsolineCreateCommand(req));
		}
		if (OmtgElementTypes.Node_2019 == req.getElementType()) {
			return getGEFWrapper(new NodeCreateCommand(req));
		}
		if (OmtgElementTypes.AdjacentPolygons_2020 == req.getElementType()) {
			return getGEFWrapper(new AdjacentPolygonsCreateCommand(req));
		}
		if (OmtgElementTypes.BidirectionalLine_2021 == req.getElementType()) {
			return getGEFWrapper(new BidirectionalLineCreateCommand(req));
		}
		if (OmtgElementTypes.Tesselation_2022 == req.getElementType()) {
			return getGEFWrapper(new TesselationCreateCommand(req));
		}
		if (OmtgElementTypes.UnidirectionalLine_2023 == req.getElementType()) {
			return getGEFWrapper(new UnidirectionalLineCreateCommand(req));
		}
		if (OmtgElementTypes.Conventional_2024 == req.getElementType()) {
			return getGEFWrapper(new ConventionalCreateCommand(req));
		}
		return super.getCreateCommand(req);
	}

	/**
	 * @generated
	 */
	protected Command getDuplicateCommand(DuplicateElementsRequest req) {
		TransactionalEditingDomain editingDomain = ((IGraphicalEditPart) getHost())
				.getEditingDomain();
		return getGEFWrapper(new DuplicateAnythingCommand(editingDomain, req));
	}

	/**
	 * @generated
	 */
	private static class DuplicateAnythingCommand extends
			DuplicateEObjectsCommand {

		/**
		 * @generated
		 */
		public DuplicateAnythingCommand(
				TransactionalEditingDomain editingDomain,
				DuplicateElementsRequest req) {
			super(editingDomain, req.getLabel(), req
					.getElementsToBeDuplicated(), req
					.getAllDuplicatedElementsMap());
		}

	}

}
