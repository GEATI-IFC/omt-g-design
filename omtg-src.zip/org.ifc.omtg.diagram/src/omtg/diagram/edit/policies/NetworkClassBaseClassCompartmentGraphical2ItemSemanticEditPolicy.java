package omtg.diagram.edit.policies;

import omtg.diagram.edit.commands.Method4CreateCommand;
import omtg.diagram.providers.OmtgElementTypes;

import org.eclipse.gef.commands.Command;
import org.eclipse.gmf.runtime.emf.type.core.requests.CreateElementRequest;

/**
 * @generated
 */
public class NetworkClassBaseClassCompartmentGraphical2ItemSemanticEditPolicy
		extends OmtgBaseItemSemanticEditPolicy {

	/**
	 * @generated
	 */
	public NetworkClassBaseClassCompartmentGraphical2ItemSemanticEditPolicy() {
		super(OmtgElementTypes.NetworkClass_2016);
	}

	/**
	 * @generated
	 */
	protected Command getCreateCommand(CreateElementRequest req) {
		if (OmtgElementTypes.Method_3015 == req.getElementType()) {
			return getGEFWrapper(new Method4CreateCommand(req));
		}
		return super.getCreateCommand(req);
	}

}
