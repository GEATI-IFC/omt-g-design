package omtg.diagram.edit.policies;

import omtg.diagram.edit.commands.Attribute8CreateCommand;
import omtg.diagram.providers.OmtgElementTypes;

import org.eclipse.gef.commands.Command;
import org.eclipse.gmf.runtime.emf.type.core.requests.CreateElementRequest;

/**
 * @generated
 */
public class AdjacentPolygonsBaseClassCompartmentGraphicalItemSemanticEditPolicy
		extends OmtgBaseItemSemanticEditPolicy {

	/**
	 * @generated
	 */
	public AdjacentPolygonsBaseClassCompartmentGraphicalItemSemanticEditPolicy() {
		super(OmtgElementTypes.AdjacentPolygons_2020);
	}

	/**
	 * @generated
	 */
	protected Command getCreateCommand(CreateElementRequest req) {
		if (OmtgElementTypes.Attribute_3008 == req.getElementType()) {
			return getGEFWrapper(new Attribute8CreateCommand(req));
		}
		return super.getCreateCommand(req);
	}

}
