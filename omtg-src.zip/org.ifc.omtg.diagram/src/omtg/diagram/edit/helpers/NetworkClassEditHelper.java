package omtg.diagram.edit.helpers;

/**
 * @generated
 */
public class NetworkClassEditHelper extends OmtgBaseEditHelper {
}
