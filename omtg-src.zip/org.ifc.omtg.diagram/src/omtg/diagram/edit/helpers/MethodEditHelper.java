package omtg.diagram.edit.helpers;

/**
 * @generated
 */
public class MethodEditHelper extends OmtgBaseEditHelper {
}
