package omtg.diagram.edit.helpers;

/**
 * @generated
 */
public class OverlappingTotalEditHelper extends OmtgBaseEditHelper {
}
