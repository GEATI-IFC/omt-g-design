package omtg.diagram.edit.helpers;

/**
 * @generated
 */
public class ConventionalEditHelper extends OmtgBaseEditHelper {
}
