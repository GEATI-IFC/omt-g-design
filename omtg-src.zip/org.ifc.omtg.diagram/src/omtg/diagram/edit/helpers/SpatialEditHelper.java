package omtg.diagram.edit.helpers;

/**
 * @generated
 */
public class SpatialEditHelper extends OmtgBaseEditHelper {
}
