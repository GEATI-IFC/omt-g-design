package omtg.diagram.edit.helpers;

/**
 * @generated
 */
public class ShapeEditHelper extends OmtgBaseEditHelper {
}
