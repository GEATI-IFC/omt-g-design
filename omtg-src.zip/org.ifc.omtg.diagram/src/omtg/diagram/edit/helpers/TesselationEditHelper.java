package omtg.diagram.edit.helpers;

/**
 * @generated
 */
public class TesselationEditHelper extends OmtgBaseEditHelper {
}
