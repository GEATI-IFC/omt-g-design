package omtg.diagram.edit.helpers;

/**
 * @generated
 */
public class LineEditHelper extends OmtgBaseEditHelper {
}
