package omtg.diagram.edit.helpers;

/**
 * @generated
 */
public class SamplingEditHelper extends OmtgBaseEditHelper {
}
