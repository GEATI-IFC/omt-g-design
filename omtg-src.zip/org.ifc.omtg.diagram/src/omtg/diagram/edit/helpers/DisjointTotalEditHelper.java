package omtg.diagram.edit.helpers;

/**
 * @generated
 */
public class DisjointTotalEditHelper extends OmtgBaseEditHelper {
}
