package omtg.diagram.edit.helpers;

/**
 * @generated
 */
public class DisjointPartialEditHelper extends OmtgBaseEditHelper {
}
