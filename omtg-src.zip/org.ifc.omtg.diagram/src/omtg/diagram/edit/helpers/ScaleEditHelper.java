package omtg.diagram.edit.helpers;

/**
 * @generated
 */
public class ScaleEditHelper extends OmtgBaseEditHelper {
}
