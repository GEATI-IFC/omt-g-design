package omtg.diagram.edit.helpers;

/**
 * @generated
 */
public class AdjacentPolygonsEditHelper extends OmtgBaseEditHelper {
}
