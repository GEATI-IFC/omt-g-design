package omtg.diagram.edit.helpers;

/**
 * @generated
 */
public class AgregationEditHelper extends OmtgBaseEditHelper {
}
