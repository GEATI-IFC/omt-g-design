package omtg.diagram.edit.helpers;

/**
 * @generated
 */
public class BidirectionalLineEditHelper extends OmtgBaseEditHelper {
}
