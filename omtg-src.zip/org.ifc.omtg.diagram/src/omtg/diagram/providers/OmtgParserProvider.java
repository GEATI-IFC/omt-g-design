package omtg.diagram.providers;

import omtg.OmtgPackage;
import omtg.diagram.edit.parts.AdjacentPolygonsNameEditPart;
import omtg.diagram.edit.parts.AttributeNameType10EditPart;
import omtg.diagram.edit.parts.AttributeNameType11EditPart;
import omtg.diagram.edit.parts.AttributeNameType12EditPart;
import omtg.diagram.edit.parts.AttributeNameType2EditPart;
import omtg.diagram.edit.parts.AttributeNameType3EditPart;
import omtg.diagram.edit.parts.AttributeNameType4EditPart;
import omtg.diagram.edit.parts.AttributeNameType5EditPart;
import omtg.diagram.edit.parts.AttributeNameType6EditPart;
import omtg.diagram.edit.parts.AttributeNameType7EditPart;
import omtg.diagram.edit.parts.AttributeNameType8EditPart;
import omtg.diagram.edit.parts.AttributeNameType9EditPart;
import omtg.diagram.edit.parts.AttributeNameTypeEditPart;
import omtg.diagram.edit.parts.BidirectionalLineNameEditPart;
import omtg.diagram.edit.parts.ConventionalNameEditPart;
import omtg.diagram.edit.parts.IsolineNameEditPart;
import omtg.diagram.edit.parts.LineNameEditPart;
import omtg.diagram.edit.parts.MethodNameAttibutesReturn10EditPart;
import omtg.diagram.edit.parts.MethodNameAttibutesReturn11EditPart;
import omtg.diagram.edit.parts.MethodNameAttibutesReturn12EditPart;
import omtg.diagram.edit.parts.MethodNameAttibutesReturn2EditPart;
import omtg.diagram.edit.parts.MethodNameAttibutesReturn3EditPart;
import omtg.diagram.edit.parts.MethodNameAttibutesReturn4EditPart;
import omtg.diagram.edit.parts.MethodNameAttibutesReturn5EditPart;
import omtg.diagram.edit.parts.MethodNameAttibutesReturn6EditPart;
import omtg.diagram.edit.parts.MethodNameAttibutesReturn7EditPart;
import omtg.diagram.edit.parts.MethodNameAttibutesReturn8EditPart;
import omtg.diagram.edit.parts.MethodNameAttibutesReturn9EditPart;
import omtg.diagram.edit.parts.MethodNameAttibutesReturnEditPart;
import omtg.diagram.edit.parts.NetworkClassNameEditPart;
import omtg.diagram.edit.parts.NodeNameEditPart;
import omtg.diagram.edit.parts.PointNameEditPart;
import omtg.diagram.edit.parts.PolygonNameEditPart;
import omtg.diagram.edit.parts.SamplingNameEditPart;
import omtg.diagram.edit.parts.TesselationNameEditPart;
import omtg.diagram.edit.parts.UnidirectionalLineNameEditPart;
import omtg.diagram.parsers.MessageFormatParser;
import omtg.diagram.part.OmtgVisualIDRegistry;

import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.gmf.runtime.common.core.service.AbstractProvider;
import org.eclipse.gmf.runtime.common.core.service.IOperation;
import org.eclipse.gmf.runtime.common.ui.services.parser.GetParserOperation;
import org.eclipse.gmf.runtime.common.ui.services.parser.IParser;
import org.eclipse.gmf.runtime.common.ui.services.parser.IParserProvider;
import org.eclipse.gmf.runtime.common.ui.services.parser.ParserService;
import org.eclipse.gmf.runtime.emf.type.core.IElementType;
import org.eclipse.gmf.runtime.emf.ui.services.parser.ParserHintAdapter;
import org.eclipse.gmf.runtime.notation.View;

/**
 * @generated
 */
public class OmtgParserProvider extends AbstractProvider implements
		IParserProvider {

	/**
	 * @generated
	 */
	private IParser polygonName_5037Parser;

	/**
	 * @generated
	 */
	private IParser getPolygonName_5037Parser() {
		if (polygonName_5037Parser == null) {
			EAttribute[] features = new EAttribute[] { OmtgPackage.eINSTANCE
					.getelement_Name() };
			MessageFormatParser parser = new MessageFormatParser(features);
			polygonName_5037Parser = parser;
		}
		return polygonName_5037Parser;
	}

	/**
	 * @generated
	 */
	private IParser pointName_5038Parser;

	/**
	 * @generated
	 */
	private IParser getPointName_5038Parser() {
		if (pointName_5038Parser == null) {
			EAttribute[] features = new EAttribute[] { OmtgPackage.eINSTANCE
					.getelement_Name() };
			MessageFormatParser parser = new MessageFormatParser(features);
			pointName_5038Parser = parser;
		}
		return pointName_5038Parser;
	}

	/**
	 * @generated
	 */
	private IParser lineName_5039Parser;

	/**
	 * @generated
	 */
	private IParser getLineName_5039Parser() {
		if (lineName_5039Parser == null) {
			EAttribute[] features = new EAttribute[] { OmtgPackage.eINSTANCE
					.getelement_Name() };
			MessageFormatParser parser = new MessageFormatParser(features);
			lineName_5039Parser = parser;
		}
		return lineName_5039Parser;
	}

	/**
	 * @generated
	 */
	private IParser networkClassName_5040Parser;

	/**
	 * @generated
	 */
	private IParser getNetworkClassName_5040Parser() {
		if (networkClassName_5040Parser == null) {
			EAttribute[] features = new EAttribute[] { OmtgPackage.eINSTANCE
					.getelement_Name() };
			MessageFormatParser parser = new MessageFormatParser(features);
			networkClassName_5040Parser = parser;
		}
		return networkClassName_5040Parser;
	}

	/**
	 * @generated
	 */
	private IParser samplingName_5049Parser;

	/**
	 * @generated
	 */
	private IParser getSamplingName_5049Parser() {
		if (samplingName_5049Parser == null) {
			EAttribute[] features = new EAttribute[] { OmtgPackage.eINSTANCE
					.getelement_Name() };
			MessageFormatParser parser = new MessageFormatParser(features);
			samplingName_5049Parser = parser;
		}
		return samplingName_5049Parser;
	}

	/**
	 * @generated
	 */
	private IParser isolineName_5042Parser;

	/**
	 * @generated
	 */
	private IParser getIsolineName_5042Parser() {
		if (isolineName_5042Parser == null) {
			EAttribute[] features = new EAttribute[] { OmtgPackage.eINSTANCE
					.getelement_Name() };
			MessageFormatParser parser = new MessageFormatParser(features);
			isolineName_5042Parser = parser;
		}
		return isolineName_5042Parser;
	}

	/**
	 * @generated
	 */
	private IParser nodeName_5043Parser;

	/**
	 * @generated
	 */
	private IParser getNodeName_5043Parser() {
		if (nodeName_5043Parser == null) {
			EAttribute[] features = new EAttribute[] { OmtgPackage.eINSTANCE
					.getelement_Name() };
			MessageFormatParser parser = new MessageFormatParser(features);
			nodeName_5043Parser = parser;
		}
		return nodeName_5043Parser;
	}

	/**
	 * @generated
	 */
	private IParser adjacentPolygonsName_5044Parser;

	/**
	 * @generated
	 */
	private IParser getAdjacentPolygonsName_5044Parser() {
		if (adjacentPolygonsName_5044Parser == null) {
			EAttribute[] features = new EAttribute[] { OmtgPackage.eINSTANCE
					.getelement_Name() };
			MessageFormatParser parser = new MessageFormatParser(features);
			adjacentPolygonsName_5044Parser = parser;
		}
		return adjacentPolygonsName_5044Parser;
	}

	/**
	 * @generated
	 */
	private IParser bidirectionalLineName_5045Parser;

	/**
	 * @generated
	 */
	private IParser getBidirectionalLineName_5045Parser() {
		if (bidirectionalLineName_5045Parser == null) {
			EAttribute[] features = new EAttribute[] { OmtgPackage.eINSTANCE
					.getelement_Name() };
			MessageFormatParser parser = new MessageFormatParser(features);
			bidirectionalLineName_5045Parser = parser;
		}
		return bidirectionalLineName_5045Parser;
	}

	/**
	 * @generated
	 */
	private IParser tesselationName_5046Parser;

	/**
	 * @generated
	 */
	private IParser getTesselationName_5046Parser() {
		if (tesselationName_5046Parser == null) {
			EAttribute[] features = new EAttribute[] { OmtgPackage.eINSTANCE
					.getelement_Name() };
			MessageFormatParser parser = new MessageFormatParser(features);
			tesselationName_5046Parser = parser;
		}
		return tesselationName_5046Parser;
	}

	/**
	 * @generated
	 */
	private IParser unidirectionalLineName_5047Parser;

	/**
	 * @generated
	 */
	private IParser getUnidirectionalLineName_5047Parser() {
		if (unidirectionalLineName_5047Parser == null) {
			EAttribute[] features = new EAttribute[] { OmtgPackage.eINSTANCE
					.getelement_Name() };
			MessageFormatParser parser = new MessageFormatParser(features);
			unidirectionalLineName_5047Parser = parser;
		}
		return unidirectionalLineName_5047Parser;
	}

	/**
	 * @generated
	 */
	private IParser conventionalName_5048Parser;

	/**
	 * @generated
	 */
	private IParser getConventionalName_5048Parser() {
		if (conventionalName_5048Parser == null) {
			EAttribute[] features = new EAttribute[] { OmtgPackage.eINSTANCE
					.getelement_Name() };
			MessageFormatParser parser = new MessageFormatParser(features);
			conventionalName_5048Parser = parser;
		}
		return conventionalName_5048Parser;
	}

	/**
	 * @generated
	 */
	private IParser attributeNameType_5001Parser;

	/**
	 * @generated
	 */
	private IParser getAttributeNameType_5001Parser() {
		if (attributeNameType_5001Parser == null) {
			EAttribute[] features = new EAttribute[] {
					OmtgPackage.eINSTANCE.getAttribute_Name(),
					OmtgPackage.eINSTANCE.getAttribute_Type() };
			MessageFormatParser parser = new MessageFormatParser(features);
			parser.setViewPattern("{0}:{1}"); //$NON-NLS-1$
			parser.setEditorPattern("{0}:{1}"); //$NON-NLS-1$
			parser.setEditPattern("{0}:{1}"); //$NON-NLS-1$
			attributeNameType_5001Parser = parser;
		}
		return attributeNameType_5001Parser;
	}

	/**
	 * @generated
	 */
	private IParser methodNameAttibutesReturn_5023Parser;

	/**
	 * @generated
	 */
	private IParser getMethodNameAttibutesReturn_5023Parser() {
		if (methodNameAttibutesReturn_5023Parser == null) {
			EAttribute[] features = new EAttribute[] {
					OmtgPackage.eINSTANCE.getMethod_Name(),
					OmtgPackage.eINSTANCE.getMethod_Attibutes(),
					OmtgPackage.eINSTANCE.getMethod_Return() };
			MessageFormatParser parser = new MessageFormatParser(features);
			parser.setViewPattern("{0}({1}):{2}"); //$NON-NLS-1$
			parser.setEditorPattern("{0}({1}):{2}"); //$NON-NLS-1$
			parser.setEditPattern("{0}({1}):{2}"); //$NON-NLS-1$
			methodNameAttibutesReturn_5023Parser = parser;
		}
		return methodNameAttibutesReturn_5023Parser;
	}

	/**
	 * @generated
	 */
	private IParser attributeNameType_5003Parser;

	/**
	 * @generated
	 */
	private IParser getAttributeNameType_5003Parser() {
		if (attributeNameType_5003Parser == null) {
			EAttribute[] features = new EAttribute[] {
					OmtgPackage.eINSTANCE.getAttribute_Name(),
					OmtgPackage.eINSTANCE.getAttribute_Type() };
			MessageFormatParser parser = new MessageFormatParser(features);
			parser.setViewPattern("{0}:{1}"); //$NON-NLS-1$
			parser.setEditorPattern("{0}:{1}"); //$NON-NLS-1$
			parser.setEditPattern("{0}:{1}"); //$NON-NLS-1$
			attributeNameType_5003Parser = parser;
		}
		return attributeNameType_5003Parser;
	}

	/**
	 * @generated
	 */
	private IParser methodNameAttibutesReturn_5024Parser;

	/**
	 * @generated
	 */
	private IParser getMethodNameAttibutesReturn_5024Parser() {
		if (methodNameAttibutesReturn_5024Parser == null) {
			EAttribute[] features = new EAttribute[] {
					OmtgPackage.eINSTANCE.getMethod_Name(),
					OmtgPackage.eINSTANCE.getMethod_Attibutes(),
					OmtgPackage.eINSTANCE.getMethod_Return() };
			MessageFormatParser parser = new MessageFormatParser(features);
			parser.setViewPattern("{0}({1}):{2}"); //$NON-NLS-1$
			parser.setEditorPattern("{0}({1}):{2}"); //$NON-NLS-1$
			parser.setEditPattern("{0}({1}):{2}"); //$NON-NLS-1$
			methodNameAttibutesReturn_5024Parser = parser;
		}
		return methodNameAttibutesReturn_5024Parser;
	}

	/**
	 * @generated
	 */
	private IParser attributeNameType_5005Parser;

	/**
	 * @generated
	 */
	private IParser getAttributeNameType_5005Parser() {
		if (attributeNameType_5005Parser == null) {
			EAttribute[] features = new EAttribute[] {
					OmtgPackage.eINSTANCE.getAttribute_Name(),
					OmtgPackage.eINSTANCE.getAttribute_Type() };
			MessageFormatParser parser = new MessageFormatParser(features);
			parser.setViewPattern("{0}:{1}"); //$NON-NLS-1$
			parser.setEditorPattern("{0}:{1}"); //$NON-NLS-1$
			parser.setEditPattern("{0}:{1}"); //$NON-NLS-1$
			attributeNameType_5005Parser = parser;
		}
		return attributeNameType_5005Parser;
	}

	/**
	 * @generated
	 */
	private IParser methodNameAttibutesReturn_5025Parser;

	/**
	 * @generated
	 */
	private IParser getMethodNameAttibutesReturn_5025Parser() {
		if (methodNameAttibutesReturn_5025Parser == null) {
			EAttribute[] features = new EAttribute[] {
					OmtgPackage.eINSTANCE.getMethod_Name(),
					OmtgPackage.eINSTANCE.getMethod_Attibutes(),
					OmtgPackage.eINSTANCE.getMethod_Return() };
			MessageFormatParser parser = new MessageFormatParser(features);
			parser.setViewPattern("{0}({1}):{2}"); //$NON-NLS-1$
			parser.setEditorPattern("{0}({1}):{2}"); //$NON-NLS-1$
			parser.setEditPattern("{0}({1}):{2}"); //$NON-NLS-1$
			methodNameAttibutesReturn_5025Parser = parser;
		}
		return methodNameAttibutesReturn_5025Parser;
	}

	/**
	 * @generated
	 */
	private IParser attributeNameType_5007Parser;

	/**
	 * @generated
	 */
	private IParser getAttributeNameType_5007Parser() {
		if (attributeNameType_5007Parser == null) {
			EAttribute[] features = new EAttribute[] {
					OmtgPackage.eINSTANCE.getAttribute_Name(),
					OmtgPackage.eINSTANCE.getAttribute_Type() };
			MessageFormatParser parser = new MessageFormatParser(features);
			parser.setViewPattern("{0}:{1}"); //$NON-NLS-1$
			parser.setEditorPattern("{0}:{1}"); //$NON-NLS-1$
			parser.setEditPattern("{0}:{1}"); //$NON-NLS-1$
			attributeNameType_5007Parser = parser;
		}
		return attributeNameType_5007Parser;
	}

	/**
	 * @generated
	 */
	private IParser methodNameAttibutesReturn_5027Parser;

	/**
	 * @generated
	 */
	private IParser getMethodNameAttibutesReturn_5027Parser() {
		if (methodNameAttibutesReturn_5027Parser == null) {
			EAttribute[] features = new EAttribute[] {
					OmtgPackage.eINSTANCE.getMethod_Name(),
					OmtgPackage.eINSTANCE.getMethod_Attibutes(),
					OmtgPackage.eINSTANCE.getMethod_Return() };
			MessageFormatParser parser = new MessageFormatParser(features);
			parser.setViewPattern("{0}({1}):{2}"); //$NON-NLS-1$
			parser.setEditorPattern("{0}({1}):{2}"); //$NON-NLS-1$
			parser.setEditPattern("{0}({1}):{2}"); //$NON-NLS-1$
			methodNameAttibutesReturn_5027Parser = parser;
		}
		return methodNameAttibutesReturn_5027Parser;
	}

	/**
	 * @generated
	 */
	private IParser attributeNameType_5009Parser;

	/**
	 * @generated
	 */
	private IParser getAttributeNameType_5009Parser() {
		if (attributeNameType_5009Parser == null) {
			EAttribute[] features = new EAttribute[] {
					OmtgPackage.eINSTANCE.getAttribute_Name(),
					OmtgPackage.eINSTANCE.getAttribute_Type() };
			MessageFormatParser parser = new MessageFormatParser(features);
			parser.setViewPattern("{0}:{1}"); //$NON-NLS-1$
			parser.setEditorPattern("{0}:{1}"); //$NON-NLS-1$
			parser.setEditPattern("{0}:{1}"); //$NON-NLS-1$
			attributeNameType_5009Parser = parser;
		}
		return attributeNameType_5009Parser;
	}

	/**
	 * @generated
	 */
	private IParser methodNameAttibutesReturn_5028Parser;

	/**
	 * @generated
	 */
	private IParser getMethodNameAttibutesReturn_5028Parser() {
		if (methodNameAttibutesReturn_5028Parser == null) {
			EAttribute[] features = new EAttribute[] {
					OmtgPackage.eINSTANCE.getMethod_Name(),
					OmtgPackage.eINSTANCE.getMethod_Attibutes(),
					OmtgPackage.eINSTANCE.getMethod_Return() };
			MessageFormatParser parser = new MessageFormatParser(features);
			parser.setViewPattern("{0}({1}):{2}"); //$NON-NLS-1$
			parser.setEditorPattern("{0}({1}):{2}"); //$NON-NLS-1$
			parser.setEditPattern("{0}({1}):{2}"); //$NON-NLS-1$
			methodNameAttibutesReturn_5028Parser = parser;
		}
		return methodNameAttibutesReturn_5028Parser;
	}

	/**
	 * @generated
	 */
	private IParser attributeNameType_5011Parser;

	/**
	 * @generated
	 */
	private IParser getAttributeNameType_5011Parser() {
		if (attributeNameType_5011Parser == null) {
			EAttribute[] features = new EAttribute[] {
					OmtgPackage.eINSTANCE.getAttribute_Name(),
					OmtgPackage.eINSTANCE.getAttribute_Type() };
			MessageFormatParser parser = new MessageFormatParser(features);
			parser.setViewPattern("{0}:{1}"); //$NON-NLS-1$
			parser.setEditorPattern("{0}:{1}"); //$NON-NLS-1$
			parser.setEditPattern("{0}:{1}"); //$NON-NLS-1$
			attributeNameType_5011Parser = parser;
		}
		return attributeNameType_5011Parser;
	}

	/**
	 * @generated
	 */
	private IParser methodNameAttibutesReturn_5029Parser;

	/**
	 * @generated
	 */
	private IParser getMethodNameAttibutesReturn_5029Parser() {
		if (methodNameAttibutesReturn_5029Parser == null) {
			EAttribute[] features = new EAttribute[] {
					OmtgPackage.eINSTANCE.getMethod_Name(),
					OmtgPackage.eINSTANCE.getMethod_Attibutes(),
					OmtgPackage.eINSTANCE.getMethod_Return() };
			MessageFormatParser parser = new MessageFormatParser(features);
			parser.setViewPattern("{0}({1}):{2}"); //$NON-NLS-1$
			parser.setEditorPattern("{0}({1}):{2}"); //$NON-NLS-1$
			parser.setEditPattern("{0}({1}):{2}"); //$NON-NLS-1$
			methodNameAttibutesReturn_5029Parser = parser;
		}
		return methodNameAttibutesReturn_5029Parser;
	}

	/**
	 * @generated
	 */
	private IParser attributeNameType_5013Parser;

	/**
	 * @generated
	 */
	private IParser getAttributeNameType_5013Parser() {
		if (attributeNameType_5013Parser == null) {
			EAttribute[] features = new EAttribute[] {
					OmtgPackage.eINSTANCE.getAttribute_Name(),
					OmtgPackage.eINSTANCE.getAttribute_Type() };
			MessageFormatParser parser = new MessageFormatParser(features);
			parser.setViewPattern("{0}:{1}"); //$NON-NLS-1$
			parser.setEditorPattern("{0}:{1}"); //$NON-NLS-1$
			parser.setEditPattern("{0}:{1}"); //$NON-NLS-1$
			attributeNameType_5013Parser = parser;
		}
		return attributeNameType_5013Parser;
	}

	/**
	 * @generated
	 */
	private IParser methodNameAttibutesReturn_5030Parser;

	/**
	 * @generated
	 */
	private IParser getMethodNameAttibutesReturn_5030Parser() {
		if (methodNameAttibutesReturn_5030Parser == null) {
			EAttribute[] features = new EAttribute[] {
					OmtgPackage.eINSTANCE.getMethod_Name(),
					OmtgPackage.eINSTANCE.getMethod_Attibutes(),
					OmtgPackage.eINSTANCE.getMethod_Return() };
			MessageFormatParser parser = new MessageFormatParser(features);
			parser.setViewPattern("{0}({1}):{2}"); //$NON-NLS-1$
			parser.setEditorPattern("{0}({1}):{2}"); //$NON-NLS-1$
			parser.setEditPattern("{0}({1}):{2}"); //$NON-NLS-1$
			methodNameAttibutesReturn_5030Parser = parser;
		}
		return methodNameAttibutesReturn_5030Parser;
	}

	/**
	 * @generated
	 */
	private IParser attributeNameType_5015Parser;

	/**
	 * @generated
	 */
	private IParser getAttributeNameType_5015Parser() {
		if (attributeNameType_5015Parser == null) {
			EAttribute[] features = new EAttribute[] {
					OmtgPackage.eINSTANCE.getAttribute_Name(),
					OmtgPackage.eINSTANCE.getAttribute_Type() };
			MessageFormatParser parser = new MessageFormatParser(features);
			parser.setViewPattern("{0}:{1}"); //$NON-NLS-1$
			parser.setEditorPattern("{0}:{1}"); //$NON-NLS-1$
			parser.setEditPattern("{0}:{1}"); //$NON-NLS-1$
			attributeNameType_5015Parser = parser;
		}
		return attributeNameType_5015Parser;
	}

	/**
	 * @generated
	 */
	private IParser methodNameAttibutesReturn_5031Parser;

	/**
	 * @generated
	 */
	private IParser getMethodNameAttibutesReturn_5031Parser() {
		if (methodNameAttibutesReturn_5031Parser == null) {
			EAttribute[] features = new EAttribute[] {
					OmtgPackage.eINSTANCE.getMethod_Name(),
					OmtgPackage.eINSTANCE.getMethod_Attibutes(),
					OmtgPackage.eINSTANCE.getMethod_Return() };
			MessageFormatParser parser = new MessageFormatParser(features);
			parser.setViewPattern("{0}({1}):{2}"); //$NON-NLS-1$
			parser.setEditorPattern("{0}({1}):{2}"); //$NON-NLS-1$
			parser.setEditPattern("{0}({1}):{2}"); //$NON-NLS-1$
			methodNameAttibutesReturn_5031Parser = parser;
		}
		return methodNameAttibutesReturn_5031Parser;
	}

	/**
	 * @generated
	 */
	private IParser attributeNameType_5017Parser;

	/**
	 * @generated
	 */
	private IParser getAttributeNameType_5017Parser() {
		if (attributeNameType_5017Parser == null) {
			EAttribute[] features = new EAttribute[] {
					OmtgPackage.eINSTANCE.getAttribute_Name(),
					OmtgPackage.eINSTANCE.getAttribute_Type() };
			MessageFormatParser parser = new MessageFormatParser(features);
			parser.setViewPattern("{0}:{1}"); //$NON-NLS-1$
			parser.setEditorPattern("{0}:{1}"); //$NON-NLS-1$
			parser.setEditPattern("{0}:{1}"); //$NON-NLS-1$
			attributeNameType_5017Parser = parser;
		}
		return attributeNameType_5017Parser;
	}

	/**
	 * @generated
	 */
	private IParser methodNameAttibutesReturn_5032Parser;

	/**
	 * @generated
	 */
	private IParser getMethodNameAttibutesReturn_5032Parser() {
		if (methodNameAttibutesReturn_5032Parser == null) {
			EAttribute[] features = new EAttribute[] {
					OmtgPackage.eINSTANCE.getMethod_Name(),
					OmtgPackage.eINSTANCE.getMethod_Attibutes(),
					OmtgPackage.eINSTANCE.getMethod_Return() };
			MessageFormatParser parser = new MessageFormatParser(features);
			parser.setViewPattern("{0}({1}):{2}"); //$NON-NLS-1$
			parser.setEditorPattern("{0}({1}):{2}"); //$NON-NLS-1$
			parser.setEditPattern("{0}({1}):{2}"); //$NON-NLS-1$
			methodNameAttibutesReturn_5032Parser = parser;
		}
		return methodNameAttibutesReturn_5032Parser;
	}

	/**
	 * @generated
	 */
	private IParser attributeNameType_5019Parser;

	/**
	 * @generated
	 */
	private IParser getAttributeNameType_5019Parser() {
		if (attributeNameType_5019Parser == null) {
			EAttribute[] features = new EAttribute[] {
					OmtgPackage.eINSTANCE.getAttribute_Name(),
					OmtgPackage.eINSTANCE.getAttribute_Type() };
			MessageFormatParser parser = new MessageFormatParser(features);
			parser.setViewPattern("{0}:{1}"); //$NON-NLS-1$
			parser.setEditorPattern("{0}:{1}"); //$NON-NLS-1$
			parser.setEditPattern("{0}:{1}"); //$NON-NLS-1$
			attributeNameType_5019Parser = parser;
		}
		return attributeNameType_5019Parser;
	}

	/**
	 * @generated
	 */
	private IParser methodNameAttibutesReturn_5033Parser;

	/**
	 * @generated
	 */
	private IParser getMethodNameAttibutesReturn_5033Parser() {
		if (methodNameAttibutesReturn_5033Parser == null) {
			EAttribute[] features = new EAttribute[] {
					OmtgPackage.eINSTANCE.getMethod_Name(),
					OmtgPackage.eINSTANCE.getMethod_Attibutes(),
					OmtgPackage.eINSTANCE.getMethod_Return() };
			MessageFormatParser parser = new MessageFormatParser(features);
			parser.setViewPattern("{0}({1}):{2}"); //$NON-NLS-1$
			parser.setEditorPattern("{0}({1}):{2}"); //$NON-NLS-1$
			parser.setEditPattern("{0}({1}):{2}"); //$NON-NLS-1$
			methodNameAttibutesReturn_5033Parser = parser;
		}
		return methodNameAttibutesReturn_5033Parser;
	}

	/**
	 * @generated
	 */
	private IParser attributeNameType_5021Parser;

	/**
	 * @generated
	 */
	private IParser getAttributeNameType_5021Parser() {
		if (attributeNameType_5021Parser == null) {
			EAttribute[] features = new EAttribute[] {
					OmtgPackage.eINSTANCE.getAttribute_Name(),
					OmtgPackage.eINSTANCE.getAttribute_Type() };
			MessageFormatParser parser = new MessageFormatParser(features);
			parser.setViewPattern("{0}:{1}"); //$NON-NLS-1$
			parser.setEditorPattern("{0}:{1}"); //$NON-NLS-1$
			parser.setEditPattern("{0}:{1}"); //$NON-NLS-1$
			attributeNameType_5021Parser = parser;
		}
		return attributeNameType_5021Parser;
	}

	/**
	 * @generated
	 */
	private IParser methodNameAttibutesReturn_5035Parser;

	/**
	 * @generated
	 */
	private IParser getMethodNameAttibutesReturn_5035Parser() {
		if (methodNameAttibutesReturn_5035Parser == null) {
			EAttribute[] features = new EAttribute[] {
					OmtgPackage.eINSTANCE.getMethod_Name(),
					OmtgPackage.eINSTANCE.getMethod_Attibutes(),
					OmtgPackage.eINSTANCE.getMethod_Return() };
			MessageFormatParser parser = new MessageFormatParser(features);
			parser.setViewPattern("{0}({1}):{2}"); //$NON-NLS-1$
			parser.setEditorPattern("{0}({1}):{2}"); //$NON-NLS-1$
			parser.setEditPattern("{0}({1}):{2}"); //$NON-NLS-1$
			methodNameAttibutesReturn_5035Parser = parser;
		}
		return methodNameAttibutesReturn_5035Parser;
	}

	/**
	 * @generated
	 */
	private IParser attributeNameType_5034Parser;

	/**
	 * @generated
	 */
	private IParser getAttributeNameType_5034Parser() {
		if (attributeNameType_5034Parser == null) {
			EAttribute[] features = new EAttribute[] {
					OmtgPackage.eINSTANCE.getAttribute_Name(),
					OmtgPackage.eINSTANCE.getAttribute_Type() };
			MessageFormatParser parser = new MessageFormatParser(features);
			parser.setViewPattern("{0}:{1}"); //$NON-NLS-1$
			parser.setEditorPattern("{0}:{1}"); //$NON-NLS-1$
			parser.setEditPattern("{0}:{1}"); //$NON-NLS-1$
			attributeNameType_5034Parser = parser;
		}
		return attributeNameType_5034Parser;
	}

	/**
	 * @generated
	 */
	private IParser methodNameAttibutesReturn_5036Parser;

	/**
	 * @generated
	 */
	private IParser getMethodNameAttibutesReturn_5036Parser() {
		if (methodNameAttibutesReturn_5036Parser == null) {
			EAttribute[] features = new EAttribute[] {
					OmtgPackage.eINSTANCE.getMethod_Name(),
					OmtgPackage.eINSTANCE.getMethod_Attibutes(),
					OmtgPackage.eINSTANCE.getMethod_Return() };
			MessageFormatParser parser = new MessageFormatParser(features);
			parser.setViewPattern("{0}({1}):{2}"); //$NON-NLS-1$
			parser.setEditorPattern("{0}({1}):{2}"); //$NON-NLS-1$
			parser.setEditPattern("{0}({1}):{2}"); //$NON-NLS-1$
			methodNameAttibutesReturn_5036Parser = parser;
		}
		return methodNameAttibutesReturn_5036Parser;
	}

	/**
	 * @generated
	 */
	protected IParser getParser(int visualID) {
		switch (visualID) {
		case PolygonNameEditPart.VISUAL_ID:
			return getPolygonName_5037Parser();
		case PointNameEditPart.VISUAL_ID:
			return getPointName_5038Parser();
		case LineNameEditPart.VISUAL_ID:
			return getLineName_5039Parser();
		case NetworkClassNameEditPart.VISUAL_ID:
			return getNetworkClassName_5040Parser();
		case SamplingNameEditPart.VISUAL_ID:
			return getSamplingName_5049Parser();
		case IsolineNameEditPart.VISUAL_ID:
			return getIsolineName_5042Parser();
		case NodeNameEditPart.VISUAL_ID:
			return getNodeName_5043Parser();
		case AdjacentPolygonsNameEditPart.VISUAL_ID:
			return getAdjacentPolygonsName_5044Parser();
		case BidirectionalLineNameEditPart.VISUAL_ID:
			return getBidirectionalLineName_5045Parser();
		case TesselationNameEditPart.VISUAL_ID:
			return getTesselationName_5046Parser();
		case UnidirectionalLineNameEditPart.VISUAL_ID:
			return getUnidirectionalLineName_5047Parser();
		case ConventionalNameEditPart.VISUAL_ID:
			return getConventionalName_5048Parser();
		case AttributeNameTypeEditPart.VISUAL_ID:
			return getAttributeNameType_5001Parser();
		case MethodNameAttibutesReturnEditPart.VISUAL_ID:
			return getMethodNameAttibutesReturn_5023Parser();
		case AttributeNameType2EditPart.VISUAL_ID:
			return getAttributeNameType_5003Parser();
		case MethodNameAttibutesReturn2EditPart.VISUAL_ID:
			return getMethodNameAttibutesReturn_5024Parser();
		case AttributeNameType3EditPart.VISUAL_ID:
			return getAttributeNameType_5005Parser();
		case MethodNameAttibutesReturn3EditPart.VISUAL_ID:
			return getMethodNameAttibutesReturn_5025Parser();
		case AttributeNameType4EditPart.VISUAL_ID:
			return getAttributeNameType_5007Parser();
		case MethodNameAttibutesReturn4EditPart.VISUAL_ID:
			return getMethodNameAttibutesReturn_5027Parser();
		case AttributeNameType5EditPart.VISUAL_ID:
			return getAttributeNameType_5009Parser();
		case MethodNameAttibutesReturn5EditPart.VISUAL_ID:
			return getMethodNameAttibutesReturn_5028Parser();
		case AttributeNameType6EditPart.VISUAL_ID:
			return getAttributeNameType_5011Parser();
		case MethodNameAttibutesReturn6EditPart.VISUAL_ID:
			return getMethodNameAttibutesReturn_5029Parser();
		case AttributeNameType7EditPart.VISUAL_ID:
			return getAttributeNameType_5013Parser();
		case MethodNameAttibutesReturn7EditPart.VISUAL_ID:
			return getMethodNameAttibutesReturn_5030Parser();
		case AttributeNameType8EditPart.VISUAL_ID:
			return getAttributeNameType_5015Parser();
		case MethodNameAttibutesReturn8EditPart.VISUAL_ID:
			return getMethodNameAttibutesReturn_5031Parser();
		case AttributeNameType9EditPart.VISUAL_ID:
			return getAttributeNameType_5017Parser();
		case MethodNameAttibutesReturn9EditPart.VISUAL_ID:
			return getMethodNameAttibutesReturn_5032Parser();
		case AttributeNameType10EditPart.VISUAL_ID:
			return getAttributeNameType_5019Parser();
		case MethodNameAttibutesReturn10EditPart.VISUAL_ID:
			return getMethodNameAttibutesReturn_5033Parser();
		case AttributeNameType11EditPart.VISUAL_ID:
			return getAttributeNameType_5021Parser();
		case MethodNameAttibutesReturn11EditPart.VISUAL_ID:
			return getMethodNameAttibutesReturn_5035Parser();
		case AttributeNameType12EditPart.VISUAL_ID:
			return getAttributeNameType_5034Parser();
		case MethodNameAttibutesReturn12EditPart.VISUAL_ID:
			return getMethodNameAttibutesReturn_5036Parser();
		}
		return null;
	}

	/**
	 * Utility method that consults ParserService
	 * @generated
	 */
	public static IParser getParser(IElementType type, EObject object,
			String parserHint) {
		return ParserService.getInstance().getParser(
				new HintAdapter(type, object, parserHint));
	}

	/**
	 * @generated
	 */
	public IParser getParser(IAdaptable hint) {
		String vid = (String) hint.getAdapter(String.class);
		if (vid != null) {
			return getParser(OmtgVisualIDRegistry.getVisualID(vid));
		}
		View view = (View) hint.getAdapter(View.class);
		if (view != null) {
			return getParser(OmtgVisualIDRegistry.getVisualID(view));
		}
		return null;
	}

	/**
	 * @generated
	 */
	public boolean provides(IOperation operation) {
		if (operation instanceof GetParserOperation) {
			IAdaptable hint = ((GetParserOperation) operation).getHint();
			if (OmtgElementTypes.getElement(hint) == null) {
				return false;
			}
			return getParser(hint) != null;
		}
		return false;
	}

	/**
	 * @generated
	 */
	private static class HintAdapter extends ParserHintAdapter {

		/**
		 * @generated
		 */
		private final IElementType elementType;

		/**
		 * @generated
		 */
		public HintAdapter(IElementType type, EObject object, String parserHint) {
			super(object, parserHint);
			assert type != null;
			elementType = type;
		}

		/**
		 * @generated
		 */
		public Object getAdapter(Class adapter) {
			if (IElementType.class.equals(adapter)) {
				return elementType;
			}
			return super.getAdapter(adapter);
		}
	}

}
