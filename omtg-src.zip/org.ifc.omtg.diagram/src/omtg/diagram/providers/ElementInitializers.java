package omtg.diagram.providers;

import omtg.diagram.part.OmtgDiagramEditorPlugin;

/**
 * @generated
 */
public class ElementInitializers {

	protected ElementInitializers() {
		// use #getInstance to access cached instance
	}

	/**
	 * @generated
	 */
	public static ElementInitializers getInstance() {
		ElementInitializers cached = OmtgDiagramEditorPlugin.getInstance()
				.getElementInitializers();
		if (cached == null) {
			OmtgDiagramEditorPlugin.getInstance().setElementInitializers(
					cached = new ElementInitializers());
		}
		return cached;
	}
}
