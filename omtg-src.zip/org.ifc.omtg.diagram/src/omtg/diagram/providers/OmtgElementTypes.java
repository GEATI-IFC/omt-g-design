package omtg.diagram.providers;

import java.util.HashSet;
import java.util.IdentityHashMap;
import java.util.Map;
import java.util.Set;

import omtg.OmtgPackage;
import omtg.diagram.edit.parts.AdjacentPolygonsEditPart;
import omtg.diagram.edit.parts.AgregationEditPart;
import omtg.diagram.edit.parts.Attribute10EditPart;
import omtg.diagram.edit.parts.Attribute11EditPart;
import omtg.diagram.edit.parts.Attribute12EditPart;
import omtg.diagram.edit.parts.Attribute2EditPart;
import omtg.diagram.edit.parts.Attribute3EditPart;
import omtg.diagram.edit.parts.Attribute4EditPart;
import omtg.diagram.edit.parts.Attribute5EditPart;
import omtg.diagram.edit.parts.Attribute6EditPart;
import omtg.diagram.edit.parts.Attribute7EditPart;
import omtg.diagram.edit.parts.Attribute8EditPart;
import omtg.diagram.edit.parts.Attribute9EditPart;
import omtg.diagram.edit.parts.AttributeEditPart;
import omtg.diagram.edit.parts.BidirectionalLineEditPart;
import omtg.diagram.edit.parts.ConventionalEditPart;
import omtg.diagram.edit.parts.DisjointPartialEditPart;
import omtg.diagram.edit.parts.DisjointTotalEditPart;
import omtg.diagram.edit.parts.IsolineEditPart;
import omtg.diagram.edit.parts.LineEditPart;
import omtg.diagram.edit.parts.Method10EditPart;
import omtg.diagram.edit.parts.Method11EditPart;
import omtg.diagram.edit.parts.Method12EditPart;
import omtg.diagram.edit.parts.Method2EditPart;
import omtg.diagram.edit.parts.Method3EditPart;
import omtg.diagram.edit.parts.Method4EditPart;
import omtg.diagram.edit.parts.Method5EditPart;
import omtg.diagram.edit.parts.Method6EditPart;
import omtg.diagram.edit.parts.Method7EditPart;
import omtg.diagram.edit.parts.Method8EditPart;
import omtg.diagram.edit.parts.Method9EditPart;
import omtg.diagram.edit.parts.MethodEditPart;
import omtg.diagram.edit.parts.NetworkAssociationEditPart;
import omtg.diagram.edit.parts.NetworkClassEditPart;
import omtg.diagram.edit.parts.NodeEditPart;
import omtg.diagram.edit.parts.OverlappingPartialEditPart;
import omtg.diagram.edit.parts.OverlappingTotalEditPart;
import omtg.diagram.edit.parts.PointEditPart;
import omtg.diagram.edit.parts.PolygonEditPart;
import omtg.diagram.edit.parts.SamplingEditPart;
import omtg.diagram.edit.parts.ScaleEditPart;
import omtg.diagram.edit.parts.SchemaEditPart;
import omtg.diagram.edit.parts.ShapeEditPart;
import omtg.diagram.edit.parts.SimpleEditPart;
import omtg.diagram.edit.parts.SpatialAgregationEditPart;
import omtg.diagram.edit.parts.SpatialEditPart;
import omtg.diagram.edit.parts.TesselationEditPart;
import omtg.diagram.edit.parts.UnidirectionalLineEditPart;
import omtg.diagram.part.OmtgDiagramEditorPlugin;

import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EClassifier;
import org.eclipse.emf.ecore.ENamedElement;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.gmf.runtime.emf.type.core.ElementTypeRegistry;
import org.eclipse.gmf.runtime.emf.type.core.IElementType;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.jface.resource.ImageRegistry;
import org.eclipse.swt.graphics.Image;

/**
 * @generated
 */
public class OmtgElementTypes {

	/**
	 * @generated
	 */
	private OmtgElementTypes() {
	}

	/**
	 * @generated
	 */
	private static Map<IElementType, ENamedElement> elements;

	/**
	 * @generated
	 */
	private static ImageRegistry imageRegistry;

	/**
	 * @generated
	 */
	private static Set<IElementType> KNOWN_ELEMENT_TYPES;

	/**
	 * @generated
	 */
	public static final IElementType Schema_1000 = getElementType("org.ifc.omtg.diagram.Schema_1000"); //$NON-NLS-1$
	/**
	 * @generated
	 */
	public static final IElementType Polygon_2013 = getElementType("org.ifc.omtg.diagram.Polygon_2013"); //$NON-NLS-1$
	/**
	 * @generated
	 */
	public static final IElementType Point_2014 = getElementType("org.ifc.omtg.diagram.Point_2014"); //$NON-NLS-1$
	/**
	 * @generated
	 */
	public static final IElementType Line_2015 = getElementType("org.ifc.omtg.diagram.Line_2015"); //$NON-NLS-1$
	/**
	 * @generated
	 */
	public static final IElementType NetworkClass_2016 = getElementType("org.ifc.omtg.diagram.NetworkClass_2016"); //$NON-NLS-1$
	/**
	 * @generated
	 */
	public static final IElementType Sampling_2025 = getElementType("org.ifc.omtg.diagram.Sampling_2025"); //$NON-NLS-1$
	/**
	 * @generated
	 */
	public static final IElementType Isoline_2018 = getElementType("org.ifc.omtg.diagram.Isoline_2018"); //$NON-NLS-1$
	/**
	 * @generated
	 */
	public static final IElementType Node_2019 = getElementType("org.ifc.omtg.diagram.Node_2019"); //$NON-NLS-1$
	/**
	 * @generated
	 */
	public static final IElementType AdjacentPolygons_2020 = getElementType("org.ifc.omtg.diagram.AdjacentPolygons_2020"); //$NON-NLS-1$
	/**
	 * @generated
	 */
	public static final IElementType BidirectionalLine_2021 = getElementType("org.ifc.omtg.diagram.BidirectionalLine_2021"); //$NON-NLS-1$
	/**
	 * @generated
	 */
	public static final IElementType Tesselation_2022 = getElementType("org.ifc.omtg.diagram.Tesselation_2022"); //$NON-NLS-1$
	/**
	 * @generated
	 */
	public static final IElementType UnidirectionalLine_2023 = getElementType("org.ifc.omtg.diagram.UnidirectionalLine_2023"); //$NON-NLS-1$
	/**
	 * @generated
	 */
	public static final IElementType Conventional_2024 = getElementType("org.ifc.omtg.diagram.Conventional_2024"); //$NON-NLS-1$
	/**
	 * @generated
	 */
	public static final IElementType Attribute_3001 = getElementType("org.ifc.omtg.diagram.Attribute_3001"); //$NON-NLS-1$
	/**
	 * @generated
	 */
	public static final IElementType Method_3012 = getElementType("org.ifc.omtg.diagram.Method_3012"); //$NON-NLS-1$
	/**
	 * @generated
	 */
	public static final IElementType Attribute_3002 = getElementType("org.ifc.omtg.diagram.Attribute_3002"); //$NON-NLS-1$
	/**
	 * @generated
	 */
	public static final IElementType Method_3013 = getElementType("org.ifc.omtg.diagram.Method_3013"); //$NON-NLS-1$
	/**
	 * @generated
	 */
	public static final IElementType Attribute_3003 = getElementType("org.ifc.omtg.diagram.Attribute_3003"); //$NON-NLS-1$
	/**
	 * @generated
	 */
	public static final IElementType Method_3014 = getElementType("org.ifc.omtg.diagram.Method_3014"); //$NON-NLS-1$
	/**
	 * @generated
	 */
	public static final IElementType Attribute_3004 = getElementType("org.ifc.omtg.diagram.Attribute_3004"); //$NON-NLS-1$
	/**
	 * @generated
	 */
	public static final IElementType Method_3015 = getElementType("org.ifc.omtg.diagram.Method_3015"); //$NON-NLS-1$
	/**
	 * @generated
	 */
	public static final IElementType Attribute_3005 = getElementType("org.ifc.omtg.diagram.Attribute_3005"); //$NON-NLS-1$
	/**
	 * @generated
	 */
	public static final IElementType Method_3016 = getElementType("org.ifc.omtg.diagram.Method_3016"); //$NON-NLS-1$
	/**
	 * @generated
	 */
	public static final IElementType Attribute_3006 = getElementType("org.ifc.omtg.diagram.Attribute_3006"); //$NON-NLS-1$
	/**
	 * @generated
	 */
	public static final IElementType Method_3017 = getElementType("org.ifc.omtg.diagram.Method_3017"); //$NON-NLS-1$
	/**
	 * @generated
	 */
	public static final IElementType Attribute_3007 = getElementType("org.ifc.omtg.diagram.Attribute_3007"); //$NON-NLS-1$
	/**
	 * @generated
	 */
	public static final IElementType Method_3018 = getElementType("org.ifc.omtg.diagram.Method_3018"); //$NON-NLS-1$
	/**
	 * @generated
	 */
	public static final IElementType Attribute_3008 = getElementType("org.ifc.omtg.diagram.Attribute_3008"); //$NON-NLS-1$
	/**
	 * @generated
	 */
	public static final IElementType Method_3019 = getElementType("org.ifc.omtg.diagram.Method_3019"); //$NON-NLS-1$
	/**
	 * @generated
	 */
	public static final IElementType Attribute_3009 = getElementType("org.ifc.omtg.diagram.Attribute_3009"); //$NON-NLS-1$
	/**
	 * @generated
	 */
	public static final IElementType Method_3020 = getElementType("org.ifc.omtg.diagram.Method_3020"); //$NON-NLS-1$
	/**
	 * @generated
	 */
	public static final IElementType Attribute_3010 = getElementType("org.ifc.omtg.diagram.Attribute_3010"); //$NON-NLS-1$
	/**
	 * @generated
	 */
	public static final IElementType Method_3021 = getElementType("org.ifc.omtg.diagram.Method_3021"); //$NON-NLS-1$
	/**
	 * @generated
	 */
	public static final IElementType Attribute_3011 = getElementType("org.ifc.omtg.diagram.Attribute_3011"); //$NON-NLS-1$
	/**
	 * @generated
	 */
	public static final IElementType Method_3023 = getElementType("org.ifc.omtg.diagram.Method_3023"); //$NON-NLS-1$
	/**
	 * @generated
	 */
	public static final IElementType Attribute_3022 = getElementType("org.ifc.omtg.diagram.Attribute_3022"); //$NON-NLS-1$
	/**
	 * @generated
	 */
	public static final IElementType Method_3024 = getElementType("org.ifc.omtg.diagram.Method_3024"); //$NON-NLS-1$
	/**
	 * @generated
	 */
	public static final IElementType SpatialAgregation_4001 = getElementType("org.ifc.omtg.diagram.SpatialAgregation_4001"); //$NON-NLS-1$
	/**
	 * @generated
	 */
	public static final IElementType OverlappingTotal_4002 = getElementType("org.ifc.omtg.diagram.OverlappingTotal_4002"); //$NON-NLS-1$
	/**
	 * @generated
	 */
	public static final IElementType DisjointPartial_4003 = getElementType("org.ifc.omtg.diagram.DisjointPartial_4003"); //$NON-NLS-1$
	/**
	 * @generated
	 */
	public static final IElementType Simple_4004 = getElementType("org.ifc.omtg.diagram.Simple_4004"); //$NON-NLS-1$
	/**
	 * @generated
	 */
	public static final IElementType Scale_4005 = getElementType("org.ifc.omtg.diagram.Scale_4005"); //$NON-NLS-1$
	/**
	 * @generated
	 */
	public static final IElementType Shape_4006 = getElementType("org.ifc.omtg.diagram.Shape_4006"); //$NON-NLS-1$
	/**
	 * @generated
	 */
	public static final IElementType Agregation_4007 = getElementType("org.ifc.omtg.diagram.Agregation_4007"); //$NON-NLS-1$
	/**
	 * @generated
	 */
	public static final IElementType Spatial_4008 = getElementType("org.ifc.omtg.diagram.Spatial_4008"); //$NON-NLS-1$
	/**
	 * @generated
	 */
	public static final IElementType NetworkAssociation_4009 = getElementType("org.ifc.omtg.diagram.NetworkAssociation_4009"); //$NON-NLS-1$
	/**
	 * @generated
	 */
	public static final IElementType DisjointTotal_4010 = getElementType("org.ifc.omtg.diagram.DisjointTotal_4010"); //$NON-NLS-1$
	/**
	 * @generated
	 */
	public static final IElementType OverlappingPartial_4011 = getElementType("org.ifc.omtg.diagram.OverlappingPartial_4011"); //$NON-NLS-1$

	/**
	 * @generated
	 */
	private static ImageRegistry getImageRegistry() {
		if (imageRegistry == null) {
			imageRegistry = new ImageRegistry();
		}
		return imageRegistry;
	}

	/**
	 * @generated
	 */
	private static String getImageRegistryKey(ENamedElement element) {
		return element.getName();
	}

	/**
	 * @generated
	 */
	private static ImageDescriptor getProvidedImageDescriptor(
			ENamedElement element) {
		if (element instanceof EStructuralFeature) {
			EStructuralFeature feature = ((EStructuralFeature) element);
			EClass eContainingClass = feature.getEContainingClass();
			EClassifier eType = feature.getEType();
			if (eContainingClass != null && !eContainingClass.isAbstract()) {
				element = eContainingClass;
			} else if (eType instanceof EClass
					&& !((EClass) eType).isAbstract()) {
				element = eType;
			}
		}
		if (element instanceof EClass) {
			EClass eClass = (EClass) element;
			if (!eClass.isAbstract()) {
				return OmtgDiagramEditorPlugin.getInstance()
						.getItemImageDescriptor(
								eClass.getEPackage().getEFactoryInstance()
										.create(eClass));
			}
		}
		// TODO : support structural features
		return null;
	}

	/**
	 * @generated
	 */
	public static ImageDescriptor getImageDescriptor(ENamedElement element) {
		String key = getImageRegistryKey(element);
		ImageDescriptor imageDescriptor = getImageRegistry().getDescriptor(key);
		if (imageDescriptor == null) {
			imageDescriptor = getProvidedImageDescriptor(element);
			if (imageDescriptor == null) {
				imageDescriptor = ImageDescriptor.getMissingImageDescriptor();
			}
			getImageRegistry().put(key, imageDescriptor);
		}
		return imageDescriptor;
	}

	/**
	 * @generated
	 */
	public static Image getImage(ENamedElement element) {
		String key = getImageRegistryKey(element);
		Image image = getImageRegistry().get(key);
		if (image == null) {
			ImageDescriptor imageDescriptor = getProvidedImageDescriptor(element);
			if (imageDescriptor == null) {
				imageDescriptor = ImageDescriptor.getMissingImageDescriptor();
			}
			getImageRegistry().put(key, imageDescriptor);
			image = getImageRegistry().get(key);
		}
		return image;
	}

	/**
	 * @generated
	 */
	public static ImageDescriptor getImageDescriptor(IAdaptable hint) {
		ENamedElement element = getElement(hint);
		if (element == null) {
			return null;
		}
		return getImageDescriptor(element);
	}

	/**
	 * @generated
	 */
	public static Image getImage(IAdaptable hint) {
		ENamedElement element = getElement(hint);
		if (element == null) {
			return null;
		}
		return getImage(element);
	}

	/**
	 * Returns 'type' of the ecore object associated with the hint.
	 * 
	 * @generated
	 */
	public static ENamedElement getElement(IAdaptable hint) {
		Object type = hint.getAdapter(IElementType.class);
		if (elements == null) {
			elements = new IdentityHashMap<IElementType, ENamedElement>();

			elements.put(Schema_1000, OmtgPackage.eINSTANCE.getSchema());

			elements.put(Polygon_2013, OmtgPackage.eINSTANCE.getPolygon());

			elements.put(Point_2014, OmtgPackage.eINSTANCE.getPoint());

			elements.put(Line_2015, OmtgPackage.eINSTANCE.getLine());

			elements.put(NetworkClass_2016,
					OmtgPackage.eINSTANCE.getNetworkClass());

			elements.put(Sampling_2025, OmtgPackage.eINSTANCE.getSampling());

			elements.put(Isoline_2018, OmtgPackage.eINSTANCE.getIsoline());

			elements.put(Node_2019, OmtgPackage.eINSTANCE.getNode());

			elements.put(AdjacentPolygons_2020,
					OmtgPackage.eINSTANCE.getAdjacentPolygons());

			elements.put(BidirectionalLine_2021,
					OmtgPackage.eINSTANCE.getBidirectionalLine());

			elements.put(Tesselation_2022,
					OmtgPackage.eINSTANCE.getTesselation());

			elements.put(UnidirectionalLine_2023,
					OmtgPackage.eINSTANCE.getUnidirectionalLine());

			elements.put(Conventional_2024,
					OmtgPackage.eINSTANCE.getConventional());

			elements.put(Attribute_3001, OmtgPackage.eINSTANCE.getAttribute());

			elements.put(Method_3012, OmtgPackage.eINSTANCE.getMethod());

			elements.put(Attribute_3002, OmtgPackage.eINSTANCE.getAttribute());

			elements.put(Method_3013, OmtgPackage.eINSTANCE.getMethod());

			elements.put(Attribute_3003, OmtgPackage.eINSTANCE.getAttribute());

			elements.put(Method_3014, OmtgPackage.eINSTANCE.getMethod());

			elements.put(Attribute_3004, OmtgPackage.eINSTANCE.getAttribute());

			elements.put(Method_3015, OmtgPackage.eINSTANCE.getMethod());

			elements.put(Attribute_3005, OmtgPackage.eINSTANCE.getAttribute());

			elements.put(Method_3016, OmtgPackage.eINSTANCE.getMethod());

			elements.put(Attribute_3006, OmtgPackage.eINSTANCE.getAttribute());

			elements.put(Method_3017, OmtgPackage.eINSTANCE.getMethod());

			elements.put(Attribute_3007, OmtgPackage.eINSTANCE.getAttribute());

			elements.put(Method_3018, OmtgPackage.eINSTANCE.getMethod());

			elements.put(Attribute_3008, OmtgPackage.eINSTANCE.getAttribute());

			elements.put(Method_3019, OmtgPackage.eINSTANCE.getMethod());

			elements.put(Attribute_3009, OmtgPackage.eINSTANCE.getAttribute());

			elements.put(Method_3020, OmtgPackage.eINSTANCE.getMethod());

			elements.put(Attribute_3010, OmtgPackage.eINSTANCE.getAttribute());

			elements.put(Method_3021, OmtgPackage.eINSTANCE.getMethod());

			elements.put(Attribute_3011, OmtgPackage.eINSTANCE.getAttribute());

			elements.put(Method_3023, OmtgPackage.eINSTANCE.getMethod());

			elements.put(Attribute_3022, OmtgPackage.eINSTANCE.getAttribute());

			elements.put(Method_3024, OmtgPackage.eINSTANCE.getMethod());

			elements.put(SpatialAgregation_4001,
					OmtgPackage.eINSTANCE.getSpatialAgregation());

			elements.put(OverlappingTotal_4002,
					OmtgPackage.eINSTANCE.getOverlappingTotal());

			elements.put(DisjointPartial_4003,
					OmtgPackage.eINSTANCE.getDisjointPartial());

			elements.put(Simple_4004, OmtgPackage.eINSTANCE.getSimple());

			elements.put(Scale_4005, OmtgPackage.eINSTANCE.getScale());

			elements.put(Shape_4006, OmtgPackage.eINSTANCE.getShape());

			elements.put(Agregation_4007, OmtgPackage.eINSTANCE.getAgregation());

			elements.put(Spatial_4008, OmtgPackage.eINSTANCE.getSpatial());

			elements.put(NetworkAssociation_4009,
					OmtgPackage.eINSTANCE.getNetworkAssociation());

			elements.put(DisjointTotal_4010,
					OmtgPackage.eINSTANCE.getDisjointTotal());

			elements.put(OverlappingPartial_4011,
					OmtgPackage.eINSTANCE.getOverlappingPartial());
		}
		return (ENamedElement) elements.get(type);
	}

	/**
	 * @generated
	 */
	private static IElementType getElementType(String id) {
		return ElementTypeRegistry.getInstance().getType(id);
	}

	/**
	 * @generated
	 */
	public static boolean isKnownElementType(IElementType elementType) {
		if (KNOWN_ELEMENT_TYPES == null) {
			KNOWN_ELEMENT_TYPES = new HashSet<IElementType>();
			KNOWN_ELEMENT_TYPES.add(Schema_1000);
			KNOWN_ELEMENT_TYPES.add(Polygon_2013);
			KNOWN_ELEMENT_TYPES.add(Point_2014);
			KNOWN_ELEMENT_TYPES.add(Line_2015);
			KNOWN_ELEMENT_TYPES.add(NetworkClass_2016);
			KNOWN_ELEMENT_TYPES.add(Sampling_2025);
			KNOWN_ELEMENT_TYPES.add(Isoline_2018);
			KNOWN_ELEMENT_TYPES.add(Node_2019);
			KNOWN_ELEMENT_TYPES.add(AdjacentPolygons_2020);
			KNOWN_ELEMENT_TYPES.add(BidirectionalLine_2021);
			KNOWN_ELEMENT_TYPES.add(Tesselation_2022);
			KNOWN_ELEMENT_TYPES.add(UnidirectionalLine_2023);
			KNOWN_ELEMENT_TYPES.add(Conventional_2024);
			KNOWN_ELEMENT_TYPES.add(Attribute_3001);
			KNOWN_ELEMENT_TYPES.add(Method_3012);
			KNOWN_ELEMENT_TYPES.add(Attribute_3002);
			KNOWN_ELEMENT_TYPES.add(Method_3013);
			KNOWN_ELEMENT_TYPES.add(Attribute_3003);
			KNOWN_ELEMENT_TYPES.add(Method_3014);
			KNOWN_ELEMENT_TYPES.add(Attribute_3004);
			KNOWN_ELEMENT_TYPES.add(Method_3015);
			KNOWN_ELEMENT_TYPES.add(Attribute_3005);
			KNOWN_ELEMENT_TYPES.add(Method_3016);
			KNOWN_ELEMENT_TYPES.add(Attribute_3006);
			KNOWN_ELEMENT_TYPES.add(Method_3017);
			KNOWN_ELEMENT_TYPES.add(Attribute_3007);
			KNOWN_ELEMENT_TYPES.add(Method_3018);
			KNOWN_ELEMENT_TYPES.add(Attribute_3008);
			KNOWN_ELEMENT_TYPES.add(Method_3019);
			KNOWN_ELEMENT_TYPES.add(Attribute_3009);
			KNOWN_ELEMENT_TYPES.add(Method_3020);
			KNOWN_ELEMENT_TYPES.add(Attribute_3010);
			KNOWN_ELEMENT_TYPES.add(Method_3021);
			KNOWN_ELEMENT_TYPES.add(Attribute_3011);
			KNOWN_ELEMENT_TYPES.add(Method_3023);
			KNOWN_ELEMENT_TYPES.add(Attribute_3022);
			KNOWN_ELEMENT_TYPES.add(Method_3024);
			KNOWN_ELEMENT_TYPES.add(SpatialAgregation_4001);
			KNOWN_ELEMENT_TYPES.add(OverlappingTotal_4002);
			KNOWN_ELEMENT_TYPES.add(DisjointPartial_4003);
			KNOWN_ELEMENT_TYPES.add(Simple_4004);
			KNOWN_ELEMENT_TYPES.add(Scale_4005);
			KNOWN_ELEMENT_TYPES.add(Shape_4006);
			KNOWN_ELEMENT_TYPES.add(Agregation_4007);
			KNOWN_ELEMENT_TYPES.add(Spatial_4008);
			KNOWN_ELEMENT_TYPES.add(NetworkAssociation_4009);
			KNOWN_ELEMENT_TYPES.add(DisjointTotal_4010);
			KNOWN_ELEMENT_TYPES.add(OverlappingPartial_4011);
		}
		return KNOWN_ELEMENT_TYPES.contains(elementType);
	}

	/**
	 * @generated
	 */
	public static IElementType getElementType(int visualID) {
		switch (visualID) {
		case SchemaEditPart.VISUAL_ID:
			return Schema_1000;
		case PolygonEditPart.VISUAL_ID:
			return Polygon_2013;
		case PointEditPart.VISUAL_ID:
			return Point_2014;
		case LineEditPart.VISUAL_ID:
			return Line_2015;
		case NetworkClassEditPart.VISUAL_ID:
			return NetworkClass_2016;
		case SamplingEditPart.VISUAL_ID:
			return Sampling_2025;
		case IsolineEditPart.VISUAL_ID:
			return Isoline_2018;
		case NodeEditPart.VISUAL_ID:
			return Node_2019;
		case AdjacentPolygonsEditPart.VISUAL_ID:
			return AdjacentPolygons_2020;
		case BidirectionalLineEditPart.VISUAL_ID:
			return BidirectionalLine_2021;
		case TesselationEditPart.VISUAL_ID:
			return Tesselation_2022;
		case UnidirectionalLineEditPart.VISUAL_ID:
			return UnidirectionalLine_2023;
		case ConventionalEditPart.VISUAL_ID:
			return Conventional_2024;
		case AttributeEditPart.VISUAL_ID:
			return Attribute_3001;
		case MethodEditPart.VISUAL_ID:
			return Method_3012;
		case Attribute2EditPart.VISUAL_ID:
			return Attribute_3002;
		case Method2EditPart.VISUAL_ID:
			return Method_3013;
		case Attribute3EditPart.VISUAL_ID:
			return Attribute_3003;
		case Method3EditPart.VISUAL_ID:
			return Method_3014;
		case Attribute4EditPart.VISUAL_ID:
			return Attribute_3004;
		case Method4EditPart.VISUAL_ID:
			return Method_3015;
		case Attribute5EditPart.VISUAL_ID:
			return Attribute_3005;
		case Method5EditPart.VISUAL_ID:
			return Method_3016;
		case Attribute6EditPart.VISUAL_ID:
			return Attribute_3006;
		case Method6EditPart.VISUAL_ID:
			return Method_3017;
		case Attribute7EditPart.VISUAL_ID:
			return Attribute_3007;
		case Method7EditPart.VISUAL_ID:
			return Method_3018;
		case Attribute8EditPart.VISUAL_ID:
			return Attribute_3008;
		case Method8EditPart.VISUAL_ID:
			return Method_3019;
		case Attribute9EditPart.VISUAL_ID:
			return Attribute_3009;
		case Method9EditPart.VISUAL_ID:
			return Method_3020;
		case Attribute10EditPart.VISUAL_ID:
			return Attribute_3010;
		case Method10EditPart.VISUAL_ID:
			return Method_3021;
		case Attribute11EditPart.VISUAL_ID:
			return Attribute_3011;
		case Method11EditPart.VISUAL_ID:
			return Method_3023;
		case Attribute12EditPart.VISUAL_ID:
			return Attribute_3022;
		case Method12EditPart.VISUAL_ID:
			return Method_3024;
		case SpatialAgregationEditPart.VISUAL_ID:
			return SpatialAgregation_4001;
		case OverlappingTotalEditPart.VISUAL_ID:
			return OverlappingTotal_4002;
		case DisjointPartialEditPart.VISUAL_ID:
			return DisjointPartial_4003;
		case SimpleEditPart.VISUAL_ID:
			return Simple_4004;
		case ScaleEditPart.VISUAL_ID:
			return Scale_4005;
		case ShapeEditPart.VISUAL_ID:
			return Shape_4006;
		case AgregationEditPart.VISUAL_ID:
			return Agregation_4007;
		case SpatialEditPart.VISUAL_ID:
			return Spatial_4008;
		case NetworkAssociationEditPart.VISUAL_ID:
			return NetworkAssociation_4009;
		case DisjointTotalEditPart.VISUAL_ID:
			return DisjointTotal_4010;
		case OverlappingPartialEditPart.VISUAL_ID:
			return OverlappingPartial_4011;
		}
		return null;
	}

}
