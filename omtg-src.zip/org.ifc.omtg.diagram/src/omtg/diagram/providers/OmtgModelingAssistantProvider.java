package omtg.diagram.providers;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;

import omtg.diagram.edit.parts.AdjacentPolygonsEditPart;
import omtg.diagram.edit.parts.BidirectionalLineEditPart;
import omtg.diagram.edit.parts.ConventionalEditPart;
import omtg.diagram.edit.parts.IsolineEditPart;
import omtg.diagram.edit.parts.LineEditPart;
import omtg.diagram.edit.parts.NetworkClassEditPart;
import omtg.diagram.edit.parts.NodeEditPart;
import omtg.diagram.edit.parts.PointEditPart;
import omtg.diagram.edit.parts.PolygonEditPart;
import omtg.diagram.edit.parts.SamplingEditPart;
import omtg.diagram.edit.parts.SchemaEditPart;
import omtg.diagram.edit.parts.TesselationEditPart;
import omtg.diagram.edit.parts.UnidirectionalLineEditPart;
import omtg.diagram.part.Messages;
import omtg.diagram.part.OmtgDiagramEditorPlugin;

import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.edit.ui.provider.AdapterFactoryLabelProvider;
import org.eclipse.gmf.runtime.diagram.ui.editparts.IGraphicalEditPart;
import org.eclipse.gmf.runtime.emf.type.core.ElementTypeRegistry;
import org.eclipse.gmf.runtime.emf.type.core.IElementType;
import org.eclipse.gmf.runtime.emf.ui.services.modelingassistant.ModelingAssistantProvider;
import org.eclipse.gmf.runtime.notation.Diagram;
import org.eclipse.jface.viewers.ILabelProvider;
import org.eclipse.jface.window.Window;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.dialogs.ElementListSelectionDialog;

/**
 * @generated
 */
public class OmtgModelingAssistantProvider extends ModelingAssistantProvider {

	/**
	 * @generated
	 */
	public List getTypesForPopupBar(IAdaptable host) {
		IGraphicalEditPart editPart = (IGraphicalEditPart) host
				.getAdapter(IGraphicalEditPart.class);
		if (editPart instanceof SchemaEditPart) {
			ArrayList<IElementType> types = new ArrayList<IElementType>(12);
			types.add(OmtgElementTypes.Polygon_2013);
			types.add(OmtgElementTypes.Point_2014);
			types.add(OmtgElementTypes.Line_2015);
			types.add(OmtgElementTypes.NetworkClass_2016);
			types.add(OmtgElementTypes.Sampling_2025);
			types.add(OmtgElementTypes.Isoline_2018);
			types.add(OmtgElementTypes.Node_2019);
			types.add(OmtgElementTypes.AdjacentPolygons_2020);
			types.add(OmtgElementTypes.BidirectionalLine_2021);
			types.add(OmtgElementTypes.Tesselation_2022);
			types.add(OmtgElementTypes.UnidirectionalLine_2023);
			types.add(OmtgElementTypes.Conventional_2024);
			return types;
		}
		if (editPart instanceof PolygonEditPart) {
			ArrayList<IElementType> types = new ArrayList<IElementType>(2);
			types.add(OmtgElementTypes.Attribute_3001);
			types.add(OmtgElementTypes.Method_3012);
			return types;
		}
		if (editPart instanceof PointEditPart) {
			ArrayList<IElementType> types = new ArrayList<IElementType>(2);
			types.add(OmtgElementTypes.Attribute_3002);
			types.add(OmtgElementTypes.Method_3013);
			return types;
		}
		if (editPart instanceof LineEditPart) {
			ArrayList<IElementType> types = new ArrayList<IElementType>(2);
			types.add(OmtgElementTypes.Attribute_3003);
			types.add(OmtgElementTypes.Method_3014);
			return types;
		}
		if (editPart instanceof NetworkClassEditPart) {
			ArrayList<IElementType> types = new ArrayList<IElementType>(2);
			types.add(OmtgElementTypes.Attribute_3004);
			types.add(OmtgElementTypes.Method_3015);
			return types;
		}
		if (editPart instanceof SamplingEditPart) {
			ArrayList<IElementType> types = new ArrayList<IElementType>(2);
			types.add(OmtgElementTypes.Attribute_3005);
			types.add(OmtgElementTypes.Method_3016);
			return types;
		}
		if (editPart instanceof IsolineEditPart) {
			ArrayList<IElementType> types = new ArrayList<IElementType>(2);
			types.add(OmtgElementTypes.Attribute_3006);
			types.add(OmtgElementTypes.Method_3017);
			return types;
		}
		if (editPart instanceof NodeEditPart) {
			ArrayList<IElementType> types = new ArrayList<IElementType>(2);
			types.add(OmtgElementTypes.Attribute_3007);
			types.add(OmtgElementTypes.Method_3018);
			return types;
		}
		if (editPart instanceof AdjacentPolygonsEditPart) {
			ArrayList<IElementType> types = new ArrayList<IElementType>(2);
			types.add(OmtgElementTypes.Attribute_3008);
			types.add(OmtgElementTypes.Method_3019);
			return types;
		}
		if (editPart instanceof BidirectionalLineEditPart) {
			ArrayList<IElementType> types = new ArrayList<IElementType>(2);
			types.add(OmtgElementTypes.Attribute_3009);
			types.add(OmtgElementTypes.Method_3020);
			return types;
		}
		if (editPart instanceof TesselationEditPart) {
			ArrayList<IElementType> types = new ArrayList<IElementType>(2);
			types.add(OmtgElementTypes.Attribute_3010);
			types.add(OmtgElementTypes.Method_3021);
			return types;
		}
		if (editPart instanceof UnidirectionalLineEditPart) {
			ArrayList<IElementType> types = new ArrayList<IElementType>(2);
			types.add(OmtgElementTypes.Attribute_3011);
			types.add(OmtgElementTypes.Method_3023);
			return types;
		}
		if (editPart instanceof ConventionalEditPart) {
			ArrayList<IElementType> types = new ArrayList<IElementType>(2);
			types.add(OmtgElementTypes.Attribute_3022);
			types.add(OmtgElementTypes.Method_3024);
			return types;
		}
		return Collections.EMPTY_LIST;
	}

	/**
	 * @generated
	 */
	public List getRelTypesOnSource(IAdaptable source) {
		IGraphicalEditPart sourceEditPart = (IGraphicalEditPart) source
				.getAdapter(IGraphicalEditPart.class);
		if (sourceEditPart instanceof PolygonEditPart) {
			return ((PolygonEditPart) sourceEditPart).getMARelTypesOnSource();
		}
		if (sourceEditPart instanceof PointEditPart) {
			return ((PointEditPart) sourceEditPart).getMARelTypesOnSource();
		}
		if (sourceEditPart instanceof LineEditPart) {
			return ((LineEditPart) sourceEditPart).getMARelTypesOnSource();
		}
		if (sourceEditPart instanceof NetworkClassEditPart) {
			return ((NetworkClassEditPart) sourceEditPart)
					.getMARelTypesOnSource();
		}
		if (sourceEditPart instanceof SamplingEditPart) {
			return ((SamplingEditPart) sourceEditPart).getMARelTypesOnSource();
		}
		if (sourceEditPart instanceof IsolineEditPart) {
			return ((IsolineEditPart) sourceEditPart).getMARelTypesOnSource();
		}
		if (sourceEditPart instanceof NodeEditPart) {
			return ((NodeEditPart) sourceEditPart).getMARelTypesOnSource();
		}
		if (sourceEditPart instanceof AdjacentPolygonsEditPart) {
			return ((AdjacentPolygonsEditPart) sourceEditPart)
					.getMARelTypesOnSource();
		}
		if (sourceEditPart instanceof BidirectionalLineEditPart) {
			return ((BidirectionalLineEditPart) sourceEditPart)
					.getMARelTypesOnSource();
		}
		if (sourceEditPart instanceof TesselationEditPart) {
			return ((TesselationEditPart) sourceEditPart)
					.getMARelTypesOnSource();
		}
		if (sourceEditPart instanceof UnidirectionalLineEditPart) {
			return ((UnidirectionalLineEditPart) sourceEditPart)
					.getMARelTypesOnSource();
		}
		if (sourceEditPart instanceof ConventionalEditPart) {
			return ((ConventionalEditPart) sourceEditPart)
					.getMARelTypesOnSource();
		}
		return Collections.EMPTY_LIST;
	}

	/**
	 * @generated
	 */
	public List getRelTypesOnTarget(IAdaptable target) {
		IGraphicalEditPart targetEditPart = (IGraphicalEditPart) target
				.getAdapter(IGraphicalEditPart.class);
		if (targetEditPart instanceof PolygonEditPart) {
			return ((PolygonEditPart) targetEditPart).getMARelTypesOnTarget();
		}
		if (targetEditPart instanceof PointEditPart) {
			return ((PointEditPart) targetEditPart).getMARelTypesOnTarget();
		}
		if (targetEditPart instanceof LineEditPart) {
			return ((LineEditPart) targetEditPart).getMARelTypesOnTarget();
		}
		if (targetEditPart instanceof NetworkClassEditPart) {
			return ((NetworkClassEditPart) targetEditPart)
					.getMARelTypesOnTarget();
		}
		if (targetEditPart instanceof SamplingEditPart) {
			return ((SamplingEditPart) targetEditPart).getMARelTypesOnTarget();
		}
		if (targetEditPart instanceof IsolineEditPart) {
			return ((IsolineEditPart) targetEditPart).getMARelTypesOnTarget();
		}
		if (targetEditPart instanceof NodeEditPart) {
			return ((NodeEditPart) targetEditPart).getMARelTypesOnTarget();
		}
		if (targetEditPart instanceof AdjacentPolygonsEditPart) {
			return ((AdjacentPolygonsEditPart) targetEditPart)
					.getMARelTypesOnTarget();
		}
		if (targetEditPart instanceof BidirectionalLineEditPart) {
			return ((BidirectionalLineEditPart) targetEditPart)
					.getMARelTypesOnTarget();
		}
		if (targetEditPart instanceof TesselationEditPart) {
			return ((TesselationEditPart) targetEditPart)
					.getMARelTypesOnTarget();
		}
		if (targetEditPart instanceof UnidirectionalLineEditPart) {
			return ((UnidirectionalLineEditPart) targetEditPart)
					.getMARelTypesOnTarget();
		}
		if (targetEditPart instanceof ConventionalEditPart) {
			return ((ConventionalEditPart) targetEditPart)
					.getMARelTypesOnTarget();
		}
		return Collections.EMPTY_LIST;
	}

	/**
	 * @generated
	 */
	public List getRelTypesOnSourceAndTarget(IAdaptable source,
			IAdaptable target) {
		IGraphicalEditPart sourceEditPart = (IGraphicalEditPart) source
				.getAdapter(IGraphicalEditPart.class);
		IGraphicalEditPart targetEditPart = (IGraphicalEditPart) target
				.getAdapter(IGraphicalEditPart.class);
		if (sourceEditPart instanceof PolygonEditPart) {
			return ((PolygonEditPart) sourceEditPart)
					.getMARelTypesOnSourceAndTarget(targetEditPart);
		}
		if (sourceEditPart instanceof PointEditPart) {
			return ((PointEditPart) sourceEditPart)
					.getMARelTypesOnSourceAndTarget(targetEditPart);
		}
		if (sourceEditPart instanceof LineEditPart) {
			return ((LineEditPart) sourceEditPart)
					.getMARelTypesOnSourceAndTarget(targetEditPart);
		}
		if (sourceEditPart instanceof NetworkClassEditPart) {
			return ((NetworkClassEditPart) sourceEditPart)
					.getMARelTypesOnSourceAndTarget(targetEditPart);
		}
		if (sourceEditPart instanceof SamplingEditPart) {
			return ((SamplingEditPart) sourceEditPart)
					.getMARelTypesOnSourceAndTarget(targetEditPart);
		}
		if (sourceEditPart instanceof IsolineEditPart) {
			return ((IsolineEditPart) sourceEditPart)
					.getMARelTypesOnSourceAndTarget(targetEditPart);
		}
		if (sourceEditPart instanceof NodeEditPart) {
			return ((NodeEditPart) sourceEditPart)
					.getMARelTypesOnSourceAndTarget(targetEditPart);
		}
		if (sourceEditPart instanceof AdjacentPolygonsEditPart) {
			return ((AdjacentPolygonsEditPart) sourceEditPart)
					.getMARelTypesOnSourceAndTarget(targetEditPart);
		}
		if (sourceEditPart instanceof BidirectionalLineEditPart) {
			return ((BidirectionalLineEditPart) sourceEditPart)
					.getMARelTypesOnSourceAndTarget(targetEditPart);
		}
		if (sourceEditPart instanceof TesselationEditPart) {
			return ((TesselationEditPart) sourceEditPart)
					.getMARelTypesOnSourceAndTarget(targetEditPart);
		}
		if (sourceEditPart instanceof UnidirectionalLineEditPart) {
			return ((UnidirectionalLineEditPart) sourceEditPart)
					.getMARelTypesOnSourceAndTarget(targetEditPart);
		}
		if (sourceEditPart instanceof ConventionalEditPart) {
			return ((ConventionalEditPart) sourceEditPart)
					.getMARelTypesOnSourceAndTarget(targetEditPart);
		}
		return Collections.EMPTY_LIST;
	}

	/**
	 * @generated
	 */
	public List getTypesForSource(IAdaptable target,
			IElementType relationshipType) {
		IGraphicalEditPart targetEditPart = (IGraphicalEditPart) target
				.getAdapter(IGraphicalEditPart.class);
		if (targetEditPart instanceof PolygonEditPart) {
			return ((PolygonEditPart) targetEditPart)
					.getMATypesForSource(relationshipType);
		}
		if (targetEditPart instanceof PointEditPart) {
			return ((PointEditPart) targetEditPart)
					.getMATypesForSource(relationshipType);
		}
		if (targetEditPart instanceof LineEditPart) {
			return ((LineEditPart) targetEditPart)
					.getMATypesForSource(relationshipType);
		}
		if (targetEditPart instanceof NetworkClassEditPart) {
			return ((NetworkClassEditPart) targetEditPart)
					.getMATypesForSource(relationshipType);
		}
		if (targetEditPart instanceof SamplingEditPart) {
			return ((SamplingEditPart) targetEditPart)
					.getMATypesForSource(relationshipType);
		}
		if (targetEditPart instanceof IsolineEditPart) {
			return ((IsolineEditPart) targetEditPart)
					.getMATypesForSource(relationshipType);
		}
		if (targetEditPart instanceof NodeEditPart) {
			return ((NodeEditPart) targetEditPart)
					.getMATypesForSource(relationshipType);
		}
		if (targetEditPart instanceof AdjacentPolygonsEditPart) {
			return ((AdjacentPolygonsEditPart) targetEditPart)
					.getMATypesForSource(relationshipType);
		}
		if (targetEditPart instanceof BidirectionalLineEditPart) {
			return ((BidirectionalLineEditPart) targetEditPart)
					.getMATypesForSource(relationshipType);
		}
		if (targetEditPart instanceof TesselationEditPart) {
			return ((TesselationEditPart) targetEditPart)
					.getMATypesForSource(relationshipType);
		}
		if (targetEditPart instanceof UnidirectionalLineEditPart) {
			return ((UnidirectionalLineEditPart) targetEditPart)
					.getMATypesForSource(relationshipType);
		}
		if (targetEditPart instanceof ConventionalEditPart) {
			return ((ConventionalEditPart) targetEditPart)
					.getMATypesForSource(relationshipType);
		}
		return Collections.EMPTY_LIST;
	}

	/**
	 * @generated
	 */
	public List getTypesForTarget(IAdaptable source,
			IElementType relationshipType) {
		IGraphicalEditPart sourceEditPart = (IGraphicalEditPart) source
				.getAdapter(IGraphicalEditPart.class);
		if (sourceEditPart instanceof PolygonEditPart) {
			return ((PolygonEditPart) sourceEditPart)
					.getMATypesForTarget(relationshipType);
		}
		if (sourceEditPart instanceof PointEditPart) {
			return ((PointEditPart) sourceEditPart)
					.getMATypesForTarget(relationshipType);
		}
		if (sourceEditPart instanceof LineEditPart) {
			return ((LineEditPart) sourceEditPart)
					.getMATypesForTarget(relationshipType);
		}
		if (sourceEditPart instanceof NetworkClassEditPart) {
			return ((NetworkClassEditPart) sourceEditPart)
					.getMATypesForTarget(relationshipType);
		}
		if (sourceEditPart instanceof SamplingEditPart) {
			return ((SamplingEditPart) sourceEditPart)
					.getMATypesForTarget(relationshipType);
		}
		if (sourceEditPart instanceof IsolineEditPart) {
			return ((IsolineEditPart) sourceEditPart)
					.getMATypesForTarget(relationshipType);
		}
		if (sourceEditPart instanceof NodeEditPart) {
			return ((NodeEditPart) sourceEditPart)
					.getMATypesForTarget(relationshipType);
		}
		if (sourceEditPart instanceof AdjacentPolygonsEditPart) {
			return ((AdjacentPolygonsEditPart) sourceEditPart)
					.getMATypesForTarget(relationshipType);
		}
		if (sourceEditPart instanceof BidirectionalLineEditPart) {
			return ((BidirectionalLineEditPart) sourceEditPart)
					.getMATypesForTarget(relationshipType);
		}
		if (sourceEditPart instanceof TesselationEditPart) {
			return ((TesselationEditPart) sourceEditPart)
					.getMATypesForTarget(relationshipType);
		}
		if (sourceEditPart instanceof UnidirectionalLineEditPart) {
			return ((UnidirectionalLineEditPart) sourceEditPart)
					.getMATypesForTarget(relationshipType);
		}
		if (sourceEditPart instanceof ConventionalEditPart) {
			return ((ConventionalEditPart) sourceEditPart)
					.getMATypesForTarget(relationshipType);
		}
		return Collections.EMPTY_LIST;
	}

	/**
	 * @generated
	 */
	public EObject selectExistingElementForSource(IAdaptable target,
			IElementType relationshipType) {
		return selectExistingElement(target,
				getTypesForSource(target, relationshipType));
	}

	/**
	 * @generated
	 */
	public EObject selectExistingElementForTarget(IAdaptable source,
			IElementType relationshipType) {
		return selectExistingElement(source,
				getTypesForTarget(source, relationshipType));
	}

	/**
	 * @generated
	 */
	protected EObject selectExistingElement(IAdaptable host, Collection types) {
		if (types.isEmpty()) {
			return null;
		}
		IGraphicalEditPart editPart = (IGraphicalEditPart) host
				.getAdapter(IGraphicalEditPart.class);
		if (editPart == null) {
			return null;
		}
		Diagram diagram = (Diagram) editPart.getRoot().getContents().getModel();
		HashSet<EObject> elements = new HashSet<EObject>();
		for (Iterator<EObject> it = diagram.getElement().eAllContents(); it
				.hasNext();) {
			EObject element = it.next();
			if (isApplicableElement(element, types)) {
				elements.add(element);
			}
		}
		if (elements.isEmpty()) {
			return null;
		}
		return selectElement((EObject[]) elements.toArray(new EObject[elements
				.size()]));
	}

	/**
	 * @generated
	 */
	protected boolean isApplicableElement(EObject element, Collection types) {
		IElementType type = ElementTypeRegistry.getInstance().getElementType(
				element);
		return types.contains(type);
	}

	/**
	 * @generated
	 */
	protected EObject selectElement(EObject[] elements) {
		Shell shell = Display.getCurrent().getActiveShell();
		ILabelProvider labelProvider = new AdapterFactoryLabelProvider(
				OmtgDiagramEditorPlugin.getInstance()
						.getItemProvidersAdapterFactory());
		ElementListSelectionDialog dialog = new ElementListSelectionDialog(
				shell, labelProvider);
		dialog.setMessage(Messages.OmtgModelingAssistantProviderMessage);
		dialog.setTitle(Messages.OmtgModelingAssistantProviderTitle);
		dialog.setMultipleSelection(false);
		dialog.setElements(elements);
		EObject selected = null;
		if (dialog.open() == Window.OK) {
			selected = (EObject) dialog.getFirstResult();
		}
		return selected;
	}
}
