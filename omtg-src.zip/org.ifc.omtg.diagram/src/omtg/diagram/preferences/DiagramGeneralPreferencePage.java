package omtg.diagram.preferences;

import omtg.diagram.part.OmtgDiagramEditorPlugin;

import org.eclipse.gmf.runtime.diagram.ui.preferences.DiagramsPreferencePage;

/**
 * @generated
 */
public class DiagramGeneralPreferencePage extends DiagramsPreferencePage {

	/**
	 * @generated
	 */
	public DiagramGeneralPreferencePage() {
		setPreferenceStore(OmtgDiagramEditorPlugin.getInstance()
				.getPreferenceStore());
	}
}
