package omtg.diagram.preferences;

import omtg.diagram.part.OmtgDiagramEditorPlugin;

import org.eclipse.gmf.runtime.diagram.ui.preferences.RulerGridPreferencePage;

/**
 * @generated
 */
public class DiagramRulersAndGridPreferencePage extends RulerGridPreferencePage {

	/**
	 * @generated
	 */
	public DiagramRulersAndGridPreferencePage() {
		setPreferenceStore(OmtgDiagramEditorPlugin.getInstance()
				.getPreferenceStore());
	}
}
