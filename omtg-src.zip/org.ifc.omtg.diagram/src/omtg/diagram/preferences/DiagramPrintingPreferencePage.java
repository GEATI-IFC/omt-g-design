package omtg.diagram.preferences;

import omtg.diagram.part.OmtgDiagramEditorPlugin;

import org.eclipse.gmf.runtime.diagram.ui.preferences.PrintingPreferencePage;

/**
 * @generated
 */
public class DiagramPrintingPreferencePage extends PrintingPreferencePage {

	/**
	 * @generated
	 */
	public DiagramPrintingPreferencePage() {
		setPreferenceStore(OmtgDiagramEditorPlugin.getInstance()
				.getPreferenceStore());
	}
}
