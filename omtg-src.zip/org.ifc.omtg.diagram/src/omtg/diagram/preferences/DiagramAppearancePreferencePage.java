package omtg.diagram.preferences;

import omtg.diagram.part.OmtgDiagramEditorPlugin;

import org.eclipse.gmf.runtime.diagram.ui.preferences.AppearancePreferencePage;

/**
 * @generated
 */
public class DiagramAppearancePreferencePage extends AppearancePreferencePage {

	/**
	 * @generated
	 */
	public DiagramAppearancePreferencePage() {
		setPreferenceStore(OmtgDiagramEditorPlugin.getInstance()
				.getPreferenceStore());
	}
}
