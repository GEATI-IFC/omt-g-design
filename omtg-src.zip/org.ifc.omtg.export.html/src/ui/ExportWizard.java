package ui;

import org.eclipse.core.resources.IResource;
import org.eclipse.emf.mwe.core.WorkflowFacade;
import org.eclipse.emf.mwe.core.issues.MWEDiagnostic;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.StructuredSelection;
import org.eclipse.jface.wizard.Wizard;
import org.eclipse.ui.IEditorPart;
import org.eclipse.ui.IExportWizard;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.internal.wizards.datatransfer.WizardFileSystemResourceExportPage1;


public class ExportWizard extends Wizard implements IExportWizard  {

	WizardFileSystemResourceExportPage1 mainPage = null;

	public void init(IWorkbench workbench, IStructuredSelection selection) {
		// TODO Auto-generated method stub

		
		IWorkbenchPage page = workbench.getActiveWorkbenchWindow().getActivePage();
		
		if ( page != null ) {
			
			IEditorPart currentEditor = page.getActiveEditor();
			
			 if (currentEditor != null) {
                 Object selectedResource = currentEditor.getEditorInput()
                         .getAdapter(IResource.class);
                 if (selectedResource != null) {
                     selection = new StructuredSelection(selectedResource);
                 }
			 }
			
		}
		
		mainPage = new ExportWizardPage("OI", selection );
		
		super.addPages();
		addPage(mainPage);
		
	}
	
	@Override
	public boolean performFinish() {
		// TODO Auto-generated method stub
		return mainPage.finish();
	}
	
	
}
